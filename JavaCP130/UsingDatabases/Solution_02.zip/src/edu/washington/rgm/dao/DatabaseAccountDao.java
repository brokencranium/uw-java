package edu.washington.rgm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.Address;
import edu.washington.ext.cp130.framework.account.CreditCard;
import edu.washington.ext.cp130.framework.dao.AccountDao;
import edu.washington.ext.cp130.framework.dao.DaoFactoryException;
import edu.washington.ext.cp130.util.AbstractTypeFactory;
import edu.washington.ext.cp130.util.FactoryException;

/**
 * Implementation of the AccountDao using relational database for persistence.
 *
 * @author Russ Moul
 */
public final class DatabaseAccountDao implements AccountDao {
    /** The JNDI name used for the DataSource */
    public static final String DATASOURCE_JNDI_NAME =
                               "jdbc/AccountDb";
                               //"java:comp/env/jdbc/AccountDb";

    /** The class' logger */
    private static Logger logger =
                          Logger.getLogger(DatabaseAccountDao.class.getName());

    /** SQL for obtaining account */
    private static final String ACCOUNT_QUERY =
            "SELECT password_hash, balance, fullname, phone, email,"
          + "       street, city, state, zip,"
          + "       card_number, issuer, cardtype, holder, expires"
          + "  FROM account"
          + " WHERE account_name = ?";

    /** SQL for inserting an account */
    private static final String INSERT_UPDATE_ACCOUNT =
            "INSERT INTO account"
          + " ( account_name, password_hash, balance, fullname, phone, email,"
          + "   street, city, state, zip,"
          + "   card_number, issuer, cardtype, holder, expires )"
          + " VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) "
          + " ON DUPLICATE KEY UPDATE"
          + "   password_hash=VALUES(password_hash), "
          + "   balance=VALUES(balance), "
          + "   fullname=VALUES(fullname), "
          + "   phone=VALUES(phone), "
          + "   email=VALUES(email), "
          + "   street=VALUES(street), "
          + "   city=VALUES(city), "
          + "   state=VALUES(state), "
          + "   zip=VALUES(zip), "
          + "   card_number=VALUES(card_number), "
          + "   issuer=VALUES(issuer), "
          + "   cardtype=VALUES(cardtype), "
          + "   holder=VALUES(holder), "
          + "   expires=VALUES(expires) ";

    /** SQL for deleting an account */
    private static final String DELETE_ACCOUNT =
            "DELETE from account"
          + " WHERE account_name = ?";

    /** SQL for resetting the accounts */
    private static final String RESET_ACCOUNTS = "DELETE from account";

    /** The connection. */
    private Connection connection;

    /** Account query prepared statement. */
    private PreparedStatement accountQuery;

    /** Account insert prepared statement. */
    private PreparedStatement accountInsertUpdate;

    /** Account delete prepared statement. */
    private PreparedStatement accountDelete;

    /**
     * Constructor.  Connects to the database and initializes the prepared
     * statements.
     *
     * @throws DaoFactoryException if unable to connect to the database or
     *         initialize the prepared statements
     */
    public DatabaseAccountDao() throws DaoFactoryException {
        Context ctx;
        try {
            ctx = new InitialContext();
            final DataSource ds = (DataSource) ctx.lookup(DATASOURCE_JNDI_NAME);
            ctx.close();
            connection = ds.getConnection();
            accountQuery = connection.prepareStatement(ACCOUNT_QUERY);
            accountInsertUpdate = connection.prepareStatement(INSERT_UPDATE_ACCOUNT);
            accountDelete = connection.prepareStatement(DELETE_ACCOUNT);
        } catch (final NamingException nex) {
            throw new DaoFactoryException("Unable to resolve datasource name, '" + DATASOURCE_JNDI_NAME + "'", nex);
        } catch (final SQLException ex) {
            throw new DaoFactoryException("Unable to connect or initialize prepared statemnts.", ex);
        }
    }

    /**
     * Lookup an account in the database based on username.
     *
     * @param accountName the name of the desired account
     *
     * @return the account if located otherwise null
     */
    public Account getAccount(final String accountName) {
        Account acct = null;
        ResultSet rs = null;

        try {
            accountQuery.setString(1, accountName);
            rs = accountQuery.executeQuery();

            if (rs.next()) {
                acct = (Account) AbstractTypeFactory.newInstance(Account.class);
                int colNdx = 1;

                acct.setName(accountName);
                acct.setPasswordHash(rs.getBytes(colNdx++));
                acct.setBalance(rs.getInt(colNdx++));

                acct.setFullName(rs.getString(colNdx++));
                acct.setPhone(rs.getString(colNdx++));
                acct.setEmail(rs.getString(colNdx++));

                Address addr;
                final String streetAddress = rs.getString(colNdx++);
                final String city = rs.getString(colNdx++);
                final String state = rs.getString(colNdx++);
                final String zipCode = rs.getString(colNdx++);

                if (streetAddress != null ||
                    city != null ||
                    state != null ||
                    zipCode != null) {
                    addr = (Address) AbstractTypeFactory.newInstance(Address.class);
                    addr.setStreetAddress(streetAddress);
                    addr.setCity(city);
                    addr.setState(state);
                    addr.setZipCode(zipCode);
                    acct.setAddress(addr);
                }

                final String accountNumber = rs.getString(colNdx++);
                final String issuer = rs.getString(colNdx++);
                final String type = rs.getString(colNdx++);
                final String holder = rs.getString(colNdx++);
                final String expirationDate = rs.getString(colNdx++);

                if (accountNumber != null ||
                    issuer != null ||
                    type != null ||
                    holder != null ||
                    expirationDate != null) {
                    CreditCard cc;
                    cc = (CreditCard) AbstractTypeFactory.newInstance(CreditCard.class);
                    cc.setAccountNumber(accountNumber);
                    cc.setIssuer(issuer);
                    cc.setType(type);
                    cc.setHolder(holder);
                    cc.setExpirationDate(expirationDate);
                    acct.setCreditCard(cc);
                }
            } else {
                logger.info("Account '" + accountName + "' not in DB");
            }
        } catch (final FactoryException ex) {
            logger.log(Level.SEVERE, 
                       "Unable to instantiate required classes, null will be returned.", ex);
        } catch (final SQLException ex) {
            logger.log(Level.SEVERE, "Unable to retrieve values for account.", ex);
        } catch (final AccountException ex) {
            logger.log(Level.SEVERE, "Unable to initialize account.", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (final SQLException e) {
                    logger.log(Level.WARNING, "Attempt to close resultset failed.", e);
                }
            }
        }

        return acct;
    }

    /**
     * Adds or updates an account.
     *
     * @param account the account to add/update
     *
     * @exception AccountException if operation fails
     */
    public void setAccount(final Account account) throws AccountException {
        try {
            int paramNdx = 1;
            accountInsertUpdate.setString(paramNdx++, account.getName());
            accountInsertUpdate.setBytes(paramNdx++, account.getPasswordHash());
            accountInsertUpdate.setInt(paramNdx++, account.getBalance());
            accountInsertUpdate.setString(paramNdx++, account.getFullName());
            accountInsertUpdate.setString(paramNdx++, account.getPhone());
            accountInsertUpdate.setString(paramNdx++, account.getEmail());

            final Address addr = account.getAddress();

            if (addr != null) {
                accountInsertUpdate.setString(paramNdx++, addr.getStreetAddress());
                accountInsertUpdate.setString(paramNdx++, addr.getCity());
                accountInsertUpdate.setString(paramNdx++, addr.getState());
                accountInsertUpdate.setString(paramNdx++, addr.getZipCode());
            } else {
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
            }

            final CreditCard cc = account.getCreditCard();

            if (cc != null) {
                accountInsertUpdate.setString(paramNdx++, cc.getAccountNumber());
                accountInsertUpdate.setString(paramNdx++, cc.getIssuer());
                accountInsertUpdate.setString(paramNdx++, cc.getType());
                accountInsertUpdate.setString(paramNdx++, cc.getHolder());
                accountInsertUpdate.setString(paramNdx++, cc.getExpirationDate());
            } else {
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
                accountInsertUpdate.setString(paramNdx++, null);
            }

            accountInsertUpdate.executeUpdate();
        } catch (final SQLException ex) {
            throw new AccountException("Insertion/update of account failed.", ex);
        }

    }

    /**
     * Remove the account.
     *
     * @param accountName the name of the account to remove
     *
     * @exception AccountException if operation fails
     */
    public void deleteAccount(final String accountName) throws AccountException
    {
        final Account acct = null;

        try {
            accountDelete.setString(1, accountName);
            accountDelete.executeUpdate();
        } catch (final SQLException ex) {
            throw new AccountException("Account deletion failed", ex);
        }
    }

    /**
     * Remove all accounts.  This is primarily available to facilitate testing.
     *
     * @exception AccountException if operation fails
     */
    public void reset() throws AccountException {
        final Account acct = null;

        Statement stmnt = null;
        try {
            stmnt = connection.createStatement();
            stmnt.executeUpdate(RESET_ACCOUNTS);
        } catch (final SQLException ex) {
            throw new AccountException("Database deletion failed", ex);
        } finally {
            if (null != stmnt) {
                try {
                    stmnt.close();
                } catch (final SQLException e) {
                    logger.log(Level.WARNING, "Attempt close statement failed.", e);
                }
            }
        }
    }

    /**
     * Close the DAO.
     */
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (final SQLException ex) {
                logger.log(Level.WARNING, "Db connection close failed.", ex);
            } finally {
                connection = null;
                logger.info("Db connection closed.");
            }
        }
    }
}

