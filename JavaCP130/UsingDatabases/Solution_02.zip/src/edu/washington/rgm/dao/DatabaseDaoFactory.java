package edu.washington.rgm.dao;

import edu.washington.ext.cp130.framework.dao.AccountDao;
import edu.washington.ext.cp130.framework.dao.DaoFactory;
import edu.washington.ext.cp130.framework.dao.DaoFactoryException;


/**
 * A DaoFactory implementation that instantiates a DatabaseAccountDao.
 *
 * @author Russ Moul
 */
public final class DatabaseDaoFactory implements DaoFactory {
    /**
     * Instantiates a new DatabaseAccountDao object.
     *
     * @return a newly instantiated DatabaseAccountDao object
     * @throws DaoFactoryException if unable to initialize the DAO
     */
    public AccountDao getAccountDao() throws DaoFactoryException {
        return new DatabaseAccountDao();
    }
}

