package edu.washington.rgm.broker;

import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.broker.Broker;
import edu.washington.ext.cp130.framework.broker.BrokerFactory;
import edu.washington.ext.cp130.framework.exchange.StockExchange;


/**
 *
 * Implementations of this class must provide a no argument constructor.
 *
 * @author Russ Moul
 */
public final class ExecutorBrokerFactory implements BrokerFactory {
    /**
     * Instantiates a new SimpleBroker.
     *
     * @param name the broker's name
     * @param acctMngr the account manager to be used by the broker
     * @param exch the exchange to be used by the broker
     *
     * @return a newly created SimpleBroker instance
      */
    public Broker newBroker(final String name, final AccountManager acctMngr,
                            final StockExchange exch) {
        return new ExecutorBroker(name, acctMngr, exch);
    }
}

