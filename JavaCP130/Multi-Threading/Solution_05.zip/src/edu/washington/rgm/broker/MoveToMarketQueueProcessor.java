package edu.washington.rgm.broker;

import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.broker.OrderProcessor;
import edu.washington.ext.cp130.framework.broker.OrderQueue;
import edu.washington.ext.cp130.framework.order.Order;

/**
 * Moves orders to a brokers market order queue.
 *
 * @author Russ Moul
 */
public final class MoveToMarketQueueProcessor implements OrderProcessor {
    /** The class' logger */
    private static final Logger log =
                         Logger.getLogger(MoveToMarketQueueProcessor.class.getName());

    /** The  market queue */
    private OrderQueue<Order> marketQueue;

    /**
     * Constructor.
     *
     * @param marketQueue the queue the orders will be moved to
     */
    public MoveToMarketQueueProcessor(final OrderQueue<Order> marketQueue) {
        this.marketQueue = marketQueue;
    }

    /**
     * Enques the order into the market order queue.
     *
     * @param order the order to process
     */
    public void process(final Order order) {
        log.info("### Moving order to market queue: " + order);
        marketQueue.enqueue(order);
    }
}

