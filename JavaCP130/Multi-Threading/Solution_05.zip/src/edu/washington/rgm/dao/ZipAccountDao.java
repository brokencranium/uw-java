package edu.washington.rgm.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.Address;
import edu.washington.ext.cp130.framework.account.CreditCard;
import edu.washington.ext.cp130.framework.dao.AccountDao;


/**
 * An AccountDao that persists the account information in a ZIP file.
 *
 * @author Russ Moul
 */
public final class ZipAccountDao implements AccountDao {
    /** The name of the persistence file */
    public static final String ZIP_FILENAME = "accounts.zip";

    /** The name of the file holding the account data */
    private static final String ACCOUNT_FILENAME = "account.dat";

    /** The name of the file holding the address data */
    private static final String ADDRESS_FILENAME = "address.properties";

    /** The name of the file holding the credit card data */
    private static final String CREDITCARD_FILENAME = "creditcard.txt";

    /** Internal storage for the account information */
    private HashMap<String, Account> accountMap = new HashMap<String, Account>();

    /**
     * Creates an instance of this class and loads the account data.
     *
     * @throws AccountException if an error occurs during the load operation
     */
    public ZipAccountDao() throws AccountException {
        load();
    }

    /**
     * Lookup an account in the HashMap based on username.
     *
     * @param accountName the name of the desired account
     *
     * @return the account if located otherwise null
     */
    public Account getAccount(final String accountName) {
        return accountMap.get(accountName);
    }

    /**
     * Adds or updates an account.
     *
     * @param account the account to add/update
     *
     * @exception AccountException if operation fails
     */
    public void setAccount(final Account account) throws AccountException {
        accountMap.put(account.getName(), account);
        store();
    }

    /**
     * Remove the account.
     *
     * @param accountName the name of the account to remove
     *
     * @exception AccountException if operation fails
     */
    public void deleteAccount(final String accountName) throws AccountException
    {
        accountMap.remove(accountName);
        store();
    }

    /**
     * Remove all accounts.  This is primarily available to facilitate testing.
     *
     * @exception AccountException if operation fails
     */
    public void reset() throws AccountException {
        accountMap.clear();
        store();
    }

    /**
     * Load all the accounts from disk, just deserialize the HashMap
     *
     * @exception AccountException if unable to load the serialized data
     */
    private void load() throws AccountException {
        accountMap.clear();

        final File f = new File(ZIP_FILENAME);

        if (f.exists()) {

            try {
                final ZipFile zf = new ZipFile(f);
                final Enumeration<? extends ZipEntry> enm = zf.entries();
                ZipEntry entry = null;
                Account currAcct = null;
                while (enm.hasMoreElements()) {
                    InputStream in;
                    entry = enm.nextElement();
                    final String entryName = entry.getName();
                    if (entryName.endsWith(ACCOUNT_FILENAME)) {
                        in = zf.getInputStream(entry);
                        currAcct = AccountSer.read(in);
                        accountMap.put(currAcct.getName(), currAcct);
                        in.close();
                    } else if (entryName.endsWith(ADDRESS_FILENAME)) {
                        in = zf.getInputStream(entry);
                        final Address addr = AddressSer.read(in);
                        currAcct.setAddress(addr);
                        in.close();
                    } else if (entryName.endsWith(CREDITCARD_FILENAME)) {
                        in = zf.getInputStream(entry);
                        final CreditCard card = CreditCardSer.read(in);
                        currAcct.setCreditCard(card);
                        in.close();
                    }
                }

                zf.close();
            } catch (final IOException ex) {
                throw new AccountException("Unable to open or read ZIP file, "
                                         + f.getAbsolutePath(), ex);
            }
        }
    }

    /**
     * Store all the accounts to disk - just serialize the HashMap.
     *
     * @exception AccountException if unable to serialize the data to file
     */
    private void store() throws AccountException {
        try {
            final File f = new File(ZIP_FILENAME);

            if (f.exists()) {
                final boolean deleted = f.delete();
                if (!deleted) {
                    Logger.getLogger(this.getClass().getName())
                          .warning("Unable to delete file, " + ZIP_FILENAME);
                }
            }

            if (accountMap.size() > 0) {
                final FileOutputStream out = new FileOutputStream(f);
                final ZipOutputStream zos = new ZipOutputStream(out);

                for (Account acct : accountMap.values()) {
                    final Address address = acct.getAddress();
                    final CreditCard card = acct.getCreditCard();

                    final String dirName = acct.getName() + "/";

                    final ZipEntry acctFile = new ZipEntry(dirName + ACCOUNT_FILENAME);
                    zos.putNextEntry(acctFile);
                    AccountSer.write(zos, acct);
                    zos.closeEntry();

                    if (address != null) {
                        final ZipEntry addrFile = new ZipEntry(dirName + ADDRESS_FILENAME);
                        zos.putNextEntry(addrFile);
                        AddressSer.write(zos, address);
                        zos.closeEntry();
                    }

                    if (card != null) {
                        ZipEntry ccFile;
                        ccFile = new ZipEntry(dirName + CREDITCARD_FILENAME);
                        zos.putNextEntry(ccFile);
                        CreditCardSer.write(zos, card);
                        zos.closeEntry();
                    }
                }

                zos.close();
            }

        } catch (final IOException ex) {
            throw new AccountException("Unable to store account.", ex);
        }
    }

    /**
     * Close the DAO.  Releases the internal storage.
     */
    public void close() {
        accountMap = null;
    }
}

