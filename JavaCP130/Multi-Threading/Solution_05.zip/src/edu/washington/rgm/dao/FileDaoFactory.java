package edu.washington.rgm.dao;

import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.dao.AccountDao;
import edu.washington.ext.cp130.framework.dao.DaoFactory;
import edu.washington.ext.cp130.framework.dao.DaoFactoryException;


/**
 * Implementation of DaoFactory that creates a FileAccountDao instance.
 *
 * @author Russ Moul
 */
public final class FileDaoFactory implements DaoFactory {
    /**
     * Instantiates an instance of FileAccountDao.
     *
     * @return a new instance of FileAccountDao
     *
     * @throws DaoFactoryException if instantiation fails
     */
    public AccountDao getAccountDao() throws DaoFactoryException {
        try {
            return new FileAccountDao();
        } catch (final AccountException ex) {
            throw new DaoFactoryException(
                  "Instantiation of FileAccountDao failed.", ex);
        }
    }
}

