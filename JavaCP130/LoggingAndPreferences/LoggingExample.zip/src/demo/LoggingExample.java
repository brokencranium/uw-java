package demo;

import java.util.logging.Logger;
import java.util.logging.LogManager;

/**
 * Application to demonstrate the use of logging, simply invokes methods on the
 * DemoClass which causes log entries to be printed.
 */
public class LoggingExample {
   public void aMethod() {
       Logger logger = Logger.getLogger("demo.LoggingExample");
       logger.info("Message from LoggingExample.aMethod.");
   }

   public static final void main(String[] args) {
       LoggingExample le = new LoggingExample();
       le.aMethod();

       DemoClass dc = new DemoClass();
       dc.aMethod();
       dc.anotherMethod();
   }

   
}
