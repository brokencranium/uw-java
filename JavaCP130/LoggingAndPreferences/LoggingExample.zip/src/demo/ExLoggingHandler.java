package demo;

import java.util.logging.Filter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.LogRecord;
import java.util.logging.LogManager;
import java.util.logging.Formatter;
import java.util.logging.SimpleFormatter;


/**
 * Writes log messages to stderr, prefacing it with the string "[*] " so the 
 * message can be distinguished from those written by the ConsoleHandler.
 * <br>
 * <b>Configuration:</b> By default each ExLoggingHandler is initialized using
 * the following LogManager configuration properties. If properties are not
 * defined (or have invalid values) then the specified default values are used. 
 * <ul>
 *   <li>demo.ExLoggingHandler.level specifies the default level for the Handler
 *       (defaults to Level.INFO). 
 *   <li>demo.ExLoggingHandler.filter specifies the name of a Filter class to
 *       use (defaults to no Filter). 
 *   <li>demo.ExLoggingHandler.formatter specifies the name of a Formatter class
 *       to use (defaults to java.util.logging.SimpleFormatter). 
 * </ul>
 *
 * @author Russ Moul
 */
public final class ExLoggingHandler extends Handler {
    /** The name of the property used to specifier a filter. */
    public static final String FILTER_PROPERTY_NAME =
                               "demo.ExLoggingHandler.filter";

    /** The name of the property used to specifier a formatter. */
    public static final String FORMATTER_PROPERTY_NAME =
                               "demo.ExLoggingHandler.formatter";

    /** The name of the property used to specifier a level. */
    public static final String LEVEL_PROPERTY_NAME =
                               "demo.ExLoggingHandler.level";

    /**
     * Constructor.  Initializes handler properties from the configuration file.
     */
    public ExLoggingHandler() {
        LogManager m = LogManager.getLogManager();
        String prop;

        prop = m.getProperty(FORMATTER_PROPERTY_NAME);
        if (prop != null) {
            try {
                setFormatter((Formatter)Class.forName(prop).newInstance());
            } catch (Exception ex) {
                Logger.getAnonymousLogger().info(
                          "Invalid logging formatter class specified: " + prop);
                setFormatter(new SimpleFormatter());
            }
        } else {
            setFormatter(new SimpleFormatter());
        }

        prop = m.getProperty(FILTER_PROPERTY_NAME);
        if (prop != null) {
            try {
                setFilter((Filter)Class.forName(prop).newInstance());
            } catch (Exception ex) {
                Logger.getAnonymousLogger().info(
                          "Invalid logging filter class specified: " + prop);
            }
        }

        Level level = Level.INFO;
        try {
            prop = m.getProperty(LEVEL_PROPERTY_NAME);
            if (prop != null) {
                level = Level.parse(prop);
            }
        } catch (Exception ex) {
            Logger.getAnonymousLogger().info(
                   "Invalid logging level specified: " + prop);
        } finally {
            setLevel(level);
        }
    }

    /**
     * This is a no-op in this implementation.
     */
    public void close() {
    }

    /**
     * This is a no-op in this implementation.
     */
    public void flush() {
    }

    /**
     * Writes the formatted log record to stderr.  If a filter is registered if
     * will be invoked to determine if the record should be logged, after the 
     * level is checked.
     *
     * @param rec inserts the log record into the database
     */
    public void publish(final LogRecord rec) {
        int levelInt = getLevel().intValue();
        int recLevelInt = rec.getLevel().intValue();
        if (recLevelInt < levelInt) {
            return;
        }
        Filter filter = getFilter();
        if (filter != null && !filter.isLoggable(rec)) {
            return;
        }
        Formatter f = getFormatter();
        System.err.println("[*] " + f.format(rec));
    }
}

