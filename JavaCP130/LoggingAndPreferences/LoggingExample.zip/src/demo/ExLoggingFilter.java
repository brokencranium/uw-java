package demo;

import java.util.logging.Filter;
import java.util.logging.LogRecord;


/**
 * A filter to exclude logging of messages originating from methods named
 * "anotherMethod".
 *
 * @author Russ Moul
 */
public final class ExLoggingFilter implements Filter {
    /**
     * Constructor.
     */
    public ExLoggingFilter() {
    }

    /**
     * Determine if a record should be logged.  Records originating in a
     * method named "anotherMethod" will not be logged, all others will be.
     *
     * @param record the log record to be accepted or rejected
     *
     * @return true if the record is to be logged, otherwise false
     */
    public boolean isLoggable(LogRecord record) {
       String methodName = record.getSourceMethodName();
       if (methodName != null && methodName.equals("anotherMethod")) {
           return false;
       }
       return true;
    }
}

