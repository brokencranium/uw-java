package demo;

import java.util.logging.Logger;
import java.util.logging.LogManager;

/**
 * A who's sole purpose it to log messages, to demonstrate logging.
 *
 * @author Russ Moul
 */
public class DemoClass {
    /** This class' logger. */
    private static Logger logger = Logger.getLogger("demo.DemoClass");

    /**
     * Logs a message, "Message from DemoClass.aMethod" at both the INFO and
     * FINER logging levels.
     */
    public void aMethod() {
        logger.info("Message from DemoClass.aMethod.");
        logger.finer("Message from DemoClass.aMethod.");
    }

    /**
     * Logs a message, "Message from DemoClass.anotherMethod" at both the INFO
     * and FINER logging levels.
     */
    public void anotherMethod() {
        logger.info("Message from DemoClass.anotherMethod.");
        logger.finer("Message from DemoClass.anotherMethod.");
    }
}
