package edu.washington.rgm.dao;

import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.dao.AccountDao;
import edu.washington.ext.cp130.framework.dao.DaoFactory;
import edu.washington.ext.cp130.framework.dao.DaoFactoryException;


/**
 * Implementation of DaoFactory that creates a ZipAccountDao instance.
 *
 * @author Russ Moul
 */
public final class ZipDaoFactory implements DaoFactory {
    /**
     * Instantiates an instance of ZipAccountDao.
     *
     * @return a new instance of ZipAccountDao
     *
     * @throws DaoFactoryException if instantiation fails
     */
    public AccountDao getAccountDao() throws DaoFactoryException {
        try {
            return new ZipAccountDao();
        } catch (final AccountException ex) {
            throw new DaoFactoryException(
                    "Instantiation of ZipAccountDao failed.", ex);
        }
    }

    /**
     * The factory could support multiple DAO interfaces.
     */
    //public abstract OrderDao getOrderDao()
    //throws DaoFactoryException;
}

