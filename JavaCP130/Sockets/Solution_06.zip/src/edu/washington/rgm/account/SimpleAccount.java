package edu.washington.rgm.account;

import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.Preferences;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.account.Address;
import edu.washington.ext.cp130.framework.account.CreditCard;
import edu.washington.ext.cp130.framework.order.Order;


/**
 * Implementation of the Account interface as a JavaBean.
 *
 * @author Russ Moul
 */
public final class SimpleAccount implements Account, Serializable {

    /** Version id */
    private static final long serialVersionUID = 9028406835809215441L;

    /** The logger to be used by this class */
    private static final Logger logger = Logger.getLogger(SimpleAccount.class.getName());

    /** The minimum allowed account length */
    private static int minAcctLen;

    /** The minimum allowed initial account balance */
    private static int minAcctBal;

    static {
        final Preferences prefs = Preferences.userNodeForPackage(Account.class);
        minAcctLen = prefs.getInt("minAccountLength", 0);
        minAcctBal = prefs.getInt("minAccountBalance", 0);
        logger.info("minAccountLength " + minAcctLen);
        logger.info("minAccountBalance " + minAcctBal);
    }

    /** The account name */
    private String name;

    /** The hashed account password */
    private byte[] passwordHash;

    /** The account balance, in cents. */
    private int balance = Integer.MIN_VALUE;

    /** The account holders full name */
    private String fullName;

    /** The account holders address */
    private Address address;

    /** The account holders phone number */
    private String phone;

    /** The account holders email address */
    private String email;

    /** The account holders credit card */
    private CreditCard creditCard;

    /** Account manager responsible for managing this account */
    private transient AccountManager acctMngr;

    /**
     * No parameter constructor, required by JavaBeans.
     */
    public SimpleAccount() {
    }

    /**
     * Constructor, validates length of account name and the balance based on
     * the preferences,
     * edu.washington.ext.cp130.account.SimpleAccount.minAccountLength and
     * edu.washington.ext.cp130.account.SimpleAccount.minAccountBalance
     * respectively.
     *
     * @param acctName the account name
     * @param passwordHash the password hash
     * @param balance the balance
     *
     * @throws AccountException if the account name is too short or balance
     *                          too low
     */
    public SimpleAccount(final String acctName, final byte[] passwordHash,
                         final int balance)
        throws AccountException {
        if (!editAccountName(acctName)) {
            final String msg = "Account creation failed for , account '" + acctName
                             + "' invalid account name";
            logger.warning(msg);
            throw new AccountException(msg);
        }

        if (balance < minAcctBal) {
            final String msg = "Account creation failed for , account '" + acctName
                             + "' minimum balance not met, " + balance;
            logger.warning(msg);
            throw new AccountException(msg);
        }

        name = acctName;
        final byte[] copy = new byte[passwordHash.length];
        System.arraycopy(passwordHash, 0, copy, 0, passwordHash.length);
        this.passwordHash = copy;
        this.balance = balance;
    }

    /**
     * Get the account name.
     *
     * @return the name of the account
     */
    public String getName() {
        return name;
    }

    /**
     * Edits the account name.
     *
     * @param acctName the value to be edited
     *
     * @return true if the provided value is acceptable
     */
    private boolean editAccountName(final String acctName) {
        return (acctName != null) && (acctName.length() >= minAcctLen);
    }

    /**
     * Sets the account name.  The name will be checked for minimum length based
     * on the edu.washington.ext.cp130.account.SimpleAccount.minAccountLength
     * preference entry.
     *
     * This operation is not generally used but is provided for JavaBean
     * conformance.
     *
     * @param acctName the value to be set for the account name
     *
     * @throws AccountException if the account name is to short
     */
    public void setName(final String acctName) throws AccountException {
        if (!editAccountName(acctName)) {
            final String msg = "Account name '" + acctName + "' is unacceptable.";
            logger.warning(msg);
            throw new AccountException(msg);
        }

        name = acctName;
    }

    /**
     * Gets the hashed password.
     *
     * @return the hashed password
     */
    public byte[] getPasswordHash() {
        byte[] copy = null;
        if (passwordHash != null) {
            copy = new byte[passwordHash.length];
            System.arraycopy(passwordHash, 0, copy, 0, passwordHash.length);
        }
        return copy;
    }

    /**
     * Sets the hashed password.
     *
     * @param passwordHash the value to be set for the password hash
     */
    public void setPasswordHash(final byte[] passwordHash) {
        byte[] copy = null;
        if (passwordHash != null) {
            copy = new byte[passwordHash.length];
            System.arraycopy(passwordHash, 0, copy, 0, passwordHash.length);
        }
        this.passwordHash = copy;
    }

    /**
     * Gets the account balance.
     *
     * @return the current balance of the account
     */
    public int getBalance() {
        return balance;
    }

    /**
     * Sets the account balance.
     *
     * @param balance the value to set the balance to
     */
    public void setBalance(final int balance) {
        this.balance = balance;
    }

    /**
     * Gets the full name of the account holder.
     *
     * @return the account holders full name
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Sets the full name of the account holder.
     *
     * @param fullName the account holders full name
     */
    public void setFullName(final String fullName) {
        this.fullName = fullName;
    }

    /**
     * Gets the account address.
     *
     *  @return the accounts address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the account address.
     *
     *  @param address the address for the account
     */
    public void setAddress(final Address address) {
        this.address = address;
    }

    /**
     * Gets the phone number.
     *
     * @return the phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets the account phone number.
     *
     * @param phone value for the account phone number
     */
    public void setPhone(final String phone) {
        this.phone = phone;
    }

    /**
     * Gets the email address.
     *
     * @return the email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the account email address.
     *
     * @param email the email address
     */
    public void setEmail(final String email) {
        this.email = email;
    }

    /**
     * Gets the account credit card.
     *
     * @return the credit card
     */
    public CreditCard getCreditCard() {
        return creditCard;
    }

    /**
     * Sets the account credit card.
     *
     * @param card the value to be set for the credit card
     */
    public void setCreditCard(final CreditCard card) {
        creditCard = card;
    }

    /**
     * Sets the account manager responsible for persisting/managing this
     * account. This may be invoked exactly once on any given account, any
     * subsequent invocations should be ignored.
     *
     * @param m the account manager
     */
    public void registerAccountManager(final AccountManager m) {
        if (acctMngr == null) {
            acctMngr = m;
        } else {
            logger.info("Attempting to set the account manager, after it has been initialized.");
        }
    }

    /**
     * Incorporates an the effect of an order in the balance.  Increments or
     * decrements the account balance by the execution price * number of shares
     * in the order and then persists the account, using the account manager.
     *
     * @param order the order to be reflected in the account
     * @param executionPrice the price the order was executed at
     */
    public void reflectOrder(final Order order, final int executionPrice) {
        try {
            balance += order.valueOfOrder(executionPrice);
            if (acctMngr != null) {
                acctMngr.persist(this);
            } else {
                logger.log(Level.SEVERE, "Account manager has not been initialized.",
                           new Exception());
            }
        } catch (final AccountException ex) {
            logger.log(Level.SEVERE, "Failed to persist account " + name
                                   + " after adjusting for order.", ex);
        }
    }
}

