package edu.washington.rgm.broker;

import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.broker.OrderDispatchFilter;
import edu.washington.ext.cp130.framework.order.Order;

/**
 * Dispatch filter that dispatches orders as long as the market is open.  The
 * threshold object will be a Boolean object indicating the state of the market.
 *
 * @author Russ Moul
 */
public final class MarketDispatchFilter
             extends OrderDispatchFilter<Boolean, Order> {

    /** This class' logger. */
    private static final Logger log =
                         Logger.getLogger(MarketDispatchFilter.class.getName());

    /**
     * Constructor.
     *
     * @param initState the initial state of the market.
     */
    public MarketDispatchFilter(final boolean initState) {
        setThreshold(initState);
    }

    /**
     * Test if the order may be dispatched, all orders are dispatchable if the
     * market is open.
     *
     * @param order the order to be tested for dispatch
     *
     * @return true if the market is open, the threshold is object is
     *         Boolean.true
     */
    public boolean check(final Order order) {
        log.fine("Market order is dispatchable: "
               + getThreshold().booleanValue());

        return getThreshold();
    }
}

