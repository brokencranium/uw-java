package edu.washington.rgm.broker;

import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.broker.OrderProcessor;
import edu.washington.ext.cp130.framework.order.Order;
import edu.washington.ext.cp130.framework.exchange.StockExchange;

/**
 * OrderProcessor implementation that executes orders through the broker.
 *
 * @author Russ Moul
 */
public final class StockTraderOrderProcessor implements OrderProcessor {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(StockTraderOrderProcessor.class.getName());

    /** The account manager managing the accounts */
    private AccountManager acctMgr;
    /** The exchange used to execute trades */
    private StockExchange exchange;

    /**
     * Constructor.
     *
     * @param acctMgr the account manager to be used to update account balances.
     * @param exchange the exchange to be used for the execution of orders
     */
    public StockTraderOrderProcessor(final AccountManager acctMgr,
                                     final StockExchange exchange) {
        this.acctMgr = acctMgr;
        this.exchange = exchange;
    }

    /**
     * Executes the order using the exchange.
     *
     * @param order the order to process
     */
    public void process(final Order order) {
        logger.info("Executing-: " + order);

        final int sharePrice = exchange.executeTrade(order);

        try {
            final Account acct = acctMgr.getAccount(order.getAccountId());
            acct.reflectOrder(order, sharePrice);
        } catch (final AccountException ex) {
            logger.log(Level.SEVERE,
                       "Unable to update account, " + order.getAccountId(), ex);
        }
    }
}

