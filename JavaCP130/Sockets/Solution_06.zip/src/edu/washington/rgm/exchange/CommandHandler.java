package edu.washington.rgm.exchange;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.exchange.StockExchange;
import edu.washington.ext.cp130.framework.exchange.StockQuote;
import edu.washington.ext.cp130.framework.order.MarketBuyOrder;
import edu.washington.ext.cp130.framework.order.MarketSellOrder;
import edu.washington.ext.cp130.framework.order.Order;

/**
 * An instance of this class is dedicated to executing commands received
 * from clients.
 */
final class CommandHandler implements Runnable {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(CommandHandler.class.getName());

    /** The socket the command was received on */
    private Socket socket;

    /** The 'real' exchange this adapter delegates to */
    private StockExchange realExchange;

    /**
     * Constructor.
     *
     * @param sock the socket for communication with the client
     * @param realExchange the "real" exchange to dispatch commands to
     */
    public CommandHandler(final Socket sock, final StockExchange realExchange) {
        socket = sock;
        this.realExchange = realExchange;
    }

    /**
     * Processes the command.
     */
    public void run() {
        InputStream inStrm = null;
        OutputStream outStrm = null;

        try {
            inStrm = socket.getInputStream();
            final Reader rdr = new InputStreamReader(inStrm);
            final BufferedReader br = new BufferedReader(rdr);

            outStrm = socket.getOutputStream();
            final Writer wrtr = new OutputStreamWriter(outStrm, ProtocolConstants.ENCODING);
            final PrintWriter prntWrtr = new PrintWriter(wrtr, true);

            String msg = br.readLine();
            if (null == msg) {
                msg = "";
            }
            final String[] elements = msg
                           .split(ProtocolConstants.ELEMENT_DELIMITER);
            final ProtocolConstants cmd = ProtocolConstants
                        .valueOf(elements[ProtocolConstants.CMD_ELEMENT]);

            // Dispatch command
            logger.info("Processing command: '" + cmd + "'");
            String ticker = null;
            int price = 0;
            switch (cmd) {
                case GET_STATE_CMD:
                    final String response = realExchange.isOpen() ? ProtocolConstants.OPEN_STATE
                                                                  : ProtocolConstants.CLOSED_STATE;
                    prntWrtr.println(response);
                    break;

                case GET_QUOTE_CMD:
                    ticker = elements[ProtocolConstants.QUOTE_CMD_TICKER_ELEMENT];
                    final StockQuote quote = realExchange.getQuote(ticker);
                    price = (quote == null) ? ProtocolConstants.INVALID_STOCK
                                            : quote.getPrice();
                    prntWrtr.println(price);
                    break;

                case GET_TICKERS_CMD:
                    final String[] tickers = realExchange.getTickers();
                    final StringBuilder buf = new StringBuilder();

                    for (int i = 0; i < tickers.length; i++) {
                        if (tickers[i] != null) {
                            if (i > 0) {
                                buf.append(ProtocolConstants.ELEMENT_DELIMITER);
                            }

                            buf.append(tickers[i]);
                        }
                    }

                    prntWrtr.println(buf.toString());
                    break;

                case EXECUTE_TRADE_CMD:
                    if (realExchange.isOpen()) {
                        final String orderType = elements[ProtocolConstants.EXECUTE_TRADE_CMD_TYPE_ELEMENT];
                        final String acctId = elements[ProtocolConstants.EXECUTE_TRADE_CMD_ACCOUNT_ELEMENT];
                        ticker = elements[ProtocolConstants.EXECUTE_TRADE_CMD_TICKER_ELEMENT];
                        final String shares = elements[ProtocolConstants.EXECUTE_TRADE_CMD_SHARES_ELEMENT];
                        int qty = -1;

                        try {
                            qty = Integer.parseInt(shares);
                        } catch (final NumberFormatException ex) {
                            logger.log(Level.WARNING,
                                       "String to int conversion failed: '"
                                      + shares + "'", ex);
                        }

                        Order order;

                        if (ProtocolConstants.BUY_ORDER.equals(orderType)) {
                            order = new MarketBuyOrder(acctId, qty, ticker);
                        } else {
                            order = new MarketSellOrder(acctId, qty, ticker);
                        }

                        price = realExchange.executeTrade(order);
                        prntWrtr.println(price);
                    } else {
                        prntWrtr.println(0);
                    }
                    break;

                default:
                    logger.severe("Unrecognized command: " + cmd);
                    break;
            }
        } catch (final IOException ex) {
            logger.log(Level.SEVERE, "Error sending response", ex);
        } finally {
            try {
                if (inStrm != null) {
                    inStrm.close();
                }
            } catch (final IOException ioex) {
                logger.log(Level.INFO, "Error closing input stream.", ioex);
            }

            try {
                if (outStrm != null) {
                    outStrm.close();
                }
            } catch (final IOException ioex) {
                logger.log(Level.INFO, "Error closing output stream.", ioex);
            }

            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (final IOException ioex) {
                logger.log(Level.INFO, "Error closing socket.", ioex);
            }
        }
    }
}
