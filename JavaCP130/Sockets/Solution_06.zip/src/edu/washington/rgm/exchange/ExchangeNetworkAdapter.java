package edu.washington.rgm.exchange;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.exchange.ExchangeAdapter;
import edu.washington.ext.cp130.framework.exchange.ExchangeEvent;
import edu.washington.ext.cp130.framework.exchange.StockExchange;


/**
 * Provides a network interface to an exchange.
 *
 * @author Russ Moul
 */
public final class ExchangeNetworkAdapter
        implements ExchangeAdapter {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(ExchangeNetworkAdapter.class.getName());

    /** The 'real' exchange this adapter delegates to */
    private StockExchange realExchange;

    /** The 'event' multicast port */
    private int multicastPort;

    /** The 'event' socket */
    private DatagramSocket eventSocket;

    /** Datagram packet used to multicast events. */
    private DatagramPacket datagramPacket;

    /** Thread for accepting connections to the command port */
    private CommandListener listenThread;

    /**
     * Constructor.
     *
     * @param exchng the exchange used to service the network requests
     * @param multicastIP the ip address used to propagate price changes
     * @param multicastPort the ip port used to propagate price changes
     * @param commandPort the ports for listening for commands
     *
     * @throws UnknownHostException if unable to resolve multicast IP address
     * @throws SocketException if an error occurs on a socket operation
     */
    public ExchangeNetworkAdapter(final StockExchange exchng,
                                  final String multicastIP,
                                  final int multicastPort,
                                  final int commandPort)
        throws UnknownHostException, SocketException {
        realExchange = exchng;
        this.multicastPort = multicastPort;

        // Use a  DatagramSocket - 'cause I can, a standard DatagramSocket can
        // send (but not receive) multicast datagrams
        eventSocket = new DatagramSocket();
        final InetAddress multicastGroup = InetAddress.getByName(multicastIP);
        final byte[] buf = {};
        datagramPacket = new DatagramPacket(buf, 0, multicastGroup, multicastPort);
        
        realExchange.addExchangeListener(this);

        listenThread = new CommandListener(commandPort, exchng);
        listenThread.start();
    }

    /**
     * The exchange has opened and prices are adjusting - add listener to
     * receive price change events from the exchange and multicast them to
     * brokers.
     *
     * @param event the event
     */
    public void exchangeOpened(final ExchangeEvent event) {
        logger.info("Exchange opening");

        final String msg = ProtocolConstants.OPEN_EVNT.toString();

        try {
            sendMulticastEvent(msg);
        } catch (final IOException ex) {
            logger.log(Level.SEVERE, "Error joining price change group:", ex);
        }
    }

    /**
     * The exchange has closed - notify clients and remove price change
     * listener.
     *
     * @param event the event
     */
    public void exchangeClosed(final ExchangeEvent event) {
        logger.info("Exchange closed");

        final String msg = ProtocolConstants.CLOSED_EVNT.toString();

        try {
            sendMulticastEvent(msg);
        } catch (final IOException ex) {
            logger.log(Level.INFO, "Error multicasting exchange closed", ex);
        }
    }

    /**
     * Processes price change events.
     *
     * @param event the event to be processed
     */
    public void priceChanged(final ExchangeEvent event) {
        final String symbol = event.getTicker();
        final int price = event.getPrice();
        final StringBuilder builder = new StringBuilder();
        builder.append(ProtocolConstants.PRICE_CHANGE_EVNT)
               .append(ProtocolConstants.ELEMENT_DELIMITER)
               .append(symbol)
               .append(ProtocolConstants.ELEMENT_DELIMITER)
               .append(price);
        final String msg = builder.toString();
        logger.info(msg);

        try {
            sendMulticastEvent(msg);
        } catch (final IOException ex) {
            logger.log(Level.SEVERE, "Error multicasting price change", ex);
        }
    }

    /**
     * Convenience method to write a buffer to the 'event' multicast socket.
     *
     * @param msg the event string message to write
     *
     * @throws IOException in the event of a network failure
     */
    private synchronized void sendMulticastEvent(final String msg) throws IOException {
        final byte[] buf = msg.getBytes(ProtocolConstants.ENCODING);
        datagramPacket.setData(buf);
        datagramPacket.setLength(buf.length);

        eventSocket.send(datagramPacket);
    }

    /**
     * Close the adapter.
     */
    public void close() {
        realExchange.removeExchangeListener(this);
        listenThread.terminate();
        eventSocket.close();
    }

}

