package edu.washington.rgm.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import java.util.logging.Logger;


/**
 * Writes LogRecords to a database. Formatters are ignored.
 *
 * @author Russ Moul
 */
public final class DbLoggingHandler extends Handler {
    /** This class' logger. */
    private static final Logger logger = Logger.getLogger(DbLoggingHandler.class.getName());

    /** The insert SQL. */
    private static final String SQL = "INSERT INTO log"
                                    + " (level, sequence, class, method, time, message)"
                                    + " VALUES (?, ?, ?, ?, ?, ?)";

    /** The database connection */
    private Connection conn;

    /** Database name */
    private String dbUrl;

    /** Database username */
    private String username;

    /** Database password */
    private String password;

    /** The prepared statement for executing the insert. */
    private PreparedStatement prepStmnt;

    /**
     * Constructor.  Initializes the database connection.
     */
    public DbLoggingHandler() {
        final LogManager logManager = LogManager.getLogManager();
        final String className = this.getClass().getName();

        String propName = className + ".driver";
        final String driverClassName = logManager.getProperty(propName);

        propName = className + ".url";
        dbUrl = logManager.getProperty(propName);

        propName = className + ".account";
        username = logManager.getProperty(propName);

        propName = className + ".password";
        password = logManager.getProperty(propName);

        if (logger.isLoggable(Level.FINE)) {
            logger.fine("Logging db info: driver class = " + driverClassName
                      + ", db URL = " + dbUrl
                      + ", username = " + username
                      + ", password = " + password);
        }
        try {
            Class.forName(driverClassName);
        } catch (final ClassNotFoundException e) {
            logger.log(Level.SEVERE, "Failed to load DB driver class: " + driverClassName , e);
        }
    }

    /**
     * This is a no-op in this implementation.
     */
    public void flush() {
        // could have internal cache and periodically write to DB
    }

    /**
     * Inserts the log record into the database.
     *
     * @param rec inserts the log record into the database
     */
    public void publish(final LogRecord rec) {
        if (isLoggable(rec)) {
            connect();
            try {
                int paramMarker = 1;
                prepStmnt.setString(paramMarker++, rec.getLevel().toString());
                prepStmnt.setLong(paramMarker++, rec.getSequenceNumber());
                prepStmnt.setString(paramMarker++, rec.getSourceClassName());
                prepStmnt.setString(paramMarker++, rec.getSourceMethodName());
                prepStmnt.setLong(paramMarker++, rec.getMillis());
                prepStmnt.setString(paramMarker++, rec.getMessage());
                prepStmnt.executeUpdate();
            } catch (final SQLException ex) {
                logger.log(Level.SEVERE, "Insert into logging DB failed.", ex);
            }
        }
    }

    /**
     * Check if this <tt>Handler</tt> would actually log a given <tt>LogRecord</tt>.
     * <p>
     * This method checks if the <tt>LogRecord</tt> has an appropriate level and
     * whether it satisfies any <tt>Filter</tt>.  It will return false if
     * the <tt>LogRecord</tt> is Null.
     * <p>
     * @param record  a <tt>LogRecord</tt>
     * @return true if the <tt>LogRecord</tt> would be logged.
     *
     */
    public boolean isLoggable(final LogRecord record) {
        boolean loggable;
        if (record == null) {
            loggable = false;
        } else {
            loggable =  super.isLoggable(record);
        }
        return loggable;
    }

    /**
     * Create the db connection.
     */
    private void connect() {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection(dbUrl, username, password);
                prepStmnt = conn.prepareStatement(SQL);
            } catch (final SQLException ex) {
                logger.log(Level.SEVERE, "Initialization of logging DB failed", ex);
            }
        }
    }

    /**
     * Closes the database connection.
     */
    public void close() {
        try {
            if (conn != null) {
                prepStmnt.close();
                conn.close();
            }
        } catch (final SQLException ex) {
            logger.log(Level.WARNING, "Attempt to close statement/connection failed", ex);
        }
        conn = null;
    }
}

