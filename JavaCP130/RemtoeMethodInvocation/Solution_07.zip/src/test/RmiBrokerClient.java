package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.Remote;

import edu.washington.ext.cp130.framework.broker.BrokerException;
import edu.washington.ext.cp130.framework.exchange.StockQuote;
import edu.washington.rgm.remote.RemoteBrokerGateway;
import edu.washington.rgm.remote.RemoteBrokerSession;


/**
 * Test driver for the first assignment.  Since there's so little functionality
 * in this application, there's not much to test since all the output goes to
 * standard out.
 *
 * @author Russ Moul
 */
public final class RmiBrokerClient {
    /** Price offset used when placing orders around the current price */
    private static final int PRICE_DELTA = 5;

    /** An order quantity of 10 */
    private static final int ORDER_QTY_10 = 10;

    /** An order quantity of 30 */
    private static final int ORDER_QTY_30 = 30;

    /** An order quantity of 250 */
    private static final int ORDER_QTY_250 = 250;

    /** An order quantity of 400 */
    private static final int ORDER_QTY_400 = 400;

    /** Initial account balance */
    private static final int INIT_BALANCE = 1000000;

    /** Boeing stock symbol */
    private static final String STOCK_SYMBOL_BA = "BA";

    /** Ford stock symbol */
    private static final String STOCK_SYMBOL_F = "F";

    /**
     * Prevent instantiation.
     */
    private RmiBrokerClient() {
    }

    /**
     * Initialize the broker client and start the test.
     *
     * @param args (not used)
     *
     * @throws NotBoundException remote object is not bound
     * @throws IOException if any are remote or other IO exceptions are raised
     */
    public static void main(final String[] args)
        throws IOException, NotBoundException {
        final String acctName = "fflintstone";
        final String acctPasswd = "password1";
        final int acctBal = INIT_BALANCE;

        final Remote remoteObj = Naming.lookup("//localhost/RTrade");
        final RemoteBrokerGateway gateway = (RemoteBrokerGateway) remoteObj;
        RemoteBrokerSession session;
        try {
            session = gateway.createAccount(acctName, acctPasswd, acctBal);

            session.placeMarketBuyOrder(STOCK_SYMBOL_F, ORDER_QTY_250);
            session.placeMarketSellOrder(STOCK_SYMBOL_F, ORDER_QTY_400);

            // get the price for BA
            StockQuote quote = session.requestQuote(STOCK_SYMBOL_BA);
            int price = quote.getPrice();

            // place orders around the price
            session.placeStopBuyOrder(STOCK_SYMBOL_BA, ORDER_QTY_10,
                                      price - PRICE_DELTA);
            session.placeStopSellOrder(STOCK_SYMBOL_BA, ORDER_QTY_30,
                                       price + PRICE_DELTA);

            // get the price for F
            quote = session.requestQuote(STOCK_SYMBOL_F);
            price = quote.getPrice();

            // place orders around the price
            session.placeStopBuyOrder(STOCK_SYMBOL_F, ORDER_QTY_10,
                                      price - PRICE_DELTA);
            session.placeStopSellOrder(STOCK_SYMBOL_F, ORDER_QTY_30,
                                       price + PRICE_DELTA);

            // login to the account
            session.close();
            session = gateway.login(acctName, acctPasswd);

            System.out.println();
            System.out.println("Account balance: " + session.getBalance());
            System.out.println();

            BufferedReader in;
            in = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("#");
            System.out.println("#");
            System.out.println("#");
            System.out.println(
                "# Press [Enter] to delete the account and continue");
            System.out.println(
                "# (may want to wait until submited orders are executed)");
            System.out.println("#");
            System.out.println("#");
            System.out.println("#");
            in.readLine();

            System.out.println();
            System.out.println("Account balance: " + session.getBalance());

            session.deleteAccount();
        } catch (final BrokerException be) {
            System.err.println("This was all expected to work.");
            be.printStackTrace(System.err);
        }

        try {
            gateway.login(acctName, acctPasswd);
            System.err.println("Error - Able to login to deleted account!");
            System.exit(1);
        } catch (final BrokerException rex) {
            // This is expected - the account has been deleted
            // Note that this is a domain/application exception
            System.out.println();
            System.out.println("Account sucessfully deleted");
            System.out.println();
        }

        System.out.println("Exiting...");
    }
}

