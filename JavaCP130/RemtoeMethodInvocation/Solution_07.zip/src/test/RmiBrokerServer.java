package test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.prefs.Preferences;

import edu.washington.ext.cp130.exchange.TestExchange;
import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.account.AccountManagerFactory;
import edu.washington.ext.cp130.framework.broker.Broker;
import edu.washington.ext.cp130.framework.broker.BrokerFactory;
import edu.washington.ext.cp130.framework.dao.AccountDao;
import edu.washington.ext.cp130.framework.dao.DaoFactory;
import edu.washington.ext.cp130.framework.exchange.NetworkExchangeProxyFactory;
import edu.washington.ext.cp130.framework.exchange.StockExchange;
import edu.washington.ext.cp130.util.AbstractTypeFactory;
import edu.washington.ext.cp130.util.FactoryException;
import edu.washington.rgm.remote.RemoteBrokerGatewayImpl;


/**
 * Test driver for the first assignment.  Since there's so little functionality
 * in this application, there's not much to test since all the output goes to
 * standard out.
 *
 * @author Russ Moul
 */
public final class RmiBrokerServer {
    /** Broker name. */
    private static final String BROKER_NAME = "RTrade";

    /** Symbol for BA (Boeing) */
    private static final String SYMBOL_BA = "BA";

    /** Initial price for BA (Boeing) */
    private static final int INITIAL_PRICE_BA = 3000;

    /** Below initial price for BA (Boeing) */
    private static final int BELOW_INITIAL_PRICE_BA = 2995;

    /** Above initial price for BA (Boeing) */
    private static final int ABOVE_INITIAL_PRICE_BA = 3005;

    /** Symbol for F (Ford) */
    private static final String SYMBOL_F = "F";

    /** Initial price for F (Ford) */
    private static final int INITIAL_PRICE_F = 4000;

    /** Above initial price for F (Ford) */
    private static final int ABOVE_INITIAL_PRICE_F = 4005;

    /** Symbol for GE (General Electric) */
    private static final String SYMBOL_GE = "GE";

    /** Initial price for GE (General Electric) */
    private static final int INITIAL_PRICE_GE = 3720;

    /** Symbol for GM (General Motors) */
    private static final String SYMBOL_GM = "GM";

    /** Initial price for GM (General Motors) */
    private static final int INITIAL_PRICE_GM = 4290;

    /** Symbol for HWP (Hewlett Packard) */
    private static final String SYMBOL_HWP = "HWP";

    /** Initial price for HWP (Hewlett Packard) */
    private static final int INITIAL_PRICE_HWP = 1605;

    /** Symbol for IBM (IBM) */
    private static final String SYMBOL_IBM = "IBM";

    /** Initial price for IBM (IBM) */
    private static final int INITIAL_PRICE_IBM = 9172;

    /** Symbol for MU (Micron Technology) */
    private static final String SYMBOL_MU = "MU";

    /** Initial price for MU (Micron Technology) */
    private static final int INITIAL_PRICE_MU = 1883;

    /** Symbol for PFE (PFIZER)*/
    private static final String SYMBOL_PFE = "PFE";

    /** Initial price for PFE (PFIZER)*/
    private static final int INITIAL_PRICE_PFE = 4010;

    /** Symbol for PG (Procter & Gamble) */
    private static final String SYMBOL_PG = "PG";

    /** Initial price for PG (Procter & Gamble) */
    private static final int INITIAL_PRICE_PG = 7279;

    /** Symbol for T (AT&T)*/
    private static final String SYMBOL_T = "T";

    /** Initial price for T (AT&T)*/
    private static final int INITIAL_PRICE_T = 1930;

    /** Default event port */
    private static final int EVENT_PORT = 5000;

    /** Default command port */
    private static final int COMMAND_PORT = 5001;

    /** Default naming port */
    private static final int NAMING_PORT = 1099;

    /**
     * Prevent instantiation.
     */
    private RmiBrokerServer() {
    }

    /**
     * Initialize the broker server and start the test.
     *
     * @param args (not used)
     *
     * @throws Exception if any are raised
     */
    public static void main(final String[] args) throws Exception {

        // initialize the factories
        final AccountManagerFactory accountManagerFactory = 
              AbstractTypeFactory.newInstance(AccountManagerFactory.class);

        final BrokerFactory mBrokerFactory = AbstractTypeFactory.newInstance(BrokerFactory.class);

        StockExchange exchange;
        // Using the network exchange
        //exchange = initNetworkExchange();

        //Using the test exchange
        exchange = initTestExchange();

        // create the account manager, dao, and broker
        final DaoFactory daoFact = AbstractTypeFactory.newInstance(DaoFactory.class);

        final AccountDao dao = daoFact.getAccountDao();
        dao.reset();

        final AccountManager acctMngr = accountManagerFactory.newAccountManager(dao);

        final Broker broker = mBrokerFactory.newBroker(BROKER_NAME, acctMngr, exchange);
        final RemoteBrokerGatewayImpl gateway;
        gateway = new RemoteBrokerGatewayImpl(broker);

        // locate or create a rmiregistry
        Registry reg = null;

        try {
            reg = LocateRegistry.createRegistry(NAMING_PORT);
            System.out.println("Using new Registry server");
        } catch (final RemoteException createEx) {
            System.out.println(
                "Can't create registry locating existing registry");

            try {
                reg = LocateRegistry.getRegistry();
                System.out.println("Using existing Registry server");
            } catch (final RemoteException locateEx) {
                System.out.println("Can't LocateRegistry");
                System.exit(1);
            }
        }

        // bind the remote object
        reg.rebind(BROKER_NAME, gateway);
        System.out.println("Broker is ready!");

        BufferedReader in;
        in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("#");
        System.out.println("#");
        System.out.println("#");
        System.out.println("# Press [Enter] to exit");
        System.out.println("#");
        System.out.println("#");
        System.out.println("#");
        in.readLine();
        System.out.println("Unexporting gateway object");
        reg.unbind(BROKER_NAME);
        UnicastRemoteObject.unexportObject(gateway, true);
    }

    /**
     * Initialize a NetworkExchangeProxy instance, if this fails a TestExchange
     * is returned.
     *
     * @return a TestExchange instance
     */
    private static StockExchange initNetworkExchange() {
        Preferences prefs;
        prefs = Preferences.userNodeForPackage(NetExchangeDriver.class);

        String eventIp;
        eventIp = prefs.get("eventIpAddress", "228.1.1.1");

        int eventPort;
        eventPort = prefs.getInt("eventPort", EVENT_PORT);

        String cmdIp;
        cmdIp = prefs.get("commandIpAddress", "127.0.0.1");

        final int cmdPort = prefs.getInt("commandPort", COMMAND_PORT);

        StockExchange exchange = null;
        try {
            final NetworkExchangeProxyFactory proxyFact =
                  AbstractTypeFactory.newInstance(NetworkExchangeProxyFactory.class);
            exchange = proxyFact.newProxy(eventIp, eventPort, cmdIp, cmdPort);
        } catch (final FactoryException ex) {
            System.err.println("Unable to initiaize NetworkExchangeProxy, using TestExchange.");
            ex.printStackTrace();
            exchange = initTestExchange();
        }
        return exchange;
    }

    /**
     * Initialize a TestExchange instance.
     *
     * @return a TestExchange instance
     */
    private static StockExchange initTestExchange() {
        final HashMap<String, Integer> stocks = new HashMap<String, Integer>();

        stocks.put(SYMBOL_BA, INITIAL_PRICE_BA);
        stocks.put(SYMBOL_F, INITIAL_PRICE_F);
        stocks.put(SYMBOL_GE, INITIAL_PRICE_GE);
        stocks.put(SYMBOL_GM, INITIAL_PRICE_GM);
        stocks.put(SYMBOL_HWP, INITIAL_PRICE_HWP);
        stocks.put(SYMBOL_IBM, INITIAL_PRICE_IBM);
        stocks.put(SYMBOL_MU, INITIAL_PRICE_MU);
        stocks.put(SYMBOL_PFE, INITIAL_PRICE_PFE);
        stocks.put(SYMBOL_PG, INITIAL_PRICE_PG);
        stocks.put(SYMBOL_T, INITIAL_PRICE_T);

        final TestExchange exchange = new TestExchange(stocks);
        exchange.open();
        return exchange;
    }
}

