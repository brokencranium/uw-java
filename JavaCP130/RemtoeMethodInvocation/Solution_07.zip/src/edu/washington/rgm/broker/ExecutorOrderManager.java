package edu.washington.rgm.broker;

import java.util.Comparator;
import java.util.concurrent.Executor;

import edu.washington.ext.cp130.framework.broker.OrderDispatchFilter;
import edu.washington.ext.cp130.framework.broker.OrderQueue;
import edu.washington.ext.cp130.framework.order.StopBuyOrder;
import edu.washington.ext.cp130.framework.order.StopSellOrder;


/**
 * Maintains queues to different types of orders and requests the execution of
 * orders when price conditions allow their execution.
 *
 * @author Russ Moul
 */
public final class ExecutorOrderManager extends SimpleOrderManager {

    /**
     * Constructor.
     *
     * @param stockTickerSymbol the ticker symbol of the stock this instance is
     *                          manage orders for
     * @param price the current price of stock to be managed
     * @param executor the executor to be used to process this queues orders
     */
    public ExecutorOrderManager(final String stockTickerSymbol,
                                final int price, final Executor executor) {
        super();
        setStockTickerSymbol(stockTickerSymbol);

        // Create the stop buy order queue and associate pieces
        final Comparator<StopBuyOrder> ascending = new StopBuyOrderComparator();
        final OrderDispatchFilter<Integer, StopBuyOrder> stopBuyFilter = new StopBuyOrderDispatchFilter(price);
        final OrderQueue<StopBuyOrder> stopBuyQueue =
            new ExecutorOrderQueue<StopBuyOrder>(ascending, stopBuyFilter, executor);

        setStopBuyOrderFilter(stopBuyFilter);
        setStopBuyOrderQueue(stopBuyQueue);
        // Create the stop sell order queue ...
        final Comparator<StopSellOrder> decending = new StopSellOrderComparator();
        final OrderDispatchFilter<Integer, StopSellOrder> stopSellFilter = new StopSellOrderDispatchFilter(price);
        final OrderQueue<StopSellOrder> stopSellQueue =
            new ExecutorOrderQueue<StopSellOrder>(decending, stopSellFilter, executor);

        setStopSellOrderQueue(stopSellQueue);
    }
}

