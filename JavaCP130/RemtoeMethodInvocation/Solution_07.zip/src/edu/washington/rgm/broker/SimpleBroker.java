package edu.washington.rgm.broker;

import java.util.HashMap;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.broker.Broker;
import edu.washington.ext.cp130.framework.broker.BrokerException;
import edu.washington.ext.cp130.framework.broker.OrderManager;
import edu.washington.ext.cp130.framework.broker.OrderProcessor;
import edu.washington.ext.cp130.framework.broker.OrderQueue;
import edu.washington.ext.cp130.framework.exchange.ExchangeEvent;
import edu.washington.ext.cp130.framework.exchange.ExchangeListener;
import edu.washington.ext.cp130.framework.exchange.StockExchange;
import edu.washington.ext.cp130.framework.exchange.StockQuote;
import edu.washington.ext.cp130.framework.order.MarketBuyOrder;
import edu.washington.ext.cp130.framework.order.MarketSellOrder;
import edu.washington.ext.cp130.framework.order.Order;
import edu.washington.ext.cp130.framework.order.StopBuyOrder;
import edu.washington.ext.cp130.framework.order.StopSellOrder;

/**
 * An implementation of the Broker interface, provides a full
 * implementation less the creation of the order manager and market queue.
 *
 * @author Russ Moul
 */
public class SimpleBroker implements Broker, ExchangeListener {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(SimpleBroker.class.getName());

    /** This broker's name */
    private String name;

    /** The brokers account manager */
    private AccountManager accountManager;

    /** The exchange used by this broker */
    private StockExchange stockExchange;

    /** The set of order managers used by the broker */
    private HashMap<String, OrderManager> orderManagerMap;

    /** The market order queue. */
    private OrderQueue<Order> marketOrders;

    /** The market order queue's dispatch filter. */
    private MarketDispatchFilter marketDispatchFilter;

    /**
     * Constructor for sub classes
     */
    protected SimpleBroker() {
    }

    /**
     *  Constructor.
     *
     * @param brokerName name of the broker
     * @param acctMgr the account manager to be used by the broker
     * @param exchg the stock exchange to be used by the broker
     */
    public SimpleBroker(final String brokerName, final AccountManager acctMgr,
                        final StockExchange exchg) {
        setName(brokerName);
        setAccountManager(acctMgr);
        setStockExchange(exchg);

        // Create the market order queue, & order processor
        final MarketDispatchFilter filter = new MarketDispatchFilter(exchg.isOpen());
        setMarketDispatchFilter(filter);
        final SimpleOrderQueue<Order> marketQueue = new SimpleOrderQueue<Order>(filter);
        final OrderProcessor tradeProc = new StockTraderOrderProcessor(acctMgr, exchg);
        marketQueue.setOrderProcessor(tradeProc);
        setMarketOrderQueue(marketQueue);

        // Create the order managers
        initializeOrderManagers();

        exchg.addExchangeListener(this);
    }
    
    /**
     * Sets the broker name.
     *
     * @param name the name of the broker
     */
    protected final void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the account manager.
     *
     * @param accountManager the account manager for the broker
     */
    protected final void setAccountManager(final AccountManager accountManager) {
        this.accountManager = accountManager;
    }

    /**
     * Sets the stock exchange.
     *
     * @param stockExchange the stock exchange for the broker
     */
    protected final void setStockExchange(final StockExchange stockExchange) {
        this.stockExchange = stockExchange;
    }

    /**
     * Sets the market order queue.
     *
     * @param marketOrders the market order queue for the broker
     */
    protected final void setMarketOrderQueue(final OrderQueue<Order> marketOrders) {
        this.marketOrders = marketOrders;
    }

    // TODO Delete this method
    /**
     * Sets the market order queue's dispatch filter.
     *
     * @param marketDispatchFilter the market dispatch filter for the broker
     */
    protected final void setMarketDispatchFilter(final MarketDispatchFilter marketDispatchFilter) {
        this.marketDispatchFilter = marketDispatchFilter;
    }

    /**
     * Fetch the stock list from the exchange and initialize an order manager
     * for each stock.
     */
    protected final void initializeOrderManagers() {
        orderManagerMap = new HashMap<String, OrderManager>();
        final OrderProcessor move2MarketProc = new MoveToMarketQueueProcessor(marketOrders);
        for (String ticker : stockExchange.getTickers()) {
            final int currPrice = stockExchange.getQuote(ticker).getPrice();
            final OrderManager orderMgr = createOrderManager(ticker, currPrice);
            orderMgr.setOrderProcessor(move2MarketProc);
            orderManagerMap.put(ticker, orderMgr);
            logger.info("Initialized order manager for '"
                      + ticker + "' @ " + currPrice);
        }

    }
    
    /**
     * Create an appropriate order manager for this broker.
     *
     * @param ticker the ticker symbol of the stock
     * @param initialPrice current price of the stock
     *
     * @return a new OrderManager for the specified stock
     */
    protected OrderManager createOrderManager(final String ticker, final int initialPrice) {
        return new SimpleOrderManager(ticker, initialPrice);
    }

   /**
    * Upon the exchange opening sets the market dispatch filter threshold
    * and processes any available orders.
    *
    * @param event the price change event
    */
    public final void priceChanged(final ExchangeEvent event) {
        checkInvariants();
        logger.info("Processing price change ["
                  + event.getTicker() + ":" + event.getPrice() + "]");

        OrderManager orderMgr;
        orderMgr = orderManagerMap.get(event.getTicker());
        if (orderMgr != null) {
            orderMgr.adjustPrice(event.getPrice());
        }
    }

    /**
     * Upon the exchange opening sets the market dispatch filter threshold
     * and processes any available orders.
     *
     * @param event the exchange (open) event
     */
    public final void exchangeOpened(final ExchangeEvent event) {
        checkInvariants();
        logger.info("### MARKET OPENED ###");
        marketDispatchFilter.setThreshold(Boolean.TRUE);
    }

    /**
     * Upon the exchange opening sets the market dispatch filter threshold.
     *
     * @param event the exchange (closed) event
     */
    public final void exchangeClosed(final ExchangeEvent event) {
        checkInvariants();
        marketDispatchFilter.setThreshold(Boolean.FALSE);
        logger.info("### MARKET CLOSED ###");
    }

    /**
     * Get the name of the broker.
     *
     * @return the name of the broker
     */
    public final String getName() {
        checkInvariants();
        return name;
    }

    /**
     * Create an account with the broker.
     *
     * @param username the user or account name for the account
     * @param password the password for the new account
     * @param balance the initial account balance in cents
     *
     * @return the new account
     *
     * @exception BrokerException if unable to create account
     */
    public final Account createAccount(final String username,
                                       final String password, final int balance)
        throws BrokerException {
        checkInvariants();
        try {
            return accountManager.createAccount(username, password, balance);
        } catch (final AccountException ae) {
            throw new BrokerException("Unable to create account.", ae);
        }
    }

    /**
     * Delete an account with the broker.
     *
     * @param username the user or account name for the account
     *
     * @exception BrokerException if unable to delete account
     */
    public final void deleteAccount(final String username)
        throws BrokerException {
        checkInvariants();
        try {
            accountManager.deleteAccount(username);
        } catch (final AccountException ae) {
            throw new BrokerException("Unable to delete account.", ae);
        }
    }

    /**
     * Locate an account with the broker.  The username and password are first
     * verified and the account is returned.
     *
     * @param username the user or account name for the account
     * @param password the password for the new account
     *
     * @return the account
     *
     * @exception BrokerException username and password are invalid
     */
    public final Account getAccount(final String username,
                                    final String password)
        throws BrokerException {
        checkInvariants();
        try {
            // First we check the password
            if (accountManager.validateLogin(username, password)) {
                // It's valid, so we'll return the account
                return accountManager.getAccount(username);
            } else {
                throw new BrokerException("Invalid username/password.");
            }
        } catch (final AccountException ae) {
            throw new BrokerException("Unable to access account.", ae);
        }
    }

    /**
     * Place an order with the broker.
     *
     * @param order the order being placed with the broker
     */
    public final void placeOrder(final MarketBuyOrder order) {
        checkInvariants();
        marketOrders.enqueue(order);
    }

    /**
     * Place an order with the broker.
     *
     * @param order the order being placed with the broker
     */
    public final void placeOrder(final MarketSellOrder order) {
        checkInvariants();
        marketOrders.enqueue(order);
    }

    /**
     * Lookup the order manager for this stock.
     *
     * @param ticker the stocks ticker symbol
     *
     * @return the order manager for the stock
     *
     * @exception BrokerException if unable to obtain the order manager
     */
    private  OrderManager orderManagerLookup(final String ticker)
        throws BrokerException {
        final OrderManager orderMgr = orderManagerMap.get(ticker);

        if (orderMgr == null) {
            throw new BrokerException("Requested stock, '" + ticker
                                    + "' does not exist");
        }

        return orderMgr;
    }

    /**
     * Place an order with the broker.
     *
     * @param order the order being placed with the broker
     *
     * @exception BrokerException if unable to place order
     */
    public final void placeOrder(final StopBuyOrder order)
        throws BrokerException {
        checkInvariants();
        orderManagerLookup(order.getStockTicker()).queueOrder(order);
    }

    /**
     * Place an order with the broker.
     *
     * @param order the order being placed with the broker
     *
     * @exception BrokerException if unable to place order
     */
    public final void placeOrder(final StopSellOrder order)
        throws BrokerException {
        checkInvariants();
        orderManagerLookup(order.getStockTicker()).queueOrder(order);
    }

    /**
     * Get a price quote for a stock.
     *
     * @param symbol the stocks ticker symbol
     *
     * @return the quote
     *
     * @exception BrokerException if unable to obtain quote
     */
    public final StockQuote requestQuote(final String symbol)
        throws BrokerException {
        checkInvariants();
        final StockQuote quote = stockExchange.getQuote(symbol);

        if (quote == null) {
            throw new BrokerException("Quote not available for '"
                                    + symbol + "'.");
        }

        return quote;
    }

    /**
     * Release broker resources.
     *
     * @exception BrokerException if the operation fails
     */
    public void close() throws BrokerException {
        try {
            stockExchange.removeExchangeListener(this);
            accountManager.close();
            orderManagerMap = null;
        } catch (final AccountException ex) {
            throw new BrokerException(
                      "Attempt to close the broker failed.", ex);
        }
    }
    
    /**
     * Every public operation invokes this method to insure the broker is 
     * capable of performing operations.  If the broker is not in a valid
     * state an IllegalStateException is thrown.
     * 
     * @throws IllegalStateException if broker is n an invalid state
     */
    private void checkInvariants() {
        if (name == null ||
            accountManager == null ||
            stockExchange == null ||
            orderManagerMap == null ||
            marketOrders == null ||
            marketDispatchFilter == null) {
            throw new IllegalStateException("Broker is not properly initialized, or has been closed.");
        }
    }
}


