package edu.washington.rgm.broker;

import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.broker.OrderManager;
import edu.washington.ext.cp130.framework.broker.OrderProcessor;
import edu.washington.ext.cp130.framework.exchange.StockExchange;
import edu.washington.ext.cp130.framework.order.Order;

/**
 * An extension of AbstractBroker that uses a  ThreadedOrderManager and
 * ThreadeOrderQueue for the market order queue.
 *
 * @author Russ Moul
 */
public final class ThreadedBroker extends SimpleBroker {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(ThreadedBroker.class.getName());

    /**
     *  Constructor.
     *
     * @param brokerName name of the broker
     * @param acctMgr the account manager to be used by the broker
     * @param exchg the stock exchange to be used by the broker
     */
    public ThreadedBroker(final String brokerName, final AccountManager acctMgr,
                          final StockExchange exchg) {
        super();
        setName(brokerName);
        setAccountManager(acctMgr);
        setStockExchange(exchg);

        // Create the market order queue, & order processor
        final MarketDispatchFilter filter = new MarketDispatchFilter(exchg.isOpen());
        setMarketDispatchFilter(filter);

        final ThreadedOrderQueue<Order> marketQueue = new ThreadedOrderQueue<Order>("MARKET", filter);
        marketQueue.setPriority(Thread.MAX_PRIORITY);
        final OrderProcessor tradeProc = new StockTraderOrderProcessor(acctMgr, exchg);
        marketQueue.setOrderProcessor(tradeProc);
        setMarketOrderQueue(marketQueue);

        // Create the order managers
        initializeOrderManagers();

        exchg.addExchangeListener(this);
    }
    
    /**
     * Create an appropriate order manager for this broker.
     *
     * @param ticker the ticker symbol of the stock
     * @param initialPrice current price of the stock
     *
     * @return a new OrderManager for the specified stock
     */
    @Override
    protected OrderManager createOrderManager(final String ticker, final int initialPrice) {
        return new ThreadedOrderManager(ticker, initialPrice);
    }
}
