package edu.washington.rgm.exchange;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;


import edu.washington.ext.cp130.framework.exchange.ExchangeListener;
import edu.washington.ext.cp130.framework.exchange.StockExchange;
import edu.washington.ext.cp130.framework.exchange.StockQuote;
import edu.washington.ext.cp130.framework.order.Order;


/**
 * Client for interacting with a network accessible exchange.  This SocketExchange
 * methods encode the method request as a string, per ProtocolConstants, and send
 * the command to the ExchangeNetworkAdapter, receive the response decode it and
 * return the result.
 *
 * @author Russ Moul
 */
public final class ExchangeNetworkProxy implements StockExchange {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(ExchangeNetworkProxy.class.getName());

    /** The 'command' IP address - the network adapter host */
    private String commandIpAddress;

    /** The 'command' port */
    private int commandPort;

    /** Thread responsible to firing listener events */
    private Thread eventDispatcher;

    /** The event processor, propagates the events to registered listeners. */
    private NetEventProcessor eventProcessor;

    /**
     * Constructor.
     *
     * @param eventIpAddress the multicast IP address to connect to
     * @param eventPort the multicast port to connect to
     * @param cmdIpAddress the address the exchange accepts request on
     * @param cmdPort the address the exchange accepts request on
     */
    public ExchangeNetworkProxy(final String eventIpAddress,
                                final int eventPort,
                                final String cmdIpAddress, final int cmdPort) {
        commandIpAddress = cmdIpAddress;
        commandPort = cmdPort;
        eventProcessor = new NetEventProcessor(eventIpAddress, eventPort);
        eventDispatcher = new Thread(eventProcessor);
        eventDispatcher.start();
    }

    /**
     * The state of the exchange.
     *
     * @return true if the exchange is open otherwise false
     */
    public boolean isOpen() {
        final String response = sendTcpCmd(ProtocolConstants.GET_STATE_CMD.toString());

        // parse response
        final boolean state = ProtocolConstants.OPEN_STATE.equals(response);

        return state;
    }

    /**
     * Gets the ticker symbols for all of the stocks in the traded on the
     * exchange.
     *
     * @return the stock ticker symbols
     */
    public String[] getTickers() {
        final String response = sendTcpCmd(ProtocolConstants.GET_TICKERS_CMD.toString());

        // parse response
        final String[] tickers = response.split(ProtocolConstants.ELEMENT_DELIMITER);

        return tickers;
    }

    /**
     * Gets a stocks current price.
     *
     * @param ticker the ticker symbol for the stock
     *
     * @return the quote, or null if the quote is unavailable.
     */
    public StockQuote getQuote(final String ticker) {
        final StringBuilder cmd = new StringBuilder();
        cmd.append(ProtocolConstants.GET_QUOTE_CMD.toString());
        cmd.append(ProtocolConstants.ELEMENT_DELIMITER);
        cmd.append(ticker);
        final String response = sendTcpCmd(cmd.toString());
        int price = ProtocolConstants.INVALID_STOCK;

        try {
            price = Integer.parseInt(response);
        } catch (final NumberFormatException nex) {
            logger.log(Level.WARNING,
                "String to int conversion failed: '" + response + "'", nex);
        }

        StockQuote quote = null;

        if (price >= 0) {
            quote = new StockQuote(ticker, price);
        }

        return quote;
    }

    /**
     * Creates a command to execute a trade and sends it to the exchange.
     *
     * @param order the order to execute
     *
     * @return the price the order was executed at
     */
    public int executeTrade(final Order order) {
        // Note that there is no distinction between market and stop orders
        // these are broker concepts
        final String orderType = (order.isBuyOrder())
                               ? ProtocolConstants.BUY_ORDER
                               : ProtocolConstants.SELL_ORDER;
        final StringBuilder cmd = new StringBuilder();
        cmd.append(ProtocolConstants.EXECUTE_TRADE_CMD.toString());
        cmd.append(ProtocolConstants.ELEMENT_DELIMITER);
        cmd.append(orderType);
        cmd.append(ProtocolConstants.ELEMENT_DELIMITER);
        cmd.append(order.getAccountId());
        cmd.append(ProtocolConstants.ELEMENT_DELIMITER);
        cmd.append(order.getStockTicker());
        cmd.append(ProtocolConstants.ELEMENT_DELIMITER);
        cmd.append(order.getNumberOfShares());
        final String response = sendTcpCmd(cmd.toString());
        int executionPrice = 0;

        try {
            executionPrice = Integer.parseInt(response);
        } catch (final NumberFormatException ex) {
            logger.log(Level.WARNING,
                "String to int conversion failed: '" + response + "'", ex);
        }

        return executionPrice;
    }

    /**
     * Adds a market listener.  Delegates to the NetEventProcessor.
     *
     * @param l the listener to add
     */
    public synchronized void addExchangeListener(final ExchangeListener l) {
        eventProcessor.addExchangeListener(l);
    }

    /**
     * Removes a market listener.  Delegates to the NetEventProcessor.
     *
     * @param l the listener to remove
     */
    public synchronized void removeExchangeListener(final ExchangeListener l) {
        eventProcessor.removeExchangeListener(l);
    }


    /**
     * Sends a command string the the exchange.
     *
     * @param cmd the command to send to the exchange
     *
     * @return the response
     */
    private String sendTcpCmd(final String cmd) {
        Socket sock = null;
        PrintWriter prntWrtr = null;
        BufferedReader br = null;
        String response = "";

        try {
            sock = new Socket(commandIpAddress, commandPort);
            logger.info("Connected to server: " + sock.getLocalAddress().toString() + ":" + sock.getLocalPort());

            final OutputStream outStrm = sock.getOutputStream();
            final Writer wrtr = new OutputStreamWriter(outStrm, ProtocolConstants.ENCODING);
            prntWrtr = new PrintWriter(wrtr, true);

            InputStreamReader rdr;
            rdr = new InputStreamReader(sock.getInputStream());
            br = new BufferedReader(rdr);
            prntWrtr.println(cmd);
            response = br.readLine();
        } catch (final IOException ex) {
            logger.log(Level.WARNING, "Error sending command to exchange", ex);
        } finally {
            if (prntWrtr != null) {
                prntWrtr.close();
            }

            try {
                if (br != null) {
                    br.close();
                }
            } catch (final IOException ioex) {
                logger.log(Level.INFO, "Error closing reader.", ioex);
            }

            try {
                if (sock != null) {
                    sock.close();
                }
            } catch (final IOException ioex) {
                logger.log(Level.INFO, "Error closing socket.", ioex);
            }
        }

        return response;
    }
}

