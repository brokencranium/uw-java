package edu.washington.rgm.exchange;

import edu.washington.ext.cp130.framework.exchange.NetworkExchangeProxyFactory;
import edu.washington.ext.cp130.framework.exchange.StockExchange;


/**
 * A factory interface for creating ExchangeNetworkProxy instances.
 *
 * @author Russ Moul
 */
public final class ExchangeNetworkProxyFactory
        implements NetworkExchangeProxyFactory {
    /**
     * Instantiates a enabled ExchangeNetworkProxy.
     *
     * @param multicastIP the multicast ip address used to distribute events
     * @param multicastPort the port used to distribute events
     * @param commandIP the exchange host
     * @param commandPort the listening port to be used to accept command
     *                    requests
     *
     * @return a newly instantiated ExchangeAdapter
     */
    public StockExchange newProxy(final String multicastIP,
                                  final int multicastPort,
                                  final String commandIP,
                                  final int commandPort) {
        return new ExchangeNetworkProxy(multicastIP, multicastPort, commandIP,
            commandPort);
    }
}

