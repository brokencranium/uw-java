package edu.washington.rgm.exchange;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.event.EventListenerList;

import edu.washington.ext.cp130.framework.exchange.ExchangeEvent;
import edu.washington.ext.cp130.framework.exchange.ExchangeListener;

/**
 * Listens for (by joining the multicast group) and processes events
 * received from the exchange.  Processing the events consists of propagating
 * them to registered listeners.
 */
final class NetEventProcessor implements Runnable {
    /** Buffer size */
    private static final int BUFFER_SIZE = 128;

    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(NetEventProcessor.class.getName());

    /** The 'event' multicast address */
    private String eventIpAddress;

    /** The 'event' multicast port */
    private int eventPort;

    /** The 'event' socket */
    private MulticastSocket eventSocket;

    /** The event listener list */
    private EventListenerList listenerList = new EventListenerList();

    /**
     * Constructor.
     * 
     * @param eventIpAddress the multicast IP address to connect to
     * @param eventPort the multicast port to connect to
     */
    NetEventProcessor(final String eventIpAddress,
                      final int eventPort) {
        this.eventIpAddress = eventIpAddress;
        this.eventPort = eventPort;
    }

    /**
     * Continuously accepts and processes market and price change events.
     */
    public void run() {
        try {
            final InetAddress eventGroup = InetAddress.getByName(eventIpAddress);
            eventSocket = new MulticastSocket(eventPort);
            eventSocket.joinGroup(eventGroup);

            final byte[] buf = new byte[BUFFER_SIZE];
            final DatagramPacket packet = new DatagramPacket(buf, buf.length);

            while (true) {
                eventSocket.receive(packet);

                final String msg = new String(packet.getData(), packet.getOffset(), packet.getLength(),
                                              ProtocolConstants.ENCODING);
                final String[] elements = msg.split(ProtocolConstants.ELEMENT_DELIMITER);
                final ProtocolConstants eventType =
                      ProtocolConstants.valueOf(elements[ProtocolConstants.CMD_ELEMENT]);

                switch (eventType) {
                    case PRICE_CHANGE_EVNT:
                        final String ticker = elements[ProtocolConstants.PRICE_CHANGE_EVNT_TICKER_ELEMENT];
                        final String priceStr = elements[ProtocolConstants.PRICE_CHANGE_EVNT_PRICE_ELEMENT];
                        int price = -1;

                        try {
                            price = Integer.parseInt(priceStr);
                        } catch (final NumberFormatException ex) {
                            logger.log(Level.WARNING, "String to int conversion failed: '"
                                                    + priceStr + "'", ex);
                        }
                        fireListeners(ExchangeEvent.newPriceChangedEvent(this, ticker, price));
                        break;
                    case OPEN_EVNT:
                        fireListeners(ExchangeEvent.newOpenedEvent(this));
                        break;
                    case CLOSED_EVNT:
                        fireListeners(ExchangeEvent.newClosedEvent(this));
                        break;
                    default:
                        break;

                }
            }
        } catch (final IOException ex) {
            logger.warning("Server error: " + ex);
        } finally {
            if (eventSocket != null) {
                eventSocket.close();
            }
        }

        logger.warning("Done processing events.");
    }

    /**
     * Adds a market listener.
     *
     * @param l the listener to add
     */
    public void addExchangeListener(final ExchangeListener l) {
        listenerList.add(ExchangeListener.class, l);
    }

    /**
     * Removes a market listener.
     *
     * @param l the listener to remove
     */
    public void removeExchangeListener(final ExchangeListener l) {
        listenerList.remove(ExchangeListener.class, l);
    }

    /**
     * Fires a exchange event.
     *
     * @param evnt the event to be fired
     */
    private void fireListeners(final ExchangeEvent evnt) {
        ExchangeListener[] listeners;
        listeners = listenerList.getListeners(ExchangeListener.class);

        for (ExchangeListener listener : listeners) {
            switch (evnt.getEventType()) {
                case OPENED:
                    listener.exchangeOpened(evnt);
                    break;

                case CLOSED:
                    listener.exchangeClosed(evnt);
                    break;

                case PRICE_CHANGED:
                    listener.priceChanged(evnt);
                    break;

                default:
                    logger.severe("Bad exchange event: " + evnt.getEventType());
                    break;
            }
        }
    }
}
