package edu.washington.rgm.exchange;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.exchange.ExchangeAdapter;
import edu.washington.ext.cp130.framework.exchange.NetworkExchangeAdapterFactory;
import edu.washington.ext.cp130.framework.exchange.StockExchange;


/**
 * A NetworkExchangeAdapterFactory implementation for creating
 * ExchangeNetworkAdapter instances.
 *
 * @author Russ Moul
 */
public final class ExchangeNetworkAdapterFactory
    implements NetworkExchangeAdapterFactory {
    
    /**
     * this class's logger.
     */
    private static final Logger logger = Logger.getLogger(ExchangeAdapter.class.getName());

    /**
     * Instantiates an ExchangeNetworkAdapter.
     *
     * @param exchange the underlying real exchange
     * @param multicastIP the multicast ip address used to distribute events
     * @param multicastPort the port used to distribute events
     * @param commandPort the listening port to be used to accept command
     *                    requests
     *
     * @return a newly instantiated ExchangeNetworkAdapter, or null if
     *         instantiation fails
     */
    public ExchangeAdapter newAdapter(final StockExchange exchange,
                                      final String multicastIP,
                                      final int multicastPort,
                                      final int commandPort) {
        ExchangeAdapter exAdapt = null;

        try {
            exAdapt = new ExchangeNetworkAdapter(exchange, multicastIP,
                                                 multicastPort, commandPort);
        } catch (final SocketException ex) {
            logger.log(Level.SEVERE, "Unable to establish socket connection.", ex);
        } catch (final UnknownHostException ex) {
            logger.log(Level.SEVERE, "Unable to resolve multicast address.", ex);
        }

        return exAdapt;
    }
}

