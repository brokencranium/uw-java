package edu.washington.rgm.exchange;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.exchange.StockExchange;

/**
 * Accepts command requests and dispatches them to a CommandHandler.
 * 
 * @see CommandHandler
 */
final class CommandListener extends Thread {
    /** This class' logger */
    private static final Logger logger =
                         Logger.getLogger(CommandListener.class.getName());

    /** The 'command' port */
    private int commandPort;

    /** Flag indicating if the thread is currently accepting connections */
    private volatile boolean listening = true;

    /** The socket the thread listens on */
    private ServerSocket servSock;
    /** The 'real' exchange this adapter delegates to */
    private StockExchange realExchange;


    /** Executor used to execute the client requests. */
    private ExecutorService requestExecutor = Executors.newCachedThreadPool();

    /**
     * Constructor.
     *
     * @param commandPort the port to listen for connections on
     * @param realExchange the "real" exchange to be used to execute the commands
     */
    public CommandListener(final int commandPort, final StockExchange realExchange) {
        this.commandPort = commandPort;
        this.realExchange = realExchange;
    }


    /**
     * Accept connections, and create a CommandExecutor for dispatching the
     * command.
     */
    public void run() {
        try {
            logger.info("Server Ready, "
                      + "accepting connections on port: " + commandPort);
            servSock = new ServerSocket(commandPort);

            while (listening) {
                Socket sock = null;

                try {
                    sock = servSock.accept();
                    logger.info("Accepted connection: " + sock.getLocalAddress().toString() + ":" + sock.getLocalPort());
                } catch (final SocketException ex) {
                    if (servSock != null && !servSock.isClosed()) {
                        logger.log(Level.WARNING, "Error accepting connection.", ex);
                    }
                }

                if (sock == null) {
                    continue;
                }

                requestExecutor.execute(new CommandHandler(sock, realExchange));
            }
        } catch (final IOException ex) {
            logger.info("Server error: " + ex);
        } finally {
            terminate();
        }
    }

    /**
     * Terminates this thread gracefully.
     */
    public void terminate() {
        listening = false;

        try {
            if (servSock != null && !servSock.isClosed()) {
                logger.info("Closing server socket.");
                servSock.close();
            }
            servSock = null;
            if (!requestExecutor.isShutdown()) {
                requestExecutor.shutdown();
                requestExecutor.awaitTermination(2L, TimeUnit.SECONDS);
            }
        } catch (final InterruptedException iex) {
            logger.log(Level.INFO, "Interrupted awaiting executor termination.", iex);
        } catch (final IOException ioex) {
            logger.log(Level.INFO, "Error closing listen socket.", ioex);
        }
    }
}
