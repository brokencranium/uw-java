package edu.washington.rgm.exchange;


/**
 * Constants for the command strings composing the exchange protocol.  The
 * protocol supports events and commands.  The events and commands are
 * represented by enumerated values, other constants are simply static final
 * variables.
 * <br>
 * Events are one way messages sent from the exchange to the broker(s).
 * <br>
 * The protocol supports the following events:
 * <pre>
 * Event: [OPEN_EVNT]
 * -
 * Event: [CLOSED_EVNT]
 * -
 * Event: [PRICE_CHANGE_EVNT][ELEMENT_DELIMITER]<i>symbol</i>[ELEMENT_DELIMITER]<i>price</i>
 * </pre>
 * <br>
 * Commands conform to a request/response model where requests are sent from
 * a broker and the result is a response sent to the requesting broker from the
 * exchange.
 * <br>
 * The protocol supports the following commands:
 * <pre>
 * Request:  [GET_STATE_CMD]
 * Response: [OPEN_STATE]|[CLOSED_STATE]
 * -
 * Request:  [GET_TICKERS_CMD]
 * Response: <i>symbol</i>[ELEMENT_DELIMITER]<i>symbol</i>...
 * -
 * Request:  [GET_QUOTE_CMD][ELEMENT_DELIMITER]<i>symbol</i>
 * Response: <i>price</i>
 * -
 * Request:  [EXECUTE_TRADE_CMD][ELEMENT_DELIMITER][BUY_ORDER]|[SELL_ORDER]
 *           [ELEMENT_DELIMITER]<i>account_id</i>[ELEMENT_DELIMITER]
 *           <i>symbol</i>[ELEMENT_DELIMITER]<i>shares</i>
 * Response: <i>execution_price</i>
 * </pre>
 *
 * @author Russ Moul
 */
public enum ProtocolConstants {
    /** The exchange has opened. */
    OPEN_EVNT,
    /** The exchange has closed. */
    CLOSED_EVNT,
    /** A stock price has changed. */
    PRICE_CHANGE_EVNT,

    /** A request for the ticker symbols for the traded stocks. */
    GET_TICKERS_CMD,
    /** A request for a stock price quote. */
    GET_QUOTE_CMD,
    /** A request for the exchange's state. */
    GET_STATE_CMD,
    /** A request to execute a trade. */
    EXECUTE_TRADE_CMD;

    /** Indicates the exchange is open. */
    public static final String OPEN_STATE = "OPEN";

    /** Indicates the exchange is closed. */
    public static final String CLOSED_STATE = "CLOSED";

    /** Identifies an order as a buy order. */
    public static final String BUY_ORDER = "BUY_ORDER";

    /** Identifies an order as a sell order. */
    public static final String SELL_ORDER = "SELL_ORDER";

    /** The maximum number of command elements used in the protocol. */
    public static final String ELEMENT_DELIMITER = ":";

    /** The index of the ticker element. */
    public static final int PRICE_CHANGE_EVNT_TICKER_ELEMENT = 1;

    /** The index of the price element. */
    public static final int PRICE_CHANGE_EVNT_PRICE_ELEMENT = 2;

    /** The index of the command element. */
    public static final int CMD_ELEMENT = 0;

    /** The index of the ticker element in the price quote command. */
    public static final int QUOTE_CMD_TICKER_ELEMENT = 1;

    /** The index of the order type element in the execute trade command. */
    public static final int EXECUTE_TRADE_CMD_TYPE_ELEMENT = 1;

    /** The index of the account id element in the execute trade command. */
    public static final int EXECUTE_TRADE_CMD_ACCOUNT_ELEMENT = 2;

    /** The index of the ticker element in the execute trade command. */
    public static final int EXECUTE_TRADE_CMD_TICKER_ELEMENT = 3;

    /** The index of the shares element in the execute trade command. */
    public static final int EXECUTE_TRADE_CMD_SHARES_ELEMENT = 4;

    /** The invalid stock price - indicates stock is not on the exchange. */
    public static final int INVALID_STOCK = -1;

    /** Character encoding to use. */
    public static final String ENCODING = "UTF-8";
}

