package edu.washington.rgm.remote;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.broker.Broker;
import edu.washington.ext.cp130.framework.broker.BrokerException;
import edu.washington.ext.cp130.framework.exchange.StockQuote;
import edu.washington.ext.cp130.framework.order.MarketBuyOrder;
import edu.washington.ext.cp130.framework.order.MarketSellOrder;
import edu.washington.ext.cp130.framework.order.StopBuyOrder;
import edu.washington.ext.cp130.framework.order.StopSellOrder;


/**
 * Implements a broker session with a remote broker.  This implementation is a
 * thin wrapper around a BrokerSession object.
 *
 * @author Russ Moul
 */
public final class RemoteBrokerSessionImpl extends UnicastRemoteObject
    implements RemoteBrokerSession {

    /** Version id. */
    private static final long serialVersionUID = 2590295313689939300L;

    /** The broker this remote session delegates to */
    private Broker broker;

    /** The account used to establish the session */
    private Account account;

    /**
     * Gets the account associated with this session.
     *
     * @param broker the broker the session is with
     * @param acct the account the session is for
     *
     * @exception RemoteException if failed to export this object
     */
    public RemoteBrokerSessionImpl(final Broker broker, final Account acct)
        throws RemoteException {
        this.broker = broker;
        this.account = acct;
    }

    /**
     * Gets the account balance.
     *
     * @return the account balance
     *
     * @exception RemoteException if unable to retrieve the account
     */
    public int getBalance() throws RemoteException {
        return account.getBalance();
    }

    /**
     * Delete the account associated with this session.
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public void deleteAccount() throws RemoteException, BrokerException {
        broker.deleteAccount(account.getName());
        account = null;
        close();
    }

    /**
     * Get a price quote for a stock.
     *
     * @param symbol the stocks ticker symbol
     *
     * @return the stocks current price
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public StockQuote requestQuote(final String symbol)
        throws RemoteException, BrokerException {
        return broker.requestQuote(symbol);
    }

    /**
     * Place a market buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public void placeMarketBuyOrder(final String ticker,
                                    final int numberOfShares)
        throws RemoteException, BrokerException {
        final MarketBuyOrder order = new MarketBuyOrder(account.getName(),
                                                        numberOfShares, ticker);
        broker.placeOrder(order);
    }

    /**
     * Place a market sell order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public void placeMarketSellOrder(final String ticker,
                                     final int numberOfShares)
        throws RemoteException, BrokerException {
        final MarketSellOrder order = new MarketSellOrder(account.getName(),
                                                          numberOfShares, ticker);
        broker.placeOrder(order);
    }

    /**
     * Place a stop buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     * @param stopPrice the price which must be attained before this order may
     *                  be executed
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public void placeStopSellOrder(final String ticker,
                                   final int numberOfShares,
                                   final int stopPrice)
        throws RemoteException, BrokerException {
        final StopSellOrder order = new StopSellOrder(account.getName(),
                                                      numberOfShares, ticker,
                                                      stopPrice);
        broker.placeOrder(order);
    }

    /**
     * Place a stop buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     * @param stopPrice the price which must be attained before this order may
     *                  be executed
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public void placeStopBuyOrder(final String ticker,
                                  final int numberOfShares,
                                  final int stopPrice)
        throws RemoteException, BrokerException {
        final StopBuyOrder order = new StopBuyOrder(account.getName(),
                                              numberOfShares, ticker,
                                              stopPrice);
        broker.placeOrder(order);
    }

    /**
     * Closes the session, releasing any resources.
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     */
    public void close() throws RemoteException {
        UnicastRemoteObject.unexportObject(this, true);
    }

}

