package edu.washington.rgm.remote;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.broker.Broker;
import edu.washington.ext.cp130.framework.broker.BrokerException;


/**
 * A gateway to a remote broker, establishes a session with a remote broker.
 * This implementation is a thin wrapper around a BrokerGatway object.
 *
 * @author Russ Moul
 */
public final class RemoteBrokerGatewayImpl extends UnicastRemoteObject
    implements RemoteBrokerGateway {

    /** Version id. */
    private static final long serialVersionUID = 1663359982455762351L;

    /** The 'real' broker this remote broker delegates to */
    private Broker broker;

    /**
     * Constructor.
     *
     * @param broker the broker to be exposed through this adapter
     *
     * @throws RemoteException if failed to ewxport this object
     */
    public RemoteBrokerGatewayImpl(final Broker broker) throws RemoteException {
        this.broker = broker;
    }

    /**
     * Create an account and construct a session for this new account.
     *
     * @param userId the user id
     * @param password the password for the account
     * @param balance the initial cash balance
     *
     * @return a new session established with the newly created account
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public RemoteBrokerSession createAccount(final String userId,
                                             final String password,
                                             final int balance)
        throws RemoteException, BrokerException  {
        final Account acct = broker.createAccount(userId, password, balance);
        final RemoteBrokerSession rSession = new RemoteBrokerSessionImpl(broker, acct);
        return rSession;
    }

    /**
     * Constructs a session for the specified account, assuming the password is
     * valid.
     *
     * @param userId the user id
     * @param password the password for the account
     *
     * @return a new session established named account
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    public RemoteBrokerSession login(final String userId, final String password)
        throws RemoteException, BrokerException {
        final Account acct = broker.getAccount(userId, password);
        final RemoteBrokerSession rSession = new RemoteBrokerSessionImpl(broker, acct);
        return rSession;
    }
}

