package edu.washington.rgm.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

import edu.washington.ext.cp130.framework.broker.BrokerException;
import edu.washington.ext.cp130.framework.exchange.StockQuote;


/**
 * Interface for a session with a remote broker.  This interface provides
 * methods for interacting with the broker and maintaining account information
 * for use in these interactions.
 *
 * @author Russ Moul
 */
public interface RemoteBrokerSession extends Remote {
    /**
     * Gets the account balance.
     *
     * @return the account balance
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     */
    int getBalance() throws RemoteException;

    /**
     * Delete the account associated with this session.
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    void deleteAccount() throws RemoteException, BrokerException;

    /**
     * Get a price quote for a stock.
     *
     * @param symbol the stocks ticker symbol
     *
     * @return the price quote
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    StockQuote requestQuote(String symbol)
        throws RemoteException, BrokerException;

    /**
     * Place a market buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    void placeMarketBuyOrder(String ticker, int numberOfShares)
        throws RemoteException, BrokerException;

    /**
     * Place a market sell order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    void placeMarketSellOrder(String ticker, int numberOfShares)
        throws RemoteException, BrokerException;

    /**
     * Place a stop buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     * @param price the desired price
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    void placeStopSellOrder(String ticker, int numberOfShares, int price)
        throws RemoteException, BrokerException;

    /**
     * Place a stop buy order with the broker.
     *
     * @param ticker the stock ticker symbol for the stock
     * @param numberOfShares the number of shares the order is for
     * @param price the desired price
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    void placeStopBuyOrder(String ticker, int numberOfShares, int price)
        throws RemoteException, BrokerException;
    
    /**
     * Closes the session, releasing any resources.
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     */
    void close() throws RemoteException;
}

