package edu.washington.rgm.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

import edu.washington.ext.cp130.framework.broker.BrokerException;


/**
 * Remote interface for the gateway to a remote broker. The gateway creates or
 * authenticates an account and returns a session which may be used to interact
 * with the broker using the account.
 *
 * @author Russ Moul
 */
public interface RemoteBrokerGateway extends Remote {
    /**
     * Create an account and construct a session for this new account.
     *
     * @param userId the user id
     * @param password the password for the account
     * @param balance the initial cash balance
     *
     * @return a new session established with the newly created account
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    RemoteBrokerSession createAccount(String userId, String password,
        int balance) throws RemoteException, BrokerException;

    /**
     * Constructs a session for the specified account, assuming the password is
     * valid.
     *
     * @param userId the user id
     * @param password the password for the account
     *
     * @return a new session established named account
     *
     * @throws RemoteException if the operation fails due to a RemoteException
     * @throws BrokerException if the operation can't be completed by the broker
     */
    RemoteBrokerSession login(String userId, String password)
        throws RemoteException, BrokerException;
}

