package demo;

import java.util.LinkedList;

import edu.washington.example.threads.Consumer;
import edu.washington.example.threads.Producer;

/**
 * Demonstrates the Producer/Consumer threads.
 *
 * @author Russ Moul
 */
public final class ProducerConsumerDemo {
    /**
     * Entry point.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        LinkedList list = new LinkedList();
        Thread producer1 = new Producer("Producer_1", list, 0, 50);
        Thread producer2 = new Producer("Producer_2", list, 100, 150);
        Consumer consumer1 = new Consumer("Consumer_1", list);
        Consumer consumer2 = new Consumer("Consumer_2", list);
        producer1.start();
        producer2.start();
        consumer1.start();
        consumer2.start();

        try {
            producer1.join();
            producer2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        consumer1.terminate();
        consumer2.terminate();
    }
}
