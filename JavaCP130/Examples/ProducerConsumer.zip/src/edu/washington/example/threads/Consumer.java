package edu.washington.example.threads;

import java.util.LinkedList;

/**
 * A thread for consuming objects out of a linked list.
 *
 * @author Russ Moul
 */
public final class Consumer extends Thread {
    /** Maximum delay. */
    private static final double MAX_DELAY = 100.0;

    /** The list to consume objects from */
    private LinkedList mList;

    /** Terminate if the list is empty. */
    private boolean mTerminate;

    /**
     * Constructs the consumer,specifying the list to obtain objects from.
     *
     * @param name a name for identifying the thread
     * @param list the source of objects
     */
    public Consumer(final String name, final LinkedList list) {
        super(name);
        mList = list;
    }

    /**
     * If the list is not empty consume an object and print it out.
     */
    public void run() {
        loop: while (true) {
            Object item;

            synchronized (mList) { // obtain the monitor for the list
                while (mList.isEmpty()) {
                    if (mTerminate) {
                        break loop;
                    }
                    try {
                        mList.wait(); // wait for the list to be populated
                    } catch (InterruptedException ex) {
                        break loop;
                    }
                }

                item = mList.removeFirst();
            }

            // print which thread consumed what
            System.out.println("               "
                             + getName() + " Consumed: " + item);

            // cause an artificial delay
            int delay = (int) (Math.random() * MAX_DELAY);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                   ex.printStackTrace();
                }
            }
        }
        System.out.println(getName() + " termintaing!");
    }

    /**
     * Terminate the consumer, once the list is empty.
     */
    public void terminate() {
        mTerminate = true;
        synchronized (mList) { // obtain the monitor for the list
            mList.notifyAll();
        }
    }
}
