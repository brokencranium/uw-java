import java.io.*;
import java.util.regex.*;
import java.util.prefs.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public final class RegExTool extends JFrame {
	private static final String PATH_PREF_NAME = "regex.eval.last.path";

	private static final String EOL = System.getProperty("line.separator");

	private JTextField experssionFld;

	private JCheckBox javaStringChkBox;

	private JButton loadFileBtn;

	private JTextArea inputTextArea;

	private JButton matchBtn;

	private JTree resultTree;

	private JCheckBoxMenuItem caseInsensitiveMI;

	private JCheckBoxMenuItem unicodeCaseMI;

	private JCheckBoxMenuItem multiLineMI;

	private JCheckBoxMenuItem unixLinesMI;

	private JCheckBoxMenuItem dotAllMI;

	private JCheckBoxMenuItem commentsMI;

	private JCheckBoxMenuItem canonEqMI;

	private int optionFlag;

	public RegExTool() {
		super("Regular Expression Evaluator");

		constructLayout();
	}

	private void constructLayout() {
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				quitAction();
			}
		});
		JMenu fileMenu = new JMenu("File");

		JMenuItem quitMenu = new JMenuItem("Quit", 'Q');
		KeyStroke quitKey = KeyStroke.getKeyStroke('Q', Event.ALT_MASK);
		quitMenu.setAccelerator(quitKey);
		quitMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				quitAction();
			}
		});

		fileMenu.add(quitMenu);

		JMenuBar menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		menuBar.add(constructOptionMenu());
		setJMenuBar(menuBar);

		JSplitPane panes = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		JPanel topPanel = new JPanel(gridbag);

		gbc.insets = new Insets(4, 4, 4, 4);
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;

		topPanel.add(new JLabel("Regular Expression:"), gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 1.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;

		experssionFld = new JTextField();
		topPanel.add(experssionFld, gbc);

		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;

		javaStringChkBox = new JCheckBox("Java String");
		topPanel.add(javaStringChkBox, gbc);
		javaStringChkBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String expr = experssionFld.getText();
				if (javaStringChkBox.isSelected()) {
					experssionFld.setText(regExToJavaString(expr));
				} else {
					experssionFld.setText(javaStringToRegEx(expr));
				}
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;

		topPanel.add(new JLabel("Input/Output Text:"), gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 1.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;

		loadFileBtn = new JButton("Load from file...");
		topPanel.add(loadFileBtn, gbc);
		loadFileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadFileAction();
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 3;
		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.fill = GridBagConstraints.BOTH;

		inputTextArea = new JTextArea();
		topPanel.add(new JScrollPane(inputTextArea), gbc);

		panes.setTopComponent(topPanel);

		JPanel btnPanel = new JPanel(gridbag);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;

		matchBtn = new JButton("Match");
		btnPanel.add(matchBtn, gbc);
		matchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				evaluateAction();
			}
		});

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;

		JButton replaceBtn = new JButton("Replace...");
		btnPanel.add(replaceBtn, gbc);
		replaceBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				replaceAction();
			}
		});

		gbc.insets = new Insets(4, 4, 4, 4);
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;

		JButton splitBtn = new JButton("Split");
		btnPanel.add(splitBtn, gbc);
		splitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				splitAction();
			}
		});

		JPanel bottomPanel = new JPanel(gridbag);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 3;
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.fill = GridBagConstraints.NONE;

		bottomPanel.add(btnPanel, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.gridheight = 1;
		gbc.gridwidth = 3;
		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.fill = GridBagConstraints.BOTH;

		resultTree = new JTree(new DefaultMutableTreeNode());
		resultTree.setRootVisible(false);
		resultTree.setShowsRootHandles(true);
		bottomPanel.add(new JScrollPane(resultTree), gbc);
		resultTree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				DefaultMutableTreeNode node;
				node = (DefaultMutableTreeNode) e.getPath()
						.getLastPathComponent();
				MatchInfo n = (MatchInfo) node.getUserObject();

				inputTextArea.setCaretPosition(n.start());
				inputTextArea.moveCaretPosition(n.end());
				inputTextArea.requestFocus();
			}
		});

		panes.setBottomComponent(bottomPanel);
		panes.setResizeWeight(.3);
		panes.setDividerSize(4);
		panes.setDividerLocation(150);
		getContentPane().add(panes);

		pack();
		setSize(400, 500);
		setResizable(true);
		// adjustControls();
		GraphicsEnvironment gEnv;
		gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Point center = gEnv.getCenterPoint();
		setLocation(center.x - getWidth() / 2, center.y - getHeight() / 2);
	}

	private JMenu constructOptionMenu() {
		JMenu optionMenu = new JMenu("Options");

		caseInsensitiveMI = new JCheckBoxMenuItem("CASE_INSENSITIVE");
		caseInsensitiveMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(caseInsensitiveMI);

		unicodeCaseMI = new JCheckBoxMenuItem("UNICODE_CASE");
		unicodeCaseMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(unicodeCaseMI);

		multiLineMI = new JCheckBoxMenuItem("MULTILINE");
		multiLineMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(multiLineMI);

		unixLinesMI = new JCheckBoxMenuItem("UNIX_LINES");
		unixLinesMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(unixLinesMI);

		dotAllMI = new JCheckBoxMenuItem("DOTALL");
		dotAllMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(dotAllMI);

		commentsMI = new JCheckBoxMenuItem("COMMENTS");
		commentsMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(commentsMI);

		canonEqMI = new JCheckBoxMenuItem("CANON_EQ");
		canonEqMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				optionAction();
			}
		});
		optionMenu.add(canonEqMI);

		return optionMenu;
	}

	private String regExToJavaString(final String regex) {
		String s = regex.replaceAll("\\\\", "\\\\\\\\");
		s = s.replaceAll("\"", "\\\\\"");
		return s;
	}

	private String javaStringToRegEx(final String s) {
		String regEx = s.replaceAll("\\\\\\\\", "\\\\");
		regEx = regEx.replaceAll("\\\\\"", "\"");
		return regEx;
	}

	private void optionAction() {
		optionFlag = 0;
		if (caseInsensitiveMI.isSelected()) {
			optionFlag |= Pattern.CASE_INSENSITIVE;
		}
		if (unicodeCaseMI.isSelected()) {
			optionFlag |= Pattern.UNICODE_CASE;
		}
		if (multiLineMI.isSelected()) {
			optionFlag |= Pattern.MULTILINE;
		}
		if (unixLinesMI.isSelected()) {
			optionFlag |= Pattern.UNIX_LINES;
		}
		if (dotAllMI.isSelected()) {
			optionFlag |= Pattern.DOTALL;
		}
		if (commentsMI.isSelected()) {
			optionFlag |= Pattern.COMMENTS;
		}
		if (canonEqMI.isSelected()) {
			optionFlag |= Pattern.CANON_EQ;
		}
	}

	private void quitAction() {
		System.exit(0);
	}

	private void clearTree() {
		DefaultTreeModel model = (DefaultTreeModel) resultTree.getModel();
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
		root.removeAllChildren();
		model.nodeStructureChanged(root);
	}

	private Pattern compileRegEx() {
		String expr = experssionFld.getText();
		if (javaStringChkBox.isSelected()) {
			expr = javaStringToRegEx(expr);
		}
		Pattern pattern = Pattern.compile(expr, optionFlag);
		return pattern;
	}

	private void replaceAction() {
		try {
			Pattern pattern = compileRegEx();
			String text = inputTextArea.getText();
			Matcher matcher = pattern.matcher(text);
			if (matcher.find()) {
				String replacementString = (String) JOptionPane
						.showInputDialog(this, "Enter the replacement string:",
								"Replacement String Input",
								JOptionPane.QUESTION_MESSAGE, null, null, null);

				if ((replacementString != null)
						&& (replacementString.length() > 0)) {
					inputTextArea.setText(matcher
							.replaceAll(replacementString));
					DefaultTreeModel model;
					model = (DefaultTreeModel) resultTree.getModel();
					DefaultMutableTreeNode root;
					root = (DefaultMutableTreeNode) model.getRoot();
					root.removeAllChildren();
					model.nodeStructureChanged(root);
				}
			} else {
				JOptionPane.showMessageDialog(this,
						"No pattern matches found, can't perform replace.",
						"No match", JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (PatternSyntaxException patex) {
			processSyntaxException(patex);
		} catch (Exception ex) {
			processException(ex);
		}
	}

	private void splitAction() {
		try {
			Pattern pattern = compileRegEx();
			String text = inputTextArea.getText();
			Matcher matcher = pattern.matcher(text);
			if (matcher.find()) {
				StringBuffer buf = new StringBuffer();
				String[] pieces = pattern.split(text);
				for (int i = 0; i < pieces.length; i++) {
					if (i > 0) {
						buf.append(EOL);
					}
					buf.append(pieces[i]);
				}
				inputTextArea.setText(buf.toString());

				DefaultTreeModel model = (DefaultTreeModel) resultTree
						.getModel();
				DefaultMutableTreeNode root = (DefaultMutableTreeNode) model
						.getRoot();
				root.removeAllChildren();
				model.nodeStructureChanged(root);
			} else {
				JOptionPane.showMessageDialog(this,
						"No pattern matches found, can't perform split.",
						"No match", JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (PatternSyntaxException patex) {
			processSyntaxException(patex);
		} catch (Exception ex) {
			processException(ex);
		}

	}

	private void evaluateAction() {
		try {
			Pattern pattern = compileRegEx();
			String text = inputTextArea.getText();
			int mNdx = 0;

			DefaultTreeModel model = (DefaultTreeModel) resultTree.getModel();
			DefaultMutableTreeNode root = (DefaultMutableTreeNode) model
					.getRoot();
			root.removeAllChildren();

			if (text.trim().length() == 0
					|| experssionFld.getText().length() == 0) {
				return;
			}
			mNdx += processText(pattern, text, mNdx);
			model.nodeStructureChanged(root);
			inputTextArea.setCaretPosition(0);
			inputTextArea.moveCaretPosition(0);
			if (mNdx <= 0) {
				JOptionPane.showMessageDialog(this,
						"No pattern matches found.", "No match",
						JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (PatternSyntaxException patex) {
			processSyntaxException(patex);
		} catch (Exception ex) {
			processException(ex);
		}
	}

	/**
	 * returns the number of matches found
	 */
	private int processText(Pattern pattern, String text, int mNdx)
			throws Exception {
		DefaultTreeModel model = (DefaultTreeModel) resultTree.getModel();
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
		Matcher matcher = pattern.matcher(text);

		int matchCnt = 0;
		while (matcher.find()) {
			matchCnt++;
			int nextGroup = 1;
			String m = matcher.group();
			int start = matcher.start();
			int end = matcher.end();
			int startLineNo = inputTextArea.getLineOfOffset(start);
			int endLineNo = inputTextArea.getLineOfOffset(end);
			int startOffset = inputTextArea.getLineStartOffset(startLineNo);
			int endOffset = inputTextArea.getLineStartOffset(endLineNo);
			int lineEnd = end - endOffset;
			int lineStart = start - startOffset;

			String msg;
			if (startLineNo == endLineNo) {
				msg = "\"" + m + "\" @ " + start + ".." + end + " " + "(line "
						+ startLineNo + ", " + lineStart + ".." + lineEnd + ")";
			} else {
				msg = "\"" + m + "\" @ " + start + ".." + end + " " + "(line "
						+ startLineNo + ", " + lineStart + "..line "
						+ endLineNo + ", " + lineEnd + ")";
			}
			MatchInfo info = new MatchInfo(start, end, msg);

			MutableTreeNode mNode = new DefaultMutableTreeNode(info, true);
			root.insert(mNode, mNdx++);

			int grpCnt = matcher.groupCount();
			int pNdx = 0;
			for (; nextGroup <= grpCnt; nextGroup++) {
				String grpStr = matcher.group(nextGroup);
				if (grpStr != null) {
					String match = matcher.group(nextGroup);
					int gStart = matcher.start(nextGroup);
					int gEnd = matcher.end(nextGroup);
					startLineNo = inputTextArea.getLineOfOffset(gStart);
					endLineNo = inputTextArea.getLineOfOffset(gEnd);
					startOffset = inputTextArea
							.getLineStartOffset(startLineNo);
					endOffset = inputTextArea.getLineStartOffset(endLineNo);
					if (startLineNo == endLineNo) {
						msg = "Group " + nextGroup + ": " + "\""
								+ matcher.group(nextGroup) + "\" @ " + gStart
								+ ".." + gEnd + " " + "(line " + startLineNo
								+ ", " + lineStart + ".." + lineEnd + ")";
					} else {
						msg = "Group " + nextGroup + ": " + "\""
								+ matcher.group(nextGroup) + "\" @ " + gStart
								+ ".." + gEnd + " " + "(line " + startLineNo
								+ ", " + (gStart - startOffset) + "..line "
								+ endLineNo + ", " + (gEnd - endOffset) + ")";
					}
					info = new MatchInfo(gStart, gEnd, msg);

					MutableTreeNode pNode = new DefaultMutableTreeNode(info,
							true);
					mNode.insert(pNode, pNdx++);
				}
			}
		}
		return matchCnt;
	}

	private void loadFileAction() {
		Preferences p;
		p = Preferences.userNodeForPackage(this.getClass());
		String exImPath = p.get(PATH_PREF_NAME, ".");

		JFileChooser chooser = new JFileChooser(exImPath);
		chooser.setDialogTitle("Select File");
		// FileExtensionFilter filter;
		// filter = new FileExtensionFilter( "XML files", true );
		// filter.addExtension( "xml" );
		// chooser.setFileFilter( filter );

		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		int returnVal = chooser.showOpenDialog(this);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			clearTree();
			try {
				File currDir = chooser.getCurrentDirectory();
				p.put(PATH_PREF_NAME, currDir.getAbsolutePath());
				File selectedFile = chooser.getSelectedFile();

				FileReader in = new FileReader(selectedFile);
				inputTextArea.read(in, null);
			} catch (Exception ex) {
				processException(ex);
			}
		}
	}

	private void processException(Exception ex) {
		ex.printStackTrace();
		JOptionPane.showMessageDialog(this, ex.getMessage() + EOL
				+ "Stack trace written to stderr.", "Exception",
				JOptionPane.ERROR_MESSAGE);
	}

	private void processSyntaxException(PatternSyntaxException ex) {
		JOptionPane.showMessageDialog(this, ex.getMessage(),
				"Expression Syntax Error", JOptionPane.WARNING_MESSAGE);
	}

	public static void main(String[] args) {
            System.setProperty("apple.laf.useScreenMenuBar", "true");
            System.setProperty("com.apple.mrj.application.growbox.intrudes","false");

	    RegExTool ui = new RegExTool();
            ui.setVisible(true);
	}

	class MatchInfo {
		private int mStart;

		private int mEnd;

		private String mMessage;

		public MatchInfo(int start, int end, String msg) {
			mStart = start;
			mEnd = end;
			mMessage = msg;
		}

		public String toString() {
			return mMessage;
		}

		public int start() {
			return mStart;
		}

		public int end() {
			return mEnd;
		}
	}

}
