package edu.washington.example.security;

import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;


/**
 * Illustrates how the sign and verify a byte buffer.
 *
 * @author Russ Moul
 */
public final class SignUtil {

    /**
     * Signs a byte array using DSA.
     *
     * @param privKey the key to be used for signing
     * @param content the bytes to be signed
     *
     * @return the signature
     */
    public static byte[] encode(final PrivateKey privKey,
                                final byte[] content) {
        byte[] signature = null;

        try {
            Signature signAlgo = Signature.getInstance("DSA", "SUN");
            signAlgo.initSign(privKey);
            signAlgo.update(content);
            signature = signAlgo.sign();
        } catch (GeneralSecurityException ex) {
            System.out.println(ex);
        }

        return signature;
    }

    /**
     * Verifies a byte array against a signature using DSA.
     *
     * @param pubKey the key to be used for verification
     * @param content the bytes to be verified
     * @param sig the signature to be used in verification
     *
     * @return true if contents are un altered otherwise false
     */
    public static boolean decode(final PublicKey pubKey, final byte[] content,
                                 final byte[] sig) {
        boolean ok = false;

        try {
            Signature verifyAlgo = Signature.getInstance("DSA", "SUN");
            verifyAlgo.initVerify(pubKey);
            verifyAlgo.update(content);
            ok = verifyAlgo.verify(sig);
        } catch (GeneralSecurityException ex) {
            System.out.println(ex);
        }

        return ok;
    }
}
