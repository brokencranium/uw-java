package test;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import edu.washington.example.security.SignUtil;

/**
 * JUnit test case for the SignUtil class.
 *
 * @author Russ Moul
 */
public final class SignUtilTest extends TestCase {
    /** Key size. */
    private static final int KEY_SIZE = 512;

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public SignUtilTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the signing.
     * Signs a small message and demonstrates that the verification failes if
     * it is altered.
     *
     * @throws Exception if anything goes wrong
     */
    public void testEncodeDecode() throws Exception {
        String s = "We the people of the Unites States";
        byte[] bytes = s.getBytes();

        // Create the key pair and get the public and private keys
        KeyPairGenerator keygen;
        keygen = KeyPairGenerator.getInstance("DSA", "SUN");
        SecureRandom rand = SecureRandom.getInstance("SHA1PRNG", "SUN");
        keygen.initialize(KEY_SIZE, rand);

        KeyPair keys = keygen.genKeyPair();
        PublicKey pubKey = keys.getPublic();
        PrivateKey privKey = keys.getPrivate();

        // Sign the message and verify it
        byte[] sig = SignUtil.encode(privKey, bytes);
        boolean status = SignUtil.decode(pubKey, bytes, sig);
        assertTrue(status);

        // Alter the message and verify it
        bytes[2] = (byte) 'M';
        status = SignUtil.decode(pubKey, bytes, sig);
        assertFalse(status);
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(SignUtilTest.class));
    }
}
