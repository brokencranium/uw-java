package edu.washington.example.sockets;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;


/**
 * A simple time of day client. Joins a multicast group and reads 10 messages
 * and then exits.
 *
 * @author Russ Moul
 */
public final class TimeClient {
    /** Message buffer size. */
    private static final int BUF_SIZE = 128;

    /** The server multicast address. */
    private String mIpAddress;

    /** The server multicast port. */
    private int mPort;

    /** The numner of time messages to recieve. */
    private int mSamplings;

    /**
     * Constructor.
     *
     * @param ipAddress the multicast IP address to connect to
     * @param port the port to connect to
     * @param samplings the number of time messages to recieve before
     *        terminating, 0 for infinite
     */
    public TimeClient(final String ipAddress, final int port,
                      final int samplings) {
        mIpAddress = ipAddress;
        mPort = port;
        mSamplings = samplings;
    }

    /**
     * Joins a multicast group and reads 10 messages.
     */
    public void start() {
        MulticastSocket multiSock = null;

        try {
            InetAddress group = InetAddress.getByName(mIpAddress);
            multiSock = new MulticastSocket(mPort);
            multiSock.joinGroup(group);

            byte[] buf = new byte[BUF_SIZE];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);

            System.out.println("Get " + mSamplings + " time messages...");

            for (int i = 0; mSamplings == 0 || i < mSamplings; i++) {
                multiSock.receive(packet);
                System.out.println("TimeOfDay: "
                                 + (new String(packet.getData(), 0,
					       packet.getLength())));
            }

            multiSock.leaveGroup(group);
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            if (multiSock != null) {
                multiSock.close();
            }
        }
    }
}
