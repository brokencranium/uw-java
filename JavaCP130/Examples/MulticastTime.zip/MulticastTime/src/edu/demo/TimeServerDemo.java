package demo;

import edu.washington.example.sockets.TimeServer;

/**
 * A simple multicast client server.  Joins a multicast group and sends the
 * date/time string every second.
 *
 * @author Russ Moul
 */
public final class TimeServerDemo {
    /**
     * Prevent instantiation.
     */
    private TimeServerDemo() {
    }

    /**
     * Create the server and start it.
     *
     * @param args command line arguments, default host is 224.0.0.0
     *                  args[0] = port number
     *                        - or -
     *                  args[0] = ipaddress
     *                  args[1] = port number
     */
    public static void main(final String[] args) {
        String host = "224.0.0.1";
        int port = 0;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        } else if (args.length == 2) {
            host = args[0];
            port = Integer.parseInt(args[1]);
        } else {
            System.out.println("usage: java TimeServer [host] port");
            System.exit(0);
        }

        TimeServer server = new TimeServer(host, port);
        server.start();
    }
}
