package demo;

import edu.washington.example.sockets.TimeClient;

/**
 * Runs the time of day client.
 *
 * @author Russ Moul
 */
public final class TimeClientDemo {
    /**
     * Prevent instantiation.
     */
    private TimeClientDemo() {
    }

    /**
     * Create the client and start it.
     *
     * @param args command line arguments:
     *                  args[0] = port number
     *                        - or -
     *                  args[0] = ipaddress
     *                  args[1] = port number
     */
    public static void main(final String[] args) {
        String host = "224.0.0.1";
        int port = 0;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        } else if (args.length == 2) {
            host = args[0];
            port = Integer.parseInt(args[1]);
        } else {
            System.out.println("usage: java TimeClient [host] port");
        }

        TimeClient client = new TimeClient(host, port, 20);
        client.start();
    }
}
