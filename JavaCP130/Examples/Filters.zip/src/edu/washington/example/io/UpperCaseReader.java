package edu.washington.example.io;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;


/**
 * Converts characters to uppercase as they are read.
 * Demonstrates the use of the FilterReader class.
 *
 * @author Russ Moul
 */
public final class UpperCaseReader extends FilterReader {
    /** Working charactr buffer size */
    private static final int BUF_SIZE = 64;

    /**
     * Create a new UpperCaseReader.
     * @param r Reader to layer this UpperCaseReader upon.
     */
    public UpperCaseReader(final Reader r) {
        super(r);
    }

    /**
     * Read a single character, converting it to uppercase.
     * @return    The character read, as an integer or -1 if end of stream has
     *            been reached
     * @exception IOException If an I/O error occurs
     */
    public int read() throws IOException {
        int c = super.read();

        if (c != -1) {
            c = Character.toUpperCase((char) c);
        }

        return c;
    }

    /**
     * Read characters into a prortion of an array, converting them to
     * uppercase.
     *
     * @param cbuf array to read characters into
     * @param off offset to the beginning index of the portion of the array to
     *            use
     * @param len the lenght og the portion of the array to use
     *
     * @return    The number of characters read or -1 if end of stream has
     *            been reached
     * @exception IOException If an I/O error occurs
     */
    public int read(final char[] cbuf, final int off, final int len)
    throws IOException {
        int cnt = super.read(cbuf, off, len);

        if (cnt != -1) {
            for (int i = off; i < (off + len); i++) {
                cbuf[i] = Character.toUpperCase(cbuf[i]);
            }
        }

        return cnt;
    }
}
