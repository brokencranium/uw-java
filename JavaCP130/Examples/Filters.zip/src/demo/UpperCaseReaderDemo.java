package demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import edu.washington.example.io.UpperCaseReader;

/**
 * Converts characters to uppercase as they are read.
 * Demonstrates the use of the FilterReader class.
 *
 * @author Russ Moul
 */
public final class UpperCaseReaderDemo {
    /** Working charactr buffer size */
    private static final int BUF_SIZE = 64;

    /**
     * Prevent instantiation.
     */
    private UpperCaseReaderDemo() {
    }

    /**
     * Tests the UpperCaseReader methods.
     *
     * @param args      the String array containing command line arguments,
     *                  not used.
     */
    public static void main(final String[] args) {
        char[] ch = new char[BUF_SIZE];
        int x;

        try {
            // create the UpperCaseReader object on a file
            Reader r = new FileReader("preamble.txt");
            UpperCaseReader fr = new UpperCaseReader(r);

            // read characters and print them
            while ((x = fr.read()) != -1) {
                System.out.print((char) x);
            }

            System.out.println();
            System.out.println();

            // Recreate the UpperCaseReader object
            r = new FileReader("preamble.txt");
            fr = new UpperCaseReader(r);

            // read characters and print them
            // note: read(char[] cbuf) calls
            //       read(char[] cbuf, int off, int len)
            while ((x = fr.read(ch)) != -1) {
                System.out.print(new String(ch, 0, x));
            }

            // Recreate the UpperCaseReader object
            r = new FileReader("preamble.txt");
            fr = new UpperCaseReader(r);

            // For kicks show we can add another layer/filter
            BufferedReader br = new BufferedReader(fr);

            // read lines and print them
            System.out.println();
            System.out.println();
            String s;

            while ((s = br.readLine()) != null) {
                System.out.println(s);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
