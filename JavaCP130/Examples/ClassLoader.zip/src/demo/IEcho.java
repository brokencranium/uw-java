package demo;


/**
 * Interface for classes which have an echo operation .
 *
 * @author Russ Moul
 */
public interface IEcho {
    /**
     * Simply echos the message.
     *
     * @param msg the message to echo
     */
    void echo(String msg);
}
