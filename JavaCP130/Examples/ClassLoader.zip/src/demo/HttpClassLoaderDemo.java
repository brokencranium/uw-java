package demo;

import edu.washington.example.loader.HttpClassLoader;

/**
 * Demonstrates the use of the HttpClassLoader class loader.  If a the
 * Echo.class file can't be found the class loader will look on a web server for
 * the file.  The Echo class loads the Echo2 class so if Echo2.class can't be
 * found ti will also be loaded from the web server.
 *
 * @author Russ Moul
 */
public final class HttpClassLoaderDemo {
    /**
     * Prevent instantiation.
     */
    private HttpClassLoaderDemo() {
    }

    /**
     * Loads the Echo class using the HttpClassLoaderLoader class loader.
     *
     * @param args  arg[0] is the web server to obtain classes from
     */
    public static void main(final String[] args) {
        try {
            ClassLoader loader = new HttpClassLoader(args[0]);
            Class echoClass = loader.loadClass("demo.Echo");
            Object tmp = echoClass.newInstance();
            IEcho e1 = (IEcho) tmp;
            e1.echo("Hello");
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }
    }
}
