package demo;


/**
 * Simple class solely for the purpose of demonstrating the class loaders.
 */
public final class Echo2 {
    /**
     * Default constructor.
     */
    public Echo2() {
    }

    /**
     * Prints the message to System.out prepended by the name og this class,
     * "Echo2".
     *
     * @param msg the message to echo
     */
    public void echo(final String msg) {
        System.out.println("Echo2: " + msg);
    }
}
