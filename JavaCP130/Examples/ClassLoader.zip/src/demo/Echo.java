package demo;


/**
 * Simple class implementing the IEcho interface.  Solely for the purpose of
 * demonstrating the class loaders.
 */
public final class Echo implements IEcho {
    /**
     * Default constructor.
     */
    public Echo() {
    }

    /**
     * Uses an Echo2 object to echo the message and then prints the message to
     * System.out.
     *
     * @param msg the message to echo
     */
    public void echo(final String msg) {
        Echo2 e = new Echo2();
        e.echo(msg);
        System.out.println(msg);
    }
}
