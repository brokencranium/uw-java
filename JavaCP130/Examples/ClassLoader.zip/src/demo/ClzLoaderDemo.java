package demo;

import edu.washington.example.loader.ClzLoader;

/**
 * Demonstrates the use of the ClzLoader class loader.  If a the Echo.class
 * file can't be found the class loader will look for Echo.clz.  The Echo class
 * loads the Echo2 class so if Echo2.class can't be found Echo.clz will be
 * looked for.  However the only classes which can be loaded by the ClzLoader
 * are those used by other classes it has loaded, to illistrate this this class,
 * which is not loaded by ClzLoader, will attempt to instantiate an instance of
 * the Echo2 class if an argument is passed at startup, if Echo2.class is not
 * present this instantiation will fail.
 *
 * @author Russ Moul
 */
public final class ClzLoaderDemo {
    /**
     * Prevent instantiation.
     */
    private ClzLoaderDemo() {
    }

    /**
     * Loads the Echo class using the ClzLoader class loader, optionally
     * attempts to use the Echo2 class.
     *
     * @param args if any arguments are provided create and use an instance of
     *             the Echo2 class.
     */
    public static void main(final String[] args) {
        try {
            ClassLoader loader = new ClzLoader();
            Class echoClass = loader.loadClass("demo.Echo");
            Object tmp = echoClass.newInstance();
            IEcho e1 = (IEcho) tmp;
            e1.echo("Hello");

            // If arguments provided try to use Echo2
            if (args.length > 0) {
                Echo2 e2 = new Echo2();
                e2.echo("World!");
            }
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }
    }
}
