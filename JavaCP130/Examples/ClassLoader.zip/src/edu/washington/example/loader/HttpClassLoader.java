package edu.washington.example.loader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import java.net.MalformedURLException;
import java.net.URL;


/**
 * Simple class loader which loads classes from a web servers.  This ClassLoader
 * uses the 'delegation' approach, and will only be invoked if the parent
 * ClassLoader is unable to locate the class.  This ClassLoader illustrates how
 * classes could be loaded from an alternate location/source.
 *
 * @author Russ Moul
 */
public final class HttpClassLoader extends ClassLoader {
    /** HTTP default port. */
    private static final int DEFAULT_HTTP_PORT = 80;
    /** Working buffer size. */
    private static final int BUF_SIZE = 4096;

    /** URL root to look for classes at. */
    private URL mClassSource;

    /**
     * Constructor, configures HTTP host information.
     *
     * @param host HTTP host
     */
    public HttpClassLoader(final String host) {
        this(host, DEFAULT_HTTP_PORT);
    }

    /**
     * Constructor, configures HTTP host information.
     *
     * @param host HTTP host
     * @param port HTTP port on host
     */
    public HttpClassLoader(final String host, final int port) {
        try {
            mClassSource = new URL("http://" + host + ":" + port);
        } catch (MalformedURLException mex) {
            System.out.println(mex);
            mex.printStackTrace();
        } catch (SecurityException sex) {
            System.out.println(sex);
            sex.printStackTrace();
        }
    }

    /**
     * Locates the class file and loads it.
     *
     * @param name the name of the class
     *
     * @return the resulting Class object
     */
    public Class findClass(final String name) {
        System.out.println("Loading class " + name + " using HttpClassLoader");

        byte[] b = loadClassData(name);
        Class clazz = defineClass(name, b, 0, b.length);
        resolveClass(clazz);

        return clazz;
    }

    /**
     * Reads the contents of the class file using HTTP and returns it as an
     * array of bytes.
     *
     * @param name the name of the class
     *
     * @return contents of class file
     */
    private byte[] loadClassData(final String name) {
        // Construct the file name
        String fname = name.replace('.', '/');
        fname = fname + ".class";

        // Load the class data from the connection
        byte[] buf = null;

        try {
            InputStream in;
            URL classUrl = new URL(mClassSource, fname);
            in = classUrl.openStream();

            ByteArrayOutputStream osBuf = new ByteArrayOutputStream(BUF_SIZE);
            int len;
            buf = new byte[BUF_SIZE];

            while ((len = in.read(buf)) != -1) {
                osBuf.write(buf, 0, len);
            }

            buf = osBuf.toByteArray();
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }

        return buf;
    }
}
