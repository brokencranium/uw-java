package edu.washington.example.loader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;


/**
 * Simple class loader which loads classes from '.clz' files.  This ClassLoader
 * uses the 'delegation' approach, and will only be invoked if the parent
 * ClassLoader is unable to locate the class.  This ClassLoader illustrates how
 * classes could be loaded from an alternate location/source.
 *
 * @author Russ Moul
 */
public final class ClzLoader extends ClassLoader {
    /** Working buffer size */
    private static final int BUF_SIZE = 4096;

    /**
     * Default constructor.
     */
    public ClzLoader() {
    }

    /**
     * Locates the class file and loads it.
     *
     * @param name the name of the class
     *
     * @return the resulting Class object
     */
    public Class findClass(final String name) {
        System.out.println("Loading class " + name + " using ClzLoader");

        byte[] b = loadClassBytes(name);
        Class clazz = defineClass(name, b, 0, b.length);

        return clazz;
    }

    /**
     * Reads the contents of the class file using the .clz suffix and returns it
     * as an array of bytes.
     *
     * @param name the name of the class
     *
     * @return contents of class file
     */
    private byte[] loadClassBytes(final String name) {
        // Construct the file name
        String fname = name.replace('.', '/');
        fname = fname + ".clz";

        // Load the class data
        byte[] buf = null;

        try {
            InputStream in;
            in = getResourceAsStream(fname);

            ByteArrayOutputStream osBuf = new ByteArrayOutputStream(BUF_SIZE);
            int len;
            buf = new byte[BUF_SIZE];

            while ((len = in.read(buf)) != -1) {
                osBuf.write(buf, 0, len);
            }

            buf = osBuf.toByteArray();
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }

        return buf;
    }
}
