package demo;

import java.io.IOException;

import edu.washington.example.sockets.HttpClient;

/**
 * Executes the HTTP client.
 *
 * @author Russ Moul
 */
public final class HttpClientDemo {
    /** Index to host argument */
    private static final int HOST_ARG = 0;

    /** Index to port argument */
    private static final int PORT_ARG = 1;

    /** Index to file argument */
    private static final int FILE_ARG = 2;

    /**
     * Prevent instantiation.
     */
    private HttpClientDemo() {
    }

    /**
     * Tests the HttpClient class.
     * @param args input arguments args[0] = hostname,
     *                             args[1] = port,
     *                             args[2] = filename
     *
     * @throws IOException - if reads from the HTTP server fail
     */
    public static void main(final String[] args) throws IOException {
        String host = "127.0.0.1";
        int port = HttpClient.DEFAULT_HTTP_PORT;
        String fileName = "/";

        // check for input arguments
        if (args.length >= HOST_ARG + 1) {
            host = args[HOST_ARG];
        }

        if (args.length >= PORT_ARG + 1) {
            port = Integer.parseInt(args[PORT_ARG]);
        }

        if (args.length >= FILE_ARG + 1) {
            fileName = args[FILE_ARG];
        }

        HttpClient browser = new HttpClient(host, port);

        browser.get(fileName);
    }
}
