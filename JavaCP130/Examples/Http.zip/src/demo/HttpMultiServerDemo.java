package demo;

import edu.washington.example.sockets.HttpMultiServer;

/**
 * Executes a simple multi threaded HTTP server.
 *
 * @author Russ Moul
 */
public final class HttpMultiServerDemo {
    /**
     * Prevent instantiation.
     */
    private HttpMultiServerDemo() {
    }

    /**
     * Creates an HTTP server on the specified port and starts it.
     *
     * @param args args[0] my optionally contain the port number
     */
    public static void main(final String[] args) {
        int port = HttpMultiServer.DEFAULT_HTTP_PORT;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        }

        HttpMultiServer server = new HttpMultiServer(port);
        server.serve();
    }
}
