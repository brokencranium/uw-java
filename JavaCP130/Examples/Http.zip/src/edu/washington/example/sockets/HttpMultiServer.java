package edu.washington.example.sockets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;

import java.net.ServerSocket;
import java.net.Socket;

/**
 * Simple HTTP server suporting only the GET method and assumes all files
 * are HTML.
 *
 * @author Russ Moul
 */
public final class HttpMultiServer {
    /** The default HTTP port */
    public static final int DEFAULT_HTTP_PORT = 80;

    /** The HTTP port */
    private int mPort;

    /**
     * Constructor. Uses the default HTTP port.
     */
    public HttpMultiServer() {
        this(DEFAULT_HTTP_PORT);
    }

    /**
     * Constructor.
     *
     * @param port the port on the HTTP server to connect to
     */
     public HttpMultiServer(final int port) {
        mPort = port;
    }

    /**
     * Creates a listining socket and waits for a connection.  When a connection
     * is received a work thread is created to process the request and this
     * thread resumes listening.
     */
    public void serve() {
        ServerSocket servSock = null;

        try {
            System.out.println("Server Ready!");
            System.out.println();
            servSock = new ServerSocket(mPort);

            while (true) {
                Socket sock = servSock.accept(); // blocks
                HttpRequest req = new HttpRequest(sock);
                Thread t = new Thread(req);
                t.start();
            }
        } catch (IOException ex) {
            System.err.println("Server error: " + ex);
        } finally {
            if (servSock != null) {
                try {
                    servSock.close();
                } catch (IOException ioex) {
                    System.err.println("Error closer server socket. " + ioex);
                }
            }
        }
    }
}


/**
 * Process an HTTP request, the only method supported is GET.
 */
final class HttpRequest implements Runnable {

    /** Working buffer size. */
    private static final int BUF_SIZE = 4096;

    /** Offset to the request type of the HTTP header */
    private static final int HTTP_REQUEST_OFFSET = 5;

    /** The request socket */
    private Socket mSocket;

    /**
     * Constructor.
     *
     * @param sock the request socket
     */
    public HttpRequest(final Socket sock) {
        mSocket = sock;
    }

    /**
     * Writes a file to the output stream.  File contents are preceeded with
     * an HTTP header indicating the file type is HTML.
     *
     * @param outStrm output stream to write file contents to
     * @param fileName name of file to write to stream
     *
     * @throws IOException if unable to read the file or write it out
     */
    private void get(final OutputStream outStrm, final String fileName)
        throws IOException {
        PrintWriter wrtr = new PrintWriter(outStrm);
        File file = new File(fileName);

        if (file.exists() && file.canRead() && file.isFile()) {
            FileInputStream inStrm = new FileInputStream(file);

            // assume html
            String header = "HTTP/1.0 200 OK\n"
                          + "Content-Type: text/html\n"
                          + "Content-Length: " + file.length() + "\n\n";

            wrtr.print(header);
            wrtr.flush();

            Reader rdr = new InputStreamReader(inStrm);
            BufferedReader br = new BufferedReader(rdr);
            int bytesRead;
            byte[] buf = new byte[BUF_SIZE];

            while ((bytesRead = inStrm.read(buf)) != -1) {
                outStrm.write(buf, 0, bytesRead);
            }

            br.close();
        } else { // can't locate or access the file
            String msg = "<html>"
                + "<head><title>Error 404 Object Not Found</title></head>"
                + "<body>Server could not find the requested file.</body>"
                + "</html>";
            String header = "HTTP/1.0 404 Object Not Found\n"
                + "Content-Type: text/html\n"
                + "Content-Length: " + msg.length() + "\n\n";
            wrtr.print(header + msg);
            wrtr.flush();
        }
    }

    /**
     * Waits for a connection and processes the request.  Only the HTML GET
     * method is supported.
     */
    public void run() {
        InputStream inStrm = null;
        OutputStream outStrm = null;

        try {
            inStrm = mSocket.getInputStream();

            Reader rdr = new InputStreamReader(inStrm);
            BufferedReader br = new BufferedReader(rdr);
            outStrm = mSocket.getOutputStream();

            String request = br.readLine();

            System.out.println("Request: " + request);

            // parse request - only support GET
            if (request.startsWith("GET /")) {
                // get filename stripping leading '/'
                int endNdx = request.lastIndexOf(" HTTP/");
                String fileName;
                fileName = request.substring(HTTP_REQUEST_OFFSET, endNdx);
                get(outStrm, fileName);
            } else {
                String msg = "<html>"
                    + "<head><title>Method Not Supported</title></head>"
                    + "<body>The specified method is not supported.<p>"
                    + request + "</body>" + "</html>";
                String header = "HTTP/1.0 501 Not Supported\n"
                    + "Content-Type: text/html\n" + "Content-Length: "
                    + msg.length() + "\n\n";
                PrintWriter wrtr = new PrintWriter(outStrm, true);
                wrtr.println(header + msg);
            }
        } catch (IOException ex) {
            System.err.println("Server error: " + ex);
            ex.printStackTrace();
        } finally {
            try {
                if (inStrm != null) {
                    inStrm.close();
                }

                if (outStrm != null) {
                    outStrm.close();
                }

                if (mSocket != null) {
                    mSocket.close();
                }
            } catch (IOException ioex) {
                System.err.println("Error closing streams or socket. " + ioex);
            }
        }
    }
}
