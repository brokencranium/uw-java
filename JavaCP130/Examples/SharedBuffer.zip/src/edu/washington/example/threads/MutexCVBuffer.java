package edu.washington.example.threads;

/**
 * A simple single element shared buffer.  This implementation of IBuffer is
 * thread-safe and was implemented using mutexes and condition-variables.
 *
 * @author Russ Moul
 */
public final class MutexCVBuffer implements Buffer {
    /** The buffer. */
    private int mBuf;

    /** Space available condition variable. */
    private ConditionVariable mSpaceAvailable = new ConditionVariable(true);

    /** Items available condition variable. */
    private ConditionVariable mItemAvailable = new ConditionVariable(false);

    /** Mutex for controlling adding to the buffer. */
    private Mutex mPutMutex = new Mutex();

    /** Mutex for controlling removing from the buffer. */
    private Mutex mGetMutex = new Mutex();

    /**
     * Places a value in the buffer.
     *
     * @param value the value to be placed in the buffer
     */
    public void put(final int value) {
        mPutMutex.lock();
        mSpaceAvailable.cvWait();
        mBuf = value;
        mSpaceAvailable.set(false);
        mItemAvailable.cvSignal();
        mPutMutex.unlock();
    }

    /**
     * Gets a value from the buffer.
     *
     * @return a value from the buffer
     */
    public int get() {
        int value;
        mGetMutex.lock();
        mItemAvailable.cvWait();
        value = mBuf;
        mItemAvailable.set(false);
        mSpaceAvailable.cvSignal();
        mGetMutex.unlock();

        return value;
    }
}
