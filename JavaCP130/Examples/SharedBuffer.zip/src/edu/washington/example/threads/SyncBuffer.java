package edu.washington.example.threads;

/**
 * A simple single element shared buffer.  This implementation of Buffer is
 * thread-safe and was implemented using synchronized blocks.
 *
 * @author Russ Moul
 */
public final class SyncBuffer implements Buffer {
    /** The buffer. */
    private int mBuf;

    /** Space available condition variable. */
    private Bool mSpaceAvailableCV = new Bool(true);

    /** Items available condition variable. */
    private Bool mItemAvailableCV = new Bool(false);

    /** Mutex for controlling adding to the buffer. */
    private Object[] mPutMutex = {};

    /** Mutex for controlling removing from the buffer. */
    private Object[] mGetMutex = {};

    /**
     * Places a value in the buffer.
     *
     * @param value the value to be placed in the buffer
     */
    public void put(final int value) {
        synchronized (mPutMutex) {
            // Place item in buffer
            synchronized (mSpaceAvailableCV) {
                while (!mSpaceAvailableCV.get()) {
                    try {
                        mSpaceAvailableCV.wait();
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }

                mBuf = value;
                mSpaceAvailableCV.set(false);
            }

            // Notify an item is available
            synchronized (mItemAvailableCV) {
                mItemAvailableCV.set(true);
                mItemAvailableCV.notify();
            }
        }
    }

    /**
     * Gets a value from the buffer.
     *
     * @return a value from the buffer
     */
    public int get() {
        int value;

        synchronized (mGetMutex) {
            // Remove item from buffer
            synchronized (mItemAvailableCV) {
                while (!mItemAvailableCV.get()) {
                    try {
                        mItemAvailableCV.wait();
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }

                value = mBuf;
                mItemAvailableCV.set(false);
            }

            // Notify space is available
            synchronized (mSpaceAvailableCV) {
                mSpaceAvailableCV.set(true);
                mSpaceAvailableCV.notify();
            }
        }

        return value;
    }

    /**
     * A simple mutable alternative to the Boolean class.
     */
    final class Bool {
        /** The state of this boolean. */
        private boolean mState;

        /**
         * Constructs a Bool with a specific initial state.
         *
         * @param state the initial state
         */
        Bool(final boolean state) {
            mState = state;
        }

        /**
         * Sets the state of this Bool.
         *
         * @param state the state the bool is to be set to
         */
        void set(final boolean state) {
            mState = state;
        }

        /**
         * Gets the state of the Bool.
         *
         * @return The current state of this Bool
         */
        boolean get() {
            return mState;
        }
    }
}
