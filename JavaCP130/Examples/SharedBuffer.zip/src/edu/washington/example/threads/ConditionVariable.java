package edu.washington.example.threads;

/**
 * A simple implementation of a boolean condition variable.
 *
 * @author Russ Moul
 */
public final class ConditionVariable {
    /** The actual variable. */
    private boolean mConditionMet = false;

    /**
     * Creates a condition variable setting its initial state.
     *
     * @param conditionMet the initial state
     */
    public ConditionVariable(final boolean conditionMet) {
        mConditionMet = conditionMet;
    }

    /**
     * Waits for the conditions variable to be signaled.
     */
    public synchronized void cvWait() {
        while (!mConditionMet) {
            try {
                wait();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Sets the state of the condition variable.
     *
     * @param conditionMet the initial state
     */
    public synchronized void set(final boolean conditionMet) {
        mConditionMet = conditionMet;
    }

    /**
     * Sets the condition to true and signals (notifies) any waiting threads.
     */
    public synchronized void cvSignal() {
        mConditionMet = true;
        notify();
    }
}
