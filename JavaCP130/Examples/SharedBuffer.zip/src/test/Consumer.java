package test;

import java.util.Arrays;

import edu.washington.example.threads.Buffer;

/**
 * A simple consumer which consumers a sequence of integers and valudates there
 * no duplicates or ommisions in the sequence.  The validations is performed
 * using a history/checking buffer maintained by the class, if more than one
 * instance of this class consumes the same integer value it will be detected
 * and an error reported.  Each consumer will consume integers until the
 * history/checking buffer is full.
 *
 * @author Russ Moul
 */
public class Consumer extends Thread {
    /** The history buffer size. */
    /** The history buffer. */
    private int[] mChecker;

    /** The shared buffer. */
    private Buffer mBuf;

    /** The consumers name. */
    private String mName;

    /**
     * Crates a consumer giving it a name and specifying the buffer it is to
     * consume integers from.
     *
     * @param name an identifying name for this thread
     * @param buffer the buffer to consume values from
     * @param checkBuf the buffer to be used for checking
     */
    public Consumer(String name, Buffer buffer, int[] checkBuf) {
        mName = name;
        mBuf = buffer;
        mChecker = checkBuf;
    }

    /**
     * Reset check buffer.
     */
    public static void resetBuffer(int[] checkBuf) {
        Arrays.fill(checkBuf, 0);
    }

    /**
     * Verifies there are no gaps in the buffer. 
     *
     * @param checkBuf the buffer to be used for checking
     *
     * @return true if there are no gaps in the buffer. 
     */
    public static boolean checkBuffer(int[] checkBuf) {
        for (int j = 0; j < checkBuf.length; j++) {
            if (checkBuf[j] != -1) {
                System.err.println("Element " + j + " not set");
                return false;
            }
        }
        return true;
    }

    /**
     * Does the work, will consume integers until the history/check buffer is
     * full.  Once the buffer is full it is evaluated for ommisions.  If at any
     * time a value is encountered which is already recorded in the
     * history/check buffer an error is reported.
     */
    public void run() {
        while (true) {
            int i = mBuf.get();

            try {
                if (mChecker[i] == 0) // this value has not been used
                 {
                    mChecker[i] = -1;
                } else { // mark value as used
                    System.out.println("Error: index = " + i +
                        " overwriting existing value!");
                    System.exit(0);
                }
            } catch (ArrayIndexOutOfBoundsException ex) { // buffer is full
                return;
            }

            // cause an artificial delay
            int delay = (int) (Math.random() * 10.0);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}
