package edu.washington.example.loader;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageProducer;

import java.net.URL;


/**
 * Loads image files as resources and creates images. Resources are loaded from
 * the classpath.
 *
 * @author Russ Moul
 */
public final class ImageLoader {
    /**
     * Prevent instantiation.
     */
    private ImageLoader() {
    }

    /**
     * Loads an image resource.
     *
     * @param name the path to the resource
     *
     * @return the loaded image
     */
    public static Image loadImage(final String name) {
        URL url = null;
        url = ClassLoader.getSystemResource(name);

        Image theImage = null;

        try {
            ImageProducer producer;
            producer = (ImageProducer) url.getContent();

            Toolkit tool = Toolkit.getDefaultToolkit();
            theImage = tool.createImage(producer);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return theImage;
    }
}
