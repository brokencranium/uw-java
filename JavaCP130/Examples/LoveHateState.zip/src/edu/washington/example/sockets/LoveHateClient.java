package edu.washington.example.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;

import java.net.Socket;

/**
 * A simple implementation of the love/hate client.
 *
 * @author Russ Moul
 */
public final class LoveHateClient {
    /** Love me choice. */
    private static final int LOVE_ME_CHOICE = 1;

    /** Hate me choice. */
    private static final int HATE_ME_CHOICE = 2;

    /** Why choice. */
    private static final int WHY_CHOICE = 3;

    /** Quit choice. */
    private static final int QUIT_CHOICE = 4;

    /** The host address or name. */
    private String mHost;

    /** The connect port. */
    private int mPort;

    /** The connected socket. */
    private Socket mSocket;

    /** Allows reading complete lines from the socket. */
    private BufferedReader mBufReader;

    /** Allows the use of println when writing to the socket. */
    private PrintWriter mWriter;

    /**
     * Constructor.
     *
     * @param host the host address or name.
     * @param port the connect port.
     *
     */
    public LoveHateClient(final String host, final int port) {
        mHost = host;
        mPort = port;
    }

    /**
     * Establish the connection.
     *
     * @throws IOException if the connection can not be established
     */
    public void connect() throws IOException {
        // establich connection
        mSocket = new Socket(mHost, mPort);

        OutputStream outStrm = mSocket.getOutputStream();
        mWriter = new PrintWriter(outStrm, true);

        InputStreamReader rdr = new InputStreamReader(mSocket.getInputStream());
        mBufReader = new BufferedReader(rdr);
    }

    /**
     * Prints prompts to and accepts prompts from the console.
     *
     * @throws IOException if a console error occurs
     */
    public void acceptCommands() throws IOException {
        Reader reader = new InputStreamReader(System.in);
        BufferedReader bufReader = new BufferedReader(reader);

        while (true) {
            String command;

            System.out.println();
            System.out.println("Commands available on server:");
            System.out.println("   1) Love me ?");
            System.out.println("   2) Hate me ?");
            System.out.println("   3) Why ?");
            System.out.println("   4) Quit ?");
            System.out.println();
            System.out.print("Select command: ");

            int choice = -1;

            String line = null;
            try {
                line = bufReader.readLine();
                choice = Integer.parseInt(line);
            } catch (NumberFormatException dfex) {
                System.out.println();
                System.out.println("Invalid input, '" + line + "'");
                System.out.println();
                continue;
            } catch (Exception ex) {
                ex.printStackTrace();
                return;
            }

            switch (choice) {
            case LOVE_ME_CHOICE:
                command = "loveme";
                break;

            case HATE_ME_CHOICE:
                command = "hateme";
                break;

            case WHY_CHOICE:
                command = "why";
                break;

            case QUIT_CHOICE:
                command = "quit";
                break;

            default:
                System.out.println();
                System.out.println("Invalid Selection!");
                System.out.println();
                continue;
            }

            mWriter.println(command);

            String reply = mBufReader.readLine();

            System.out.println();
            System.out.println(reply);

            if (choice == QUIT_CHOICE) {
                break;
            }
        }
    }

    /**
     * Disconnect, close the socket.
     *
     * @throws IOException if a socket closure failes
     */
    public void disconnect() throws IOException {
        mSocket.close();
    }

    /**
     * Runs the class.
     *
     * @param args input arguments args[0] = hostname,
     *                             args[1] = port,
     *                             args[2] = filename
     *
     * @throws IOException if any are thrown
     */
    public static void main(final String[] args) throws IOException {
        // check for input arguments
        if (args.length != 2) {
            System.out.println("Host and port are required");
            System.exit(0);
        }

        String host = args[0];
        int port = Integer.parseInt(args[1]);

        LoveHateClient client = new LoveHateClient(host, port);
        client.connect();
        client.acceptCommands();
        client.disconnect();
    }
}
