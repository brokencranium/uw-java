package demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import java.util.Vector;


/**
 * Demonstrates the use of the RandomAccessFile class.
 */
public final class RandomReadDemo {
    /** Test iterations. */
    private static final int MAX_ITERATIONS = 10;
    /** The random access file */
    private RandomAccessFile mRandomFile;

    /** Index into the random access file. */
    private Vector mIndex = new Vector();

    /**
     * Constructor.  Opens the file for random access and builds the index.
     * The file to be indexed contains an arbitrary number of arbitrary length
     * strings delimited by '$$'.
     *
     * @param fileName the name of the file to be indexed
     *
     * @throws FileNotFoundException if unable to locate the file
     */
    public RandomReadDemo(final String fileName) throws FileNotFoundException {
        File f = new File(fileName);
        mRandomFile = new RandomAccessFile(f, "r");
        index();
    }

    /**
     * Construct the index.
     */
    private void index() {
        int textChar;
        mIndex.addElement(new Long(0));

        try {
            while ((textChar = mRandomFile.read()) != -1) {
                if ((char) textChar == '$') {
                    textChar = mRandomFile.read();

                    if ((char) textChar == '$') {
                        mIndex.addElement(
                                      new Long(mRandomFile.getFilePointer()));
                    } else if (textChar == -1) {
                        break;
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Print one of the strings from the file.  An index is selected randomly
     * and its offset and the string itself is printed.
     */
    public void printOne() {
        try {
            int ndx = (int) (Math.random() * mIndex.size());
            long offset = ((Long) mIndex.elementAt(ndx)).longValue();
            System.out.println("Offset:" + offset);
            mRandomFile.seek(offset);
            System.out.print("String = '");

            int textChar;

            while ((textChar = mRandomFile.read()) != -1) {
                if (textChar == '$') {
                    if ((textChar = mRandomFile.read()) == '$') {
                        break;
                    } else {
                        System.out.print('$');
                    }
                }

                System.out.print((char) textChar);
            }

            System.out.println("'");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Exercise the class.
     *
     * @param args args[0] is the name of the file to process
     *
     * @throws IOException id anything at all goes wrong
     */
    public static void main(final String[] args) throws IOException {
        String fileName = "presidents.dat";

        if (args.length > 0) {
            fileName = args[0];
        }

        RandomReadDemo rr = new RandomReadDemo(fileName);

        for (int i = 0; i < MAX_ITERATIONS; i++) {
            rr.printOne();
        }
    }
}
