package edu.washington.example.sockets;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

/**
 * Encapsulates the client side request.  A method is provided for each request,
 * each method sends the request string to the server and recieved the response,
 * isolateing these details from the client.
 *
 * @author Russ Moul
 */
public final class RequestStub implements RequestStateInf {
    /** Allows reading complete lines of text from the socket. */
    private BufferedReader mBufReader;

    /** Provides the println method for writing to the server. */
    private PrintWriter mWriter;

    /**
     * Constructor.
     *
     * @param in the socket input stream
     * @param out the socket outut stream
     */
    public RequestStub(final InputStream in, final OutputStream out) {
        InputStreamReader rdr = new InputStreamReader(in);
        mBufReader = new BufferedReader(rdr);
        mWriter = new PrintWriter(out, true);
    }

    /**
     * Sends the request string and then reads the response.
     *
     * @param command the command string
     *
     * @return the response string
     *
     * @throws IOException if communication with the server fails
     */
    private String sendRequest(final String command) throws IOException {
        mWriter.println(command);

        String response = mBufReader.readLine();

        return response;
    }

    /**
     * Sends the "loveme" command.
     *
     * @return the response
     */
    public String loveme() {
        try {
            return sendRequest("loveme");
        } catch (IOException ex) {
            return "Server error";
        }
    }

    /**
     * Sends the "hateme" command.
     *
     * @return the response
     */
    public String hateme() {
        try {
            return sendRequest("hateme");
        } catch (IOException ex) {
            return "Server error";
        }
    }

    /**
     * Sends the "why" command.
     *
     * @return the response
     */
    public String why() {
        try {
            return sendRequest("why");
        } catch (IOException ex) {
            return "Server error";
        }
    }

    /**
     * Sends the "quit" command.
     *
     * @return the response
     */
    public String quit() {
        try {
            return sendRequest("quit");
        } catch (IOException ex) {
            return "Server error";
        }
    }
}
