package edu.washington.example.sockets;

/**
 * Interface for the client side stub and server side request classes.
 *
 * @author Russ Moul
 */
public interface RequestStateInf {
    /**
     * The loveme request handler.
     *
     * @return "I love you"
     */
    String loveme();

    /**
     * The hateme request handler.
     *
     * @return "No I don't hate you"
     */
     String hateme();

    /**
     * The why request handler.
     *
     * @return a response appropriate for the current conversation state
     */
    String why();

    /**
     * The quit request handler.
     *
     * @return "Bye."
     */
    String quit();
}
