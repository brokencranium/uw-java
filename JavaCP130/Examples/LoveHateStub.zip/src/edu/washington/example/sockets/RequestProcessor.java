package edu.washington.example.sockets;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.net.Socket;

/**
 * A request processor for the love/hate server. A request state object is used
 * to encapsulate the behavior of each request and maintain the state of the
 * conversation.
 *
 * @author Russ Moul
 */
public final class RequestProcessor implements Runnable {
    /** The request socket. */
    private Socket mSocket;

    /** The request state object. */
    private RequestState mReqState = new RequestState();

    /**
     * Constructor.
     *
     * @param sock the request socket
     */
    public RequestProcessor(final Socket sock) {
        mSocket = sock;
    }

    /**
     * Processes request on the socket.
     */
    public void run() {
        InputStream inStrm = null;
        OutputStream outStrm = null;

        try {
            boolean more = true;
            inStrm = mSocket.getInputStream();

            InputStreamReader in = new InputStreamReader(inStrm);
            BufferedReader br = new BufferedReader(in);
            outStrm = mSocket.getOutputStream();

            PrintWriter wrtr = new PrintWriter(outStrm, true);

            while (more) {
                String command = br.readLine();

                if (command.equals("loveme")) {
                    wrtr.println(mReqState.loveme());
                } else if (command.equals("hateme")) {
                    wrtr.println(mReqState.hateme());
                } else if (command.equals("why")) {
                    wrtr.println(mReqState.why());
                } else if (command.equals("quit")) {
                    wrtr.println(mReqState.quit());
                    more = false;
                }
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            try {
                if (inStrm != null) {
                    inStrm.close();
                }

                if (outStrm != null) {
                    outStrm.close();
                }

                if (mSocket != null) {
                    mSocket.close();
                }
            } catch (IOException ioex) {
                ioex.printStackTrace();
            }
        }
    }
}
