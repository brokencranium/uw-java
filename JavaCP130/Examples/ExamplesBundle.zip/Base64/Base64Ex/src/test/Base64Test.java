package test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.util.Arrays;
import java.util.Random;


/**
 * JUnit test case demonstrating the use of the undocumented BASE64Encoder and
 * BASE64Decoder classes.
 */
public class Base64Test extends TestCase {
    private Random random;

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public Base64Test(String testName) {
        super(testName);
    }

    /**
     * Initialize the test fixture.  Initializes variables used by the various
     * tests.
     */
    protected void setUp() {
        random = new Random();
    }

    /**
     * Constructs a suite of tests.
     *
     * @return the test suite
     */
    public static Test suite() {
        TestSuite suite = new TestSuite();
        suite.addTest(new Base64Test("testEncodeDecode"));

        return suite;
    }

    /**
     * Tests the encode and decode methods.
     */
    public void testEncodeDecode() throws Exception {
        int bufSize = 0;

        do {
            bufSize = random.nextInt(4096);
        } while (bufSize == 0);

        System.out.println();
        System.out.println("Buffer size: " + bufSize);

        byte[] byteArray = new byte[bufSize];
        random.nextBytes(byteArray);

        // Encode the bytes
        BASE64Encoder encoder = new BASE64Encoder();
        String encoded = encoder.encode(byteArray);

        // Decode the bytes
        BASE64Decoder decoder = new BASE64Decoder();
        byte[] newByteArray = decoder.decodeBuffer(encoded);

        assertTrue(Arrays.equals(byteArray, newByteArray));
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(new TestSuite(Base64Test.class));
    }
}
