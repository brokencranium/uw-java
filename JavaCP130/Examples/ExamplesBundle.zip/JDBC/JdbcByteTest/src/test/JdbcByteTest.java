package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test of an SQL VARBINARY field for holding a byte array.
 *
 * @author Russ Moul
 */
public final class JdbcByteTest extends TestCase {

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public JdbcByteTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the externalization.
     */
    public void testVarBinary() throws Exception {
        Connection conn = null;
        String dbUrl = "jdbc:hsqldb:ByteTestDB";
        String driverClassName = "org.hsqldb.jdbcDriver";
        String username = "sa";
        String password = "";

        Class.forName(driverClassName);
        conn = DriverManager.getConnection(dbUrl, username, password);

        Statement stmnt = conn.createStatement();
        ResultSet rs;

        // CREATE TABLE
        stmnt.executeUpdate("CREATE TABLE test_tab "
                         + "( name VARCHAR PRIMARY KEY,"
                         + "  data VARBINARY )");

        // INSERT
        PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO test_tab (name, data) " + "VALUES ( ?, ? )");
        ps.setString(1, "record 1");

        byte[] data = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
                       10, 11, 12, 13, 14, 15, 16, 17, 18, 19};
        ps.setBytes(2, data);

        int cnt = ps.executeUpdate();

        // SELECT
        rs = stmnt.executeQuery("SELECT name, data" + "  FROM test_tab");

        if (rs.next()) {
            byte[] dat = rs.getBytes("data");
            assertTrue(Arrays.equals(data, dat));
        } else {
            fail("Empty result set.");
        }
        conn.close();
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(JdbcByteTest.class));
    }
}
