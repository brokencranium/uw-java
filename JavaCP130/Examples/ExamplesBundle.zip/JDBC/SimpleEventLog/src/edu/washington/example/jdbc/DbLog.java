package edu.washington.example.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

/**
 * A simple database logging implementation.
 *
 * @author Russ Moul
 */
public final class DbLog {
    /** Database URL. */
    private String mDbUrl;

    /** SQL driver class. */
    private String mDriverClassName;

    /** Database username. */
    private String mUsername = "sa";

    /** Database password. */
    private String mPassword = "";

    /**
     * Constructor.  Initializes variables required to make a DB connection.
     *
     * @param dbName the database URL
     * @param driverClassName the name of the SQL driver class
     * @param username the username
     * @param password the password
     *
     * @throws SQLException if any database operations fail
     * @throws ClassNotFoundException if the database drive class can't be
     *                                loaded
     */
    public DbLog(final String dbName, final String driverClassName,
                 final String username, final String password)
                 throws SQLException, ClassNotFoundException {
        mDbUrl = dbName;
        mDriverClassName = driverClassName;
        mUsername = username;
        mPassword = password;
        Class.forName(driverClassName);
    }

    /**
     * Adds a message to the event log table.
     *
     * @param msg the message
     *
     * @return true if logged successfully
     */
    public boolean logMessage(final String msg) {
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(mDbUrl, mUsername, mPassword);

            Statement stmnt = conn.createStatement();
            stmnt.executeUpdate("INSERT INTO EventLog (message)"
                              + " VALUES ('" + msg + "')");

            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    /**
     * Prints the contents of teh event log table.
     */
    public void dump() {
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(mDbUrl, mUsername, mPassword);

            Statement stmnt = conn.createStatement();
            ResultSet rs = stmnt.executeQuery("SELECT id, message"
                                            + "  FROM EventLog");

            while (rs.next()) {
                System.out.print(rs.getInt("id") + "   ");
                System.out.println(rs.getString("message"));
            }

            System.out.println();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
