CREATE TABLE EventLog
( id INTEGER IDENTITY,
  message VARCHAR(255) );

