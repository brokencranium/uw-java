package edu.washington.example.sockets;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import java.net.Socket;


/**
 * Simple HTTP client allows reading a file from an HTTP Server.
 *
 * @author Russ Moul
 */
public final class HttpClient {
    /** The default HTTP port */
    public static final int DEFAULT_HTTP_PORT = 80;

    /** The HTTP server */
    private String mHost;

    /** The HTTP port */
    private int mPort;

    /** Index to host argument */
    private static final int HOST_ARG = 0;

    /** Index to port argument */
    private static final int PORT_ARG = 1;

    /** Index to file argument */
    private static final int FILE_ARG = 2;

    /**
     * Constructor.  Uses the default HTTP port.
     *
     * @param host the HTTP server host to connect to
     */
    public HttpClient(final String host) {
        mHost = host;
        mPort = DEFAULT_HTTP_PORT;
    }

    /**
     * Constructor.
     *
     * @param host the HTTP server host to connect to
     * @param port the port on the HTTP server to connect to
     */
    public HttpClient(final String host, final int port) {
        mHost = host;
        mPort = port;
    }

    /**
     * Opens connection to HTTP server and requests a file, and prints its
     * contents.
     *
     * @param fileName file to be retrieved from the server
     *
     * @throws IOException - if reads from the HTTP server fail
     */
    public void get(final String fileName) throws IOException {
        String tmpFileName = fileName;
        // establish connection
        Socket sock = new Socket(mHost, mPort);
        OutputStream outStrm = sock.getOutputStream();
        PrintWriter wrtr = new PrintWriter(outStrm, true); //Autoflush

        // protocol requires the filename to begin with '/'
        if (tmpFileName.charAt(0) != '/') {
            tmpFileName = "/" + tmpFileName;
        }

        wrtr.println("GET " + tmpFileName + " HTTP/1.0\n\n");

        InputStreamReader rdr = new InputStreamReader(sock.getInputStream());
        BufferedReader br = new BufferedReader(rdr);
        String line;

        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }

        wrtr.close();
        br.close();
        sock.close();
    }
}
