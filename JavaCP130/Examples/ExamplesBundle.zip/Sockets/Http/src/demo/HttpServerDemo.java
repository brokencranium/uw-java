package demo;

import edu.washington.example.sockets.HttpServer;

/**
 * Executes a simple HTTP server.
 *
 * @author Russ Moul
 */
public final class HttpServerDemo {
    /**
     * Prevent instantiation.
     */
    private HttpServerDemo() {
    }

    /**
     * Creates an HTTP server on the specified port and starts it.
     *
     * @param args args[0] my optionally contain the port number
     */
    public static void main(final String[] args) {
        int port = HttpServer.DEFAULT_HTTP_PORT;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        }

        HttpServer server = new HttpServer(port);
        server.serve();
    }
}
