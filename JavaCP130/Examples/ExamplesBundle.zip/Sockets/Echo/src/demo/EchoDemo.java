package demo;

import  edu.washington.example.sockets.EchoServer;

/**
 * Demonstrate/start the Echo server.
 * Telnet can be used to "talk" to the server.
 */
public final class EchoDemo {

    /**
     * Prevent instantiation.
     */
    private EchoDemo() {
    }

    /**
     * Creates an Echo server on the specified port and starts it.
     *
     * @param args command line arguments:
     *                  args[0] = port number
     */
    public static void main(final String[] args) {
        int port = 0;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        } else {
            System.out.println("usage: java EchoDemo port");
            System.exit(0);
        }

        EchoServer server = new EchoServer(port);
    }
}
