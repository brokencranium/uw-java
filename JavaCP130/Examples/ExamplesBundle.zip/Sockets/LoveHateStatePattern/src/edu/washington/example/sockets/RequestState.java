package edu.washington.example.sockets;

import java.io.PrintWriter;

/**
 * Interface for the request state implementation classes.  Each implementation
 * of this interface will encapsulate the desired behavior for a specific state
 * of the conversation.
 *
 * @author Russ Moul
 */
public interface RequestState {
    /**
     * The loveme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return a state object representing the state after this request
     */
    RequestState loveme(PrintWriter out);

    /**
     * The hateme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return a state object representing the state after this request
     */
    RequestState hateme(PrintWriter out);

    /**
     * The why request handler.
     *
     * @param out the writer to write the response to
     *
     * @return a state object representing the state after this request
     */
    RequestState why(PrintWriter out);

    /**
     * The quit request handler.
     *
     * @param out the writer to write the response to
     *
     * @return a state object representing the state after this request
     */
    RequestState quit(PrintWriter out);
}
