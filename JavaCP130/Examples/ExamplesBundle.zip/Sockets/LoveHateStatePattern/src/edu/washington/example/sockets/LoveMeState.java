package edu.washington.example.sockets;

import java.io.PrintWriter;

/**
 * Implementation of the RequestState interface for the "loveme" state.  This is
 * to state of the conversation after there has been a "loveme" request.
 *
 * @author Russ Moul
 */
public final class LoveMeState implements RequestState {
    /**
     * The loveme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return itself, this request does not change the state
     */
    public RequestState loveme(final PrintWriter out) {
        out.println("I told you, I love you.");

        return this;
    }

    /**
     * The hateme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return itself, this request does not change the state
     */
    public RequestState hateme(final PrintWriter out) {
        out.println("Hows that possible I already told you I love you.");

        return this;
    }

    /**
     * The why request handler.
     *
     * @param out the writer to write the response to
     *
     * @return the why state
     */
    public RequestState why(final PrintWriter out) {
        out.println("Because your wondeful.");

        return new WhyState();
    }

    /**
     * The quit request handler.
     *
     * @param out the writer to write the response to
     *
     * @return null, the conversation is over
     */
    public RequestState quit(final PrintWriter out) {
        out.println("Bye.");

        return null;
    }
}
