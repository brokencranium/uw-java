package edu.washington.example.sockets;

import java.io.PrintWriter;

/**
 * Implementation of the RequestState interface for the "hateme" state.  This is
 * to state of the conversation after there has been a "hateme" request.
 *
 * @author Russ Moul
 */
public final class HateMeState implements RequestState {
    /**
     * The loveme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return itself, this request does not change the state
     */
    public RequestState loveme(final PrintWriter out) {
        out.println("Lets not get carried away.");

        return this;
    }

    /**
     * The hateme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return itself, this request does not change the state
     */
    public RequestState hateme(final PrintWriter out) {
        out.println("I told you, I don't hate you.");

        return this;
    }

    /**
     * The why request handler.
     *
     * @param out the writer to write the response to
     *
     * @return the why state
     */
    public RequestState why(final PrintWriter out) {
        out.println("You've never given me any reason to.");

        return new WhyState();
    }

    /**
     * The quit request handler.
     *
     * @param out the writer to write the response to
     *
     * @return null, the conversation is over
     */
    public RequestState quit(final PrintWriter out) {
        out.println("Bye.");

        return null;
    }
}
