package demo;

import edu.washington.example.sockets.UdpEchoServer;

/**
 * Runs the UDP echo server.
 *
 * @author Russ Moul
 */
public final class UdpEchoServerDemo {
    /** Buffer size. */
    private static final int BUF_SIZE = 1024;
    /** The port. */
    private int mPort;

    /**
     * Prevent instantiation.
     *
     * @param port the port to connect to
     */
    private UdpEchoServerDemo() {
    }

    /**
     * Create the server and start it.
     *
     * @param args command line arguments:
     *                  args[0] = port number
     */
    public static void main(final String[] args) {
        int port = 0;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        } else {
            System.out.println("usage: java UdpEchoServer port");
            System.exit(0);
        }

        UdpEchoServer server = new UdpEchoServer(port);
        server.start();
    }
}
