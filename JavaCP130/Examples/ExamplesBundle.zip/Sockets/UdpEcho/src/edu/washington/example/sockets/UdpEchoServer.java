package edu.washington.example.sockets;

import java.io.IOException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * A simple Echo server, using UDP.  Replies to the client by echoing the
 * string sent to it.
 *
 * @author Russ Moul
 */
public final class UdpEchoServer {
    /** Buffer size. */
    private static final int BUF_SIZE = 1024;
    /** The port. */
    private int mPort;

    /**
     * Constructor.
     *
     * @param port the port to connect to
     */
    public UdpEchoServer(final int port) {
        mPort = port;
    }

    /**
     * Continually, attemps to read a message and echo it back to the sended.
     */
    public void start() {
        DatagramSocket udpSock = null;

        try {
            udpSock = new DatagramSocket(mPort);
            System.out.println("Server ready...");

            byte[] buf = new byte[BUF_SIZE];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);

            while (true) {
                udpSock.receive(packet);

                String msg = new String(packet.getData(), packet.getOffset(),
                                        packet.getLength());
                msg = msg.toUpperCase();
                packet.setData(msg.getBytes());
                packet.setLength(msg.length());
                udpSock.send(packet);

                // prepare to receive - buffer must be big enough
                packet.setData(buf);
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            if (udpSock != null) {
                udpSock.close();
            }
        }
    }
}
