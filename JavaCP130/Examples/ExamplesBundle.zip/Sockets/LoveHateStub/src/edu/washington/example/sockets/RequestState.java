package edu.washington.example.sockets;

/**
 * Encapsulates the request behaviors.  A method is provided for each request,
 * each method returns a message that is appropriate for the current state of
 * the conversation and sets the appropriate response to a forthcoming "why"
 * request.
 *
 * @author Russ Moul
 */
public final class RequestState implements RequestStateInf {
    /** Default response to why. */
    private String mWhy = "Don't know";

    /**
     * The loveme request handler.
     *
     * @return "I love you"
     */
    public String loveme() {
        mWhy = "Because you are wonderful!";

        return "I love you";
    }

    /**
     * The hateme request handler.
     *
     * @return "No I don't hate you"
     */
    public String hateme() {
        mWhy = "There is no reason to.";

        return "I don't hate you";
    }

    /**
     * The why request handler.
     *
     * @return a response appropriate for the current conversation state
     */
    public String why() {
        return mWhy;
    }

    /**
     * The quit request handler.
     *
     * @return "Bye."
     */
    public String quit() {
        return "Bye.";
    }
}
