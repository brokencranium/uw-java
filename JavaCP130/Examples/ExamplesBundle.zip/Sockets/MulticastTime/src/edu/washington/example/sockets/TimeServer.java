package edu.washington.example.sockets;

import java.io.IOException;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import java.util.Date;


/**
 * A simple multicast client server.  Joins a multicast group and sends the
 * date/time string every second.
 *
 * @author Russ Moul
 */
public final class TimeServer {
    /** Milliseconds per second. */
    private static final int ONE_SECOND = 1000;

    /** The server multicast address. */
    private String mIpAddress;

    /** The server multicast port. */
    private int mPort;


    /**
     * Constructor.
     *
     * @param ipAddress the multicast IP address to connect to
     * @param port the port to connect to
     */
    public TimeServer(final String ipAddress, final int port) {
        mIpAddress = ipAddress;
        mPort = port;
    }

    /**
     * Joins a multicast group and sends the date/time string every second.
     */
    public void start() {
        MulticastSocket multiSock = null;

        try {
            InetAddress group = InetAddress.getByName(mIpAddress);
            multiSock = new MulticastSocket(mPort);
            multiSock.joinGroup(group);
            System.out.println("Server ready...");

            while (true) {
                String ds = (new Date()).toString().trim();
                byte[] buf = ds.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length,
                        group, mPort);
                multiSock.send(packet);
                Thread.currentThread().sleep(ONE_SECOND);
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } catch (InterruptedException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            if (multiSock != null) {
                multiSock.close();
            }
        }
    }
}
