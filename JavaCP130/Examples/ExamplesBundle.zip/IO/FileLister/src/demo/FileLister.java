package demo;

import java.io.File;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

/**
 * A directory/file lister program, somewhat resembles the UNIX ls command.
 *
 * @author Russ Moul
 */
public final class FileLister {
    /** File size display width. */
    private static final int FILE_SIZE_DISPLAY_WIDTH = 12;
    /**
     * Prevent instantiation.
     */
    private FileLister() {
    }

    /**
     * Prints a file or directory listing.
     *
     * @param args arg[0] may optionally contian the name of the file or
     *                    directory to list
     */
    public static void main(final String[] args) {
        String dirName = null;

        if (args.length > 1) {
            System.out.println("usage: FileLister [file|dir]");
            System.exit(1);
        } else if (args.length == 0) {
            dirName = System.getProperty("user.dir");
            System.out.println(dirName);
        } else {
            dirName = args[0];
        }

        File dir = new File(dirName);

        if (!dir.exists()) {
            System.out.println(dirName + " does not exist");
            return;
        }

        String[] contents = {""};
        if (dir.isDirectory()) {
            contents = dir.list();
        }

        NumberFormat nf = NumberFormat.getIntegerInstance();
        nf.setGroupingUsed(false);

        Date today = new Date();
        Calendar cal = GregorianCalendar.getInstance();
        int thisYear = cal.get(Calendar.YEAR);
        SimpleDateFormat df = new SimpleDateFormat("MMM dd kk:mm");
        SimpleDateFormat dfYear = new SimpleDateFormat("MMM dd  yyyy");

        for (int i = 0; i < contents.length; i++) {
            // get the file attributes
            File file = new File(dir.getPath(), contents[i]);
            String dirIndicator = file.isDirectory() ? "d" : "-";
            String readIndicator = file.canRead() ? "r" : "-";
            String writeIndicator = file.canWrite() ? "w" : "-";
            long len = file.length();
            long modified = file.lastModified();

            // format the length
            String lenStr = nf.format(len);
            int padLen = FILE_SIZE_DISPLAY_WIDTH - lenStr.length();
            char[] pad = new char[padLen];
            Arrays.fill(pad, ' ');
            lenStr = new String(pad) + lenStr;

            // format the modified date
            Date dt = new Date(modified);
            cal.setTime(dt);
            String modifiedStr = null;
            if (thisYear == cal.get(Calendar.YEAR)) {
                modifiedStr = df.format(dt);
            } else {
                modifiedStr = dfYear.format(dt);
            }

            System.out.println(dirIndicator
                             + readIndicator
                             + writeIndicator
                             + lenStr
                             + " " + modifiedStr
                             + " " + file.getName());
        }
    }
}



