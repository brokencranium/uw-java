package demo;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.Reader;
import java.io.Writer;

/**
 * A simple example using pipes.
 *
 * @author Russ Moul
 */
public final class PipeDemo {
    /** The input pipe. */
    private PipedReader mIn;

    /** The output pipe. */
    private PipedWriter mOut;

    /**
     * Constructor.  Initializes reading and writing pipes.
     *
     * @throws IOException if unable to create either pipe
     */
    public PipeDemo() throws IOException {
        mIn = new PipedReader();
        mOut = new PipedWriter(mIn);
    }

    /**
     * Obtains the reading end of the pipe.
     *
     * @return the pipe Reader
     */
    public Reader getReader() {
        return mIn;
    }

    /**
     * Obtains the writing end of the pipe.
     *
     * @return the pipe writer
     */
    public Writer getWriter() {
        return mOut;
    }

    /**
     * Writes argument strings the a pipe.  A separate thread reads from the
     * pipe and prints whatever it reads.
     *
     * @param args the String array containing strings to be printed
     */
    public static void main(final String[] args) {
        PipeDemo p = null;
        try {
            p = new PipeDemo();
        } catch (IOException ex) {
            System.err.println("Error creating pipes");
            ex.printStackTrace();
            System.exit(1);
        }
        Writer wtr = p.getWriter();
        Reader rdr = p.getReader();
        Thread t = new PrintThread(rdr);

        for (int i = 0; i < args.length; i++) {
            try {
                wtr.write(args[i] + "\n");
            } catch (IOException ex) {
               System.err.println("Error writing to pipe");
               ex.printStackTrace();
               System.exit(1);
            }
        }

        try {
            wtr.close();
        } catch (IOException ex) {
            System.err.println("Error closing stream");
            ex.printStackTrace();
            System.exit(1);
        }

        try {
            t.join();
        } catch (InterruptedException iex) {
            System.err.println("Error joining print thread");
            iex.printStackTrace();
            System.exit(1);
        }

        System.out.println();
        System.out.println("Done!");
    }
}


/**
 * Continuousy reads characters from a Reader and prints them.
 */
final class PrintThread extends Thread {
    /** The reader to read characters from for printing. */
    private Reader mRdr;

    /**
     * Constructor.
     *
     * @param rdr Reader to read input from
     */
    public PrintThread(final Reader rdr) {
        mRdr = rdr;
        start();
    }

    /**
     * Continuousy read characters and print them.
     */
    public void run() {
        int ch;

        try {
            while ((ch = mRdr.read()) != -1) {
                System.out.print((char) ch);
            }
        } catch (IOException ex) {
            System.err.println("Error reading from pipe");
            ex.printStackTrace();
            System.exit(1);
        }
    }
}
