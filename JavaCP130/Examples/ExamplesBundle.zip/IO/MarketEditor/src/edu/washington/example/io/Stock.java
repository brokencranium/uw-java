package edu.washington.example.io;

/**
 * Represents a stock, consisting of a ticker symbol and price expressed in
 * cents.
 *
 * @author Russ Moul
 */
public final class Stock {
    /** The maximum length of the ticker symbol. */
    private static final int MAX_TICKER_LENGTH = 4;

    /** The ticker symbol. */
    private String mTicker = " ";

    /** The stock price. */
    private int mPrice = 0;

    /**
     * Default constructor.
     */
    public Stock() {
    }

    /**
     * Default constructor.
     *
     * @param ticker the ticker's symbol
     * @param price the stock's price
     */
    public Stock(final String ticker, final int price) {
        setTicker(ticker);
        setPrice(price);
    }

    /**
     * Set the ticker symbol.
     *
     * @param ticker the ticker symbol
     */
    public void setTicker(final String ticker) {
        String tmpTicker = ticker.trim();

        if ((tmpTicker == null) || (tmpTicker.length() == 0)
                             || (tmpTicker.length() > MAX_TICKER_LENGTH)) {
            throw new IllegalArgumentException(
                "Ticker must be 1 to 4 chararacters in length.");
        }

        mTicker = tmpTicker;
    }

    /**
     * Get the ticker symbol.
     *
     * @return the ticker symbol
     */
    public String getTicker() {
        return mTicker;
    }

    /**
     * Set the stock price.
     *
     * @param price the stock price
     */
    public void setPrice(final int price) {
        if (price < 0) {
            throw new IllegalArgumentException(
                "Price must be a positive value.");
        }

        mPrice = price;
    }

    /**
     * Set the stock price.
     *
     * @return the ticker symbol
     */
    public int getPrice() {
        return mPrice;
    }

    /**
     * String representation of a stock, <i>ticker</i>:<i>price</i>
     *
     * @return the string representation
     */
    public String toString() {
        return mTicker + ":" + mPrice;
    }
}
