package edu.washington.example.io;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

/**
 * Table model for a Vector of Stock objects.
 *
 * @author Russ Moul
 */
public final class MarketTableModel extends AbstractTableModel {
    /** The initial size for the vector containing the data */
    private static final int DEFAULT_VECTOR_SIZE = 10;

    /** The data vector increment size. */
    private static final int DEFAULT_VECTOR_INCREMENT = 10;

    /** The column names. */
    private String[] mColNames = {"Ticker", "Price (cents)"};

    /** The data. */
    private Vector mRowData = new Vector(DEFAULT_VECTOR_SIZE,
                                         DEFAULT_VECTOR_INCREMENT);

    /** Map of the ticker symbols to the stocks - used to prevent duplicates. */
    private Hashtable mMap = new Hashtable();

    /** Constructor. */
    public MarketTableModel() {
    }

    /**
     * Returns the name of the column at columnIndex.
     *
     * @param col the index of the column
     *
     * @return the name of the column
     */
    public String getColumnName(final int col) {
        return mColNames[col];
    }

    /**
     * Returns an enumeration of the stocks in the model.
     *
     * @return an enumeration of Stock objects
     */
    public Enumeration getData() {
        return mRowData.elements();
    }

    /**
     * Deletes all data from the model.
     */
    public void clear() {
        mRowData.clear();
        mMap.clear();
        fireTableDataChanged();
    }

    /**
     * Sets the models data.  If the data contains duplicates the model data
     * will not be updated.
     *
     * @param data a vector containing Stock objects to be used as the models
     *             data
     *
     * @throws IllegalArgumentException if the data coontains stocks with
     *                                  duplicate tickers
     */
    public void setData(final Vector data) throws IllegalArgumentException {
        // check for duplicates...
        Hashtable newMap = new Hashtable();
        int len = data.size();
        for (int i = 0; i < len; i++) {
            Stock stock = (Stock)data.elementAt(i);
            String ticker = stock.getTicker();
            if (mMap.get(ticker) == null) {
               newMap.put(ticker, stock);
            } else {
                throw new IllegalArgumentException(
                          "Data contains duplicate ticker '" + ticker + "'.");
            }
        }

        // set the data
        mRowData = data;
        mMap = newMap;

        fireTableDataChanged();
    }

    /**
     * Returns the number of rows in the model.
     *
     * @return the number of rows in the model
     */
    public int getRowCount() {
        return mRowData.size();
    }

    /**
     * Returns the number of columns in the model.
     *
     * @return the number of columns in the model, this will always be 2
     */
    public int getColumnCount() {
        return mColNames.length;
    }

    /**
     * Returns the value for the cell at columnIndex and rowIndex.
     *
     * @param row the row whose value is to be queried
     * @param col the column whose value is to be queried
     *
     * @return the value Object at the specified cell, a String if the column
     *         is 0, an Integer if the column is 1
     */
    public Object getValueAt(final int row, final int col) {
        Object value = null;
        Stock stock = (Stock) mRowData.elementAt(row);

        switch (col) {
            case 0:
                value = stock.getTicker();
                break;

            case 1:
                value = new Integer(stock.getPrice());
                break;

            default:
                throw new IllegalArgumentException(
                                           "Invalid column specified, " + col);
        }

        return value;
    }

    /**
     * Returns true if the cell at rowIndex and columnIndex is editable.
     * Otherwise, setValueAt on the cell will not change the value of that cell.
     *
     * @param row the row whose value to be queried
     * @param col the column whose value to be queried
     *
     * @return true for column 1, false for all others
     */
    public boolean isCellEditable(final int row, final int col) {
        return col == 1;
    }

    /**
     * Sets the value in the cell at col and row to value.
     *
     * @param value the new value
     * @param row the row whose value is to be changed
     * @param col the column whose value is to be changed
     *
     * @throws IllegalArgumentException if the value object is invalid, or the
     *                                  column is not 0 or 1
     */
    public void setValueAt(final Object value, final int row, final int col)
    throws IllegalArgumentException {
        Stock stock = (Stock) mRowData.elementAt(row);

        switch (col) {
            case 0:
                String key = stock.getTicker();
                String ticker = value.toString();

                if (mMap.get(ticker) == null) {
                    stock.setTicker(value.toString());
                    mMap.remove(key);
                    mMap.put(ticker, stock);
                } else {
                    throw new IllegalArgumentException(
                        "Ticker '" + ticker + "' already exists");
                }
                break;

            case 1:
                stock.setPrice(((Integer)value).intValue());
                break;

            default:
                throw new IllegalArgumentException(
                                           "Invalid column specified, " + col);
        }

        fireTableCellUpdated(row, col);
    }

    /**
     * Adds a stock to the model.
     *
     * @param stock the stock to add
     *
     * @throws IllegalArgumentException if the data coontains stocks with
     *                                  duplicate tickers
     */
    public void addRow(final Stock stock) throws IllegalArgumentException {
        String ticker = stock.getTicker();
        if (mMap.get(ticker) == null) {
            mRowData.addElement(stock);
            mMap.put(ticker, stock);

            int row = mRowData.size() - 1;
            fireTableRowsInserted(row, row);
        } else {
            throw new IllegalArgumentException("Duplicate ticker symbol.");
        }
    }

    /**
     * Deletes the specified row from the models data.
     *
     * @param row the row to be deleted
     */
    public void deleteRow(final int row) {
        mRowData.removeElementAt(row);
        fireTableRowsDeleted(row, row);
    }
}
