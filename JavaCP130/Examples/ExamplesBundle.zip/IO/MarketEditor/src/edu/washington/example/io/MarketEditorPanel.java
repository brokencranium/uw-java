package edu.washington.example.io;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JLayeredPane;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;


/**
 * A panel containing all the components for editing a set of stock records.
 *
 * @Author Russ Moul
 */
public final class MarketEditorPanel extends JPanel {
    /** Preferered width of the scroll pane. */
    private static final int INITIAL_WIDTH = 200;

    /** Preferered height of the scroll pane. */
    private static final int INITIAL_HEIGHT = 100;

    /** The price column index. */
    private static final int PRICE_COLUMN_INDEX = 1;

    /** The tabel containing the stock data. */
    private JTable mTable;

    /** The panels pop-up menu. */
    private JPopupMenu mPopMnu;

    /** The pop-up menu's add item. */
    private JMenuItem mPopAddMI;

    /** The pop-up menu's delete item. */
    private JMenuItem mPopDeleteMI;

    /** The panels scroll pane. */
    private JScrollPane mScrollPane;

    /** The Y coordinate of the last popup invocation. */
    private int mLastPopupY;

    /** Indicates the data has change. */
    private boolean mChanged;

    /**
     * Constructor.
     */
    public MarketEditorPanel() {
        super(new GridBagLayout());
        TableModel model = new MarketTableModel();
        mTable = new JTable(model);
        mTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        mTable.getColumnModel().getColumn(PRICE_COLUMN_INDEX)
                               .setCellEditor(new UnsignedEditor());
        mChanged = false;

        model.addTableModelListener(new TableModelListener() {
                public void tableChanged(final TableModelEvent e) {
                    mChanged = true;
                }
            });

        mScrollPane = new JScrollPane(mTable);
        mScrollPane.setPreferredSize(new Dimension(INITIAL_WIDTH,
                                                   INITIAL_HEIGHT));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        add(mScrollPane, gbc);

        mPopMnu = new JPopupMenu("Add-Remove Rows");
        mPopAddMI = new JMenuItem("Add Row");
        mPopMnu.add(mPopAddMI);
        mPopAddMI.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent e) {
                    String ticker;
                    ticker = JOptionPane.showInputDialog(MarketEditorPanel.this,
                            "Enter stock ticker: ");

                    if (ticker != null) {
                        try {
                            Stock newStock = new Stock(ticker, 0);
                            MarketTableModel model;
                            model = (MarketTableModel)mTable.getModel();
                            model.addRow(newStock);
                        } catch (IllegalArgumentException ex) {
                           JOptionPane.showMessageDialog(MarketEditorPanel.this,
                                                   ex.getMessage(), "Warning",
                                                   JOptionPane.WARNING_MESSAGE);
                        }
                    }
                }
            });

        mPopDeleteMI = new JMenuItem("Delete Row");
        mPopMnu.add(mPopDeleteMI);
        mPopDeleteMI.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent e) {
                    int row = mLastPopupY / mTable.getRowHeight();
                    ((MarketTableModel)mTable.getModel()).deleteRow(row);
                }
            });

        // Add the popup menu and listener to the layeredPane
        //popupPane = getLayeredPane();
        mScrollPane.add(mPopMnu, JLayeredPane.POPUP_LAYER);

        MouseListener ml = new PopupMouseListener();
        mScrollPane.addMouseListener(ml);
        mTable.addMouseListener(ml);
    }

    /**
     * Sets the table data.
     *
     * @param stocks a Vector containing the stocks to be edited.
     */
    public void setMarket(final Vector stocks) {
        try {
            ((MarketTableModel)mTable.getModel()).setData(stocks);
            mChanged = false;
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(MarketEditorPanel.this,
                                          ex.getMessage(), "Warning",
                                          JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * An enumeration of the stocks being edited.
     *
     * @return an Enumeration containing Stock objects
     */
    public Enumeration getMarket() {
        return ((MarketTableModel)mTable.getModel()).getData();
    }

    /**
     * Determines if the data has changed.
     *
     * @return true if the data has changed
     */
    public boolean isChanged() {
        return mChanged;
    }

    /**
     * Sets the "changed" status of the data.
     *
     * @param changed the "changed" status, true if the data has changed
     */
    public void setChanged(final boolean changed) {
        mChanged = changed;
    }

    /**
     * Process pop-up events.
     */
    final class PopupMouseListener extends MouseAdapter {
        /**
         * Recognizes the UNIX pop-up event and presents the menu.
         *
         * @param e the (potential)pop-up mouse event
         */
        public void mousePressed(final MouseEvent e) {
            mPopDeleteMI.setEnabled(e.getSource() == mTable);

            if (e.isPopupTrigger()) {
                mLastPopupY = e.getY();
                mPopMnu.show(mScrollPane, e.getX(), e.getY());
            }
        }

        /**
         * Recognizes the Windows pop-up event and presents the menu.
         *
         * @param e the (potential)pop-up mouse event
         */
        public void mouseReleased(final MouseEvent e) {
            mPopDeleteMI.setEnabled(e.getSource() == mTable);

            if (e.isPopupTrigger()) {
                mLastPopupY = e.getY();
                mPopMnu.show(mScrollPane, e.getX(), e.getY());
            }
        }
    }
}
