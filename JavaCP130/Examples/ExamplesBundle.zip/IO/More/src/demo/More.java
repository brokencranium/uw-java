package demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * A simple program for displaying a text file in pieces.
 *
 * This program takes two arguments; the name of a text file and optionally the
 * number of lines to display. If the second argument is not provided the
 * default is 23.
 */
public final class More {
   /** Default lines per screen. */
   private static final int DEFAULT_LINES_PER_SCREEN = 23;

   /**
    * Prevent instantiation.
    */
   private More() {
   }

   /**
    * Entry point.
    *
    * @param args args[0] the name of the file to display,
    *             args[1] the number of lines to display on a screen (optional)
    */
   public static void main(final String[] args) {
      String fileName = null;
      int linesPerScreen = DEFAULT_LINES_PER_SCREEN;

      if (args.length == 0) {
         System.out.println("Usage: filename [linesperscreen]");
         return;
      }

      if (args.length >= 1) {
         fileName = args[0];
      }

      if (args.length >= 2) {
         try {
            linesPerScreen = Integer.parseInt(args[1]);
         } catch (NumberFormatException ex) {
            ex.printStackTrace();
         }
      }

      try {
         //Create a FileReader and then hook up a LineNumberReader
         FileReader file = new FileReader(fileName);
         LineNumberReader reader = new LineNumberReader(file);

         //Create the InputStreamReader to interface
         //the Reader with the Stream
         Reader converter = new InputStreamReader(System.in);
         BufferedReader stdin = new BufferedReader(converter);

         String line;
         while ((line = reader.readLine()) != null) {
            // A null means end of file for readLine()
            System.out.println(line);

            if (reader.getLineNumber() % linesPerScreen == 0) {
               System.out.println("--More--");
               System.out.flush();
               stdin.readLine();  // Wait for user to push key
               reader.setLineNumber(0); // Reset lines read to 0
            }
         }
      } catch (IOException e) {
         System.out.println(e);
      }
   }
}
