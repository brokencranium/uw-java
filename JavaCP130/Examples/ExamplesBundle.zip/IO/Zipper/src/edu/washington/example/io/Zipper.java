package edu.washington.example.io;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Demonstrate the use of the ZIP file processing classes.
 */
public final class Zipper {
    /** Working buffer size. */
    private static final int BUF_SIZE = 4096;

    /** Index to the action argument */
    private static final int ACTION_ARG = 0;

    /** Index to the file name argument */
    private static final int ZIP_FILE_NAME_ARG = 1;

    /** Index to the extract target directory */
    private static final int TARGET_DIR_ARG = 2;

    /** Index to the first file argument */
    private static final int FILE_LIST_ARG = 2;

    /** Extract action flag */
    private static final String EXTRACT_ACTION = "-x";

    /** Create action flag */
    private static final String CREATE_ACTION = "-c";

    /**
     * Prevent instantiation.
     */
    private Zipper() {
    }

    /**
     * Extracts a zip file to the current directory.
     *
     * @param zipFile name of zip file to be expanded
     */
    public static void unzip(final String zipFile) {
        unzip(zipFile, null);
    }

    /**
     * Extracts a zip file to a specific directory.
     *
     * @param zipFile name of zip file to be expanded
     * @param targetDir name of the directory the files are to be placed in
     */
    public static void unzip(final String zipFile, final String targetDir) {
        try {
            boolean hasTargetDir = ((targetDir != null)
                                 && (targetDir.length() > 0));

            if (hasTargetDir) {
                File dir = new File(targetDir);

                if (!dir.exists()) {
                    dir.mkdirs();
                }
            }

            // open the zip file
            FileInputStream fs = new FileInputStream(zipFile);
            ZipInputStream zin = new ZipInputStream(fs);

            // begin extracting entries
            ZipEntry entry;
            byte[] buf = new byte[BUF_SIZE];

            while ((entry = zin.getNextEntry()) != null) {
                // create the output file and perform the extraction
                String name;

                if (hasTargetDir) {
                    name = targetDir + "/" + entry.getName();
                } else {
                    name = entry.getName();
                }

                File f = new File(name);

                /*
                if (entry.isDirectory()) {
                    if (!f.exists()) {
                        f.mkdirs();
                    }
                } else {
                */
                if (!entry.isDirectory()) {
                    File dir = f.getParentFile();

                    if ((dir != null) && !dir.exists()) {
                        dir.mkdirs();
                    }

                    FileOutputStream fos = new FileOutputStream(name);

                    int len;

                    while ((len = zin.read(buf, 0, BUF_SIZE)) != -1) {
                        fos.write(buf, 0, len);
                    }
                }

                zin.closeEntry();
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Adds a files and/or directories to the zip file.
     *
     * @param zipFileName name of the zip file to be created
     * @param files name of files to add to zip file
     */
    public static void zip(final String zipFileName, final String[] files) {
        try {
            FileOutputStream fos = new FileOutputStream(zipFileName);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            ZipOutputStream zos = (new ZipOutputStream(bos));

            for (int i = 0; i < files.length; i++) {
                addEntry(zos, files[i]);
            }

            zos.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Adds a file or directory to the zip stream. Recursive processing of
     * directories simplifies maintaining proper path names.
     *
     * @param zipOut zip stream the entry is added to
     * @param file name of file to add to zip stream
     */
    private static void addEntry(final ZipOutputStream zipOut,
                                 final String file) {
        try {
            File f = new File(file);

            if (f.isDirectory()) {
                // write the directory
                /*
                ZipEntry e = new ZipEntry(file + "/");
                zipOut.putNextEntry(e);
                zipOut.closeEntry();
                */

                // process files in directory
                String[] files = f.list();

                for (int i = 0; i < files.length; i++) {
                    addEntry(zipOut, file + "/" + files[i]);
                }
            } else {
                byte[] buf = new byte[BUF_SIZE];
                int bytes = 0;
                FileInputStream in = new FileInputStream(f);
                ZipEntry e = new ZipEntry(file);
                zipOut.putNextEntry(e);

                while ((bytes = in.read(buf)) != -1) {
                    zipOut.write(buf, 0, bytes);
                }

                zipOut.closeEntry();
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Simple front end processor for zipping and unzipping.
     *
     * @param args [-x zip_file [target_dir]] | [-c zip_file files...]
     */
    public static void main(final String[] args) {
        boolean done = false;

        if (args.length > 0) {
            String action =  args[ACTION_ARG];

            if (EXTRACT_ACTION.equals(action)) {
                if (args.length == ZIP_FILE_NAME_ARG + 1) {
                    Zipper.unzip(args[ZIP_FILE_NAME_ARG]);
                    done = true;
                } else if (args.length == TARGET_DIR_ARG + 1) {
                    Zipper.unzip(args[ZIP_FILE_NAME_ARG], args[TARGET_DIR_ARG]);
                    done = true;
                }

            } else if (CREATE_ACTION.equals(action)) {
                if (args.length >= FILE_LIST_ARG + 1) {
                    // Copy the list of files
                    String[] files = new String[args.length - FILE_LIST_ARG];
                    for (int i = FILE_LIST_ARG; i < args.length; i++) {
                        files[i - FILE_LIST_ARG] = args[i];
                    }

                    Zipper.zip(args[ZIP_FILE_NAME_ARG], files);
                    done = true;
                }
            }
        }

        if (!done) {  // bad arguments
            System.out.println("Invalid argument list, needs to be:");
            System.out.println(
                "    [-x zip_file [target_dir]] | [-c zip_file files...]");
        }
    }
}
