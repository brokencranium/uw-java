package demo;

/*
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.InputStream;
*/

import edu.washington.example.io.ConsoleIn;

/**
 * Demonstrates the use of the CondsoleIn class.
 *
 * @author Russ Moul
 */
public final class ConsoleInDemo {
    /**
     * Prevent instantiation.
     */
    private ConsoleInDemo() {
    }

    /**
     * Tests each of the read methods.
     *
     * @param args      the String array containing command line arguments,
     *                  not used.
     */
    public static void main(final String[] args) {
        /* Uncomment for automated test
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter w = new PrintWriter(baos, true);

        w.println("A");
        w.println("Hello");
        w.println("true");
        w.println("16");
        w.println("1024");
        w.println("102400");
        w.println("1024000");
        w.println("3.14");
        w.println("3.14");
        w.flush();

        byte[] buf = baos.toByteArray();

        InputStream dir = (InputStream)new ByteArrayInputStream( buf );
        System.setIn(dir);
        */

        System.out.print("enter char: ");
        System.out.flush();
        System.out.println("You entered: '" + ConsoleIn.readChar() + "'");

        System.out.print("enter String: ");
        System.out.flush();
        System.out.println("You entered: \"" + ConsoleIn.readString() + "\"");

        System.out.print("enter boolean: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readBoolean());

        System.out.print("enter byte: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readByte());

        System.out.print("enter short: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readShort());

        System.out.print("enter int: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readInt());

        System.out.print("enter long: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readLong());

        System.out.print("enter float: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readFloat());

        System.out.print("enter double: ");
        System.out.flush();
        System.out.println("You entered: " + ConsoleIn.readDouble());
    }
}
