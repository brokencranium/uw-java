package edu.washington.example.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * A class that roughly immulates DataInputStream for text sources. The newline
 * sequence is interpreted as a delimiter in all methods except readFully.
 *
 * @author Russ Moul
 */
public final class DataInputReader {
    /** Reader used to read in characters. */
    private BufferedReader mBufReader;

    /**
     * Constructor.
     *
     * @param src the Reader which is the source of characters
     */
    public DataInputReader(final Reader src) {
        if (src instanceof BufferedReader) {
            mBufReader = (BufferedReader) src;
        } else {
            mBufReader = new BufferedReader(src);
        }
    }

    /**
     * Constructor.
     *
     * @param inStream the InputStream which is the source of characters
     */
    public DataInputReader(final InputStream inStream) {
        mBufReader = new BufferedReader(new InputStreamReader(inStream));
    }

    /**
     * Reads a line of text.
     *
     * @return  the string read.
     *
     * @throws IOException if an io error occurs
     */
    private String getString() throws IOException {
        String s = null;

        try {
            s = mBufReader.readLine();
        } catch (Exception ex) {
            s = "";
        }

        return s;
    }

    /**
     * Reads a boolean value from the source.  The case insensitive string
     * "true" is interpreted as true all other values are false.
     *
     * @return the boolean value represented by the input string
     *
     * @throws IOException if an io error occurs
     */
    public boolean readBoolean() throws IOException {
        boolean value = false;
        value = Boolean.valueOf(getString()).booleanValue();

        return value;
    }

    /**
     * Reads a byte value from the source.
     *
     * @return the byte value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse a byte value from the
     *                               string read
     */
    public byte readByte() throws IOException, NumberFormatException {
        byte value = 0;
        value = Byte.parseByte(getString());

        return value;
    }

    /**
     * Reads a short value from the source.
     *
     * @return the short value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse a short value from the
     *                               string read
     */
    public short readShort() throws IOException, NumberFormatException {
        short value = 0;
        value = Short.parseShort(getString());

        return value;
    }

    /**
     * Reads an int value from the source.
     *
     * @return the int value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse an int value from the
     *                               string read
     */
    public int readInt() throws IOException, NumberFormatException {
        int value = 0;
        value = Integer.parseInt(getString());

        return value;
    }

    /**
     * Reads a long value from the source.
     *
     * @return the long value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse a long value from the
     *                               string read
     */
    public long readLong() throws IOException, NumberFormatException {
        long value = 0;
        value = Long.parseLong(getString());

        return value;
    }

    /**
     * Reads a float value from the source.
     *
     * @return the float value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse a byte float from the
     *                               string read
     */
    public float readFloat() throws IOException, NumberFormatException {
        float value = 0.0F;
        value = Float.parseFloat(getString());

        return value;
    }

    /**
     * Reads a double value from the source.
     *
     * @return the double value represented by the input string
     *
     * @throws IOException if an io error occurs
     * @throws NumberFormatException if unable to parse a double value from the
     *                               string read
     */
    public double readDouble() throws IOException, NumberFormatException {
        double value = 0.0;
        value = Double.parseDouble(getString());

        return value;
    }

    /**
     * Reads a char value from the source. A extra characters before a newline
     * sequence are discarded.
     *
     * @return the first char of the input string
     *
     * @throws IOException if an io error occurs
     */
    public char readChar() throws IOException {
        char value = 0;
        String s = getString();

        if (s.length() > 0) {
            value = s.charAt(0);
        }

        return value;
    }

    /**
     * Reads characters from the source and stores them into the buffer array.
     *
     * @param b buffer to fill with characters
     *
     * @throws IOException if an io error occurs
     */
    public void readFully(final char[] b) throws IOException {
        mBufReader.read(b);
    }

    /**
     * Reads len characters from the source.
     *
     * @param b buffer to hold the characters
     * @param off offset at which to start storing characters
     * @param len number of characters to read
     *
     * @throws IOException if an io error occurs
     */
    public void readFully(final char[] b, final int off, final int len)
    throws IOException {
        mBufReader.read(b, off, len);
    }

    /**
     * Reads the next line of text the source.
     *
     * @return the the input string
     *
     * @throws IOException if an io error occurs
     */
    public String readLine() throws IOException {
        String value = "";
        value = mBufReader.readLine();

        return value;
    }
}
