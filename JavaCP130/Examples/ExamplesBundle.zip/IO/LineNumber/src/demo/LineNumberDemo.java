package demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Arrays;

/**
 * Lists a file, uses LineNumberReader to prepend each line with its line
 * number.
 */
public final class LineNumberDemo {
    /** Left padding length. */
    private static final int PAD_LEN = 5;
    /**
     * Prevent instantiation.
     */
    private LineNumberDemo() {
    }

    /**
     * The main entry point for the application.
     *
     * @param args args[0] the name of the file to list
     */
    public static void main(final String[] args) {
        NumberFormat nf = NumberFormat.getIntegerInstance();
        nf.setGroupingUsed(false);
        try {
            LineNumberReader in =
                    new LineNumberReader(
                            new BufferedReader(
                                    new FileReader(args[0])));
            String line;
            while ((line = in.readLine()) != null) {
                int lineNo = in.getLineNumber();
                // format the length
                String lineNoStr = nf.format(lineNo);
                int padLen = PAD_LEN - lineNoStr.length();
                char[] pad = new char[padLen];
                Arrays.fill(pad, ' ');
                lineNoStr = new String(pad) + lineNoStr;
                System.out.println(lineNoStr + ": " + line);

            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
