package demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import edu.washington.example.io.RevReader;
import edu.washington.example.io.RevWriter;

/**
 * Test the RevReader and RevWriter classes.
 */
public final class RevFilterDemo {
    /**
     * Prevent instantiation.
     */
    private RevFilterDemo() {
    }

    /**
     * Write and the subssequently reads characters to/from a file using the
     * RevWriter and RevReader classes.
     *
     * @param args args[0] optionally contains the name of the file to
     *             write/read to/from, if not specified "RevFilterTest.txt" will
     *             be used.
     */
    public static void main(final String[] args) {
        String testStr = new String("This is a test");
        String filename;

        // If no arg then use defaults
        if (args.length == 0) {
            filename = "RevFilterTest.txt";
        } else {
            filename = args[0];
        }

        try {
            // Write out the string to a file
            RevWriter out = new RevWriter(new FileOutputStream(filename));
            for (int i = 0; i < testStr.length(); i++) {
                out.write((char) testStr.charAt(i));
            }
            out.close();

            // Read the string from a file
            RevReader in = new RevReader(new FileInputStream(filename));
            StringBuffer sb = new StringBuffer();
            for (int c = in.read(); c > -1; c = in.read())  {
                sb.append((char) c);
            }

            // print out the results/feedback
            System.out.println();
            String decoded = sb.toString();
            System.out.println("DeCode: " + decoded);
            if (testStr.equals(decoded)) {
                System.out.println("Success.");
            } else {
                System.out.println("Failure.");
            }
            in.close();
        } catch (IOException e) {
            System.err.println("\n" + e.toString());
      }
   }
}

