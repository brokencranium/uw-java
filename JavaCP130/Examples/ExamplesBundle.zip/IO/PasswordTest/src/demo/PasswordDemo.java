package demo;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Test a password for encoding and validation.
 */
public final class PasswordDemo {
    /**
     * Prevent instantiation.
     */
    private PasswordDemo() {
    }

    /**
     * Run the test.
     *
     * @param args args[0] the password,
     *             args[1] optionally contains encoding to use
     *
     * @throws UnsupportedEncodingException if the specified encoding is not
     *                                      supported
     * @throws NoSuchAlgorithmException if the 'SHA-1' hashing algorithm is not
     *                                  supported
     */
    public static void main(final String[] args)
        throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String enc = null;
        String password = null;

        if (args.length == 1) {
            password = args[0];
            enc = (new InputStreamReader(System.in)).getEncoding();
        } else if (args.length == 2) {
            password = args[0];
            enc = args[1];
        } else { // get the default encoding
            System.out.println("usage: java PasswordDemo password [encoding]");
            System.exit(0);
        }

        System.out.println("Encoding: " + enc);

        byte[] b = password.getBytes(enc);
        MessageDigest alg = MessageDigest.getInstance("SHA-1");
        alg.update(b);

        byte[] hash = alg.digest();

        String hashString = new String(hash, enc);
        byte[] verifyHash = hashString.getBytes(enc);

        if (MessageDigest.isEqual(hash, verifyHash)) {
            System.out.println(
               "Password '" + password + "' successfully hashed and verified!");
        } else {
            System.out.println(
                "Password '" + password + "' failed verification!");
        }
    }
}
