package demo;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 * Test a character encoding for conversion of all possible byte values to
 * characters and back.
 *
 * @author Russ Moul
 */
public final class VerifyEncoding {
    /**
     * Prevent instantiation.
     */
    private VerifyEncoding() {
    }

    /**
     * Run the test.
     *
     * @param args args[0] optionally contains encoding to use.
     *
     * @throws UnsupportedEncodingException if the specified encoding is not
     *                                      supported
     */
    public static void main(final String[] args)
        throws UnsupportedEncodingException {
        boolean hasFailure = false;
        String enc;

        if (args.length == 1) {
            enc = args[0];
        } else { // get the default encoding
            enc = (new InputStreamReader(System.in)).getEncoding();
        }

        System.out.println("Encoding: " + enc);

        for (byte b = Byte.MIN_VALUE; b < Byte.MAX_VALUE; b++) {
            byte[] bArr = {b};
            String tmp = new String(bArr, enc);
            byte[] rArr = tmp.getBytes(enc);

            if (rArr.length > 0) {
                if (bArr[0] != rArr[0]) {
                    hasFailure = true;
                    System.out.println("Failed conversion: " + bArr[0]
                                     + " -> '" + tmp + "' -> " + rArr[0]);
                }
            } else {
                hasFailure = true;
                System.out.println("No character -> byte conversion for '"
                                 + bArr[0] + "'");
            }
        }

        if (!hasFailure) {
            System.out.println("No conversion problems.");
        }
    }
}
