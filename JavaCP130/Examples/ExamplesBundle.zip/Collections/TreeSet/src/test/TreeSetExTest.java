package test;

import java.util.Iterator;
import java.util.TreeSet;

import edu.washington.example.collections.Employee;
import edu.washington.example.collections.EmployeeComparator;

import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test case for the externalizble cube class ExCube.
 *
 * @author Russ Moul
 */
public final class TreeSetExTest extends TestCase {
    /** The employeess. */
    private Employee[] mEmployees;

    /** The name ordering of the objects */
    private int[] mNameOrdering;

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public TreeSetExTest(final String testName) {
        super(testName);
    }

    /**
     * Create the employee objects.
     */
    protected void setUp() {
        mEmployees = new Employee[10];
        int i = 0;
        mEmployees[i++] = new Employee("Doe", "John", 1009);
        mEmployees[i++] = new Employee("Doe", "Jane", 1010);
        mEmployees[i++] = new Employee("Flintstone", "Wilma", 1001);
        mEmployees[i++] = new Employee("Flintstone", "Fred", 1002);
        mEmployees[i++] = new Employee("Flintstone", "Pebbles", 1003);
        mEmployees[i++] = new Employee("Rubble", "Barney", 1004);
        mEmployees[i++] = new Employee("Rubble", "Betty", 1005);
        mEmployees[i++] = new Employee("Rubble", "Bam Bam", 1006);
        mEmployees[i++] = new Employee("Doe", "John", 1007);
        mEmployees[i++] = new Employee("Doe", "Jane", 1008);

        mNameOrdering = new int[10];
        i = 0;
        mNameOrdering[i++] = 1008;
        mNameOrdering[i++] = 1010;
        mNameOrdering[i++] = 1007;
        mNameOrdering[i++] = 1009;
        mNameOrdering[i++] = 1002;
        mNameOrdering[i++] = 1003;
        mNameOrdering[i++] = 1001;
        mNameOrdering[i++] = 1006;
        mNameOrdering[i++] = 1004;
        mNameOrdering[i++] = 1005;
    }

    /**
     * Tests the natural ordering of a TreeSet.
     */
    public void testCompareTo() {
        //TreeSet tree = new TreeSet(new EmployeeComparator());
        TreeSet tree = new TreeSet();
        for (int i = 0; i < mEmployees.length; i++) {
            tree.add(mEmployees[i]);
        }

        // verify order - by id
        Iterator iter = tree.iterator();

        int lastId = -1;
        while (iter.hasNext()) {
            Employee emp = (Employee)iter.next();
            int id = emp.getEmployeeId();
            assertTrue(id > lastId);
            lastId = id;
        }
    }

    /**
     * Tests the comparator ordering of a TreeSet.
     */
    public void testComparator() {
        TreeSet tree = new TreeSet(new EmployeeComparator());
        for (int i = 0; i < mEmployees.length; i++) {
            tree.add(mEmployees[i]);
        }

        // verify order - by name
        Iterator iter = tree.iterator();

        int orderingNdx = 0;
        while (iter.hasNext()) {
            Employee emp = (Employee)iter.next();
            int id = emp.getEmployeeId();
            assertEquals(mNameOrdering[orderingNdx++], id);
        }
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(TreeSetExTest.class));
    }
}
