package edu.washington.example.collections;

import java.util.Comparator;

/**
 * A comparator for the employee class places in accending order by last name,
 * first name and finally employee id.  Will assume duplicate id's are not
 * but won't check for them.
 *
 * @author Russ Moul
 */
public final class EmployeeComparator implements Comparator {
    /**
     * Compares its two arguments for order. Returns a negative integer, zero,
     * or a positive integer as the first argument is less than, equal to, or
     * greater than the second.
     *
     * @param o1 first object to be compared
     * @param o2 second object to be compared
     * @return a negative integer, zero, or a positive integer as the first
     *         argument is less than, equal to, or greater than the second.
     *         But, should never actually return zero.
     */
    public int compare(final Object o1, final Object o2) {
        // Casting operations will through ClassCastException if arguments
        // are not of class Employee
        Employee e1 = (Employee) o1;
        Employee e2 = (Employee) o2;
        int result = 0;

        if ((result = e1.getLastName().compareTo(e2.getLastName())) == 0) {
            if ((result = e1.getFirstName()
                            .compareTo(e2.getFirstName())) == 0) {
                result = e1.getEmployeeId() - e2.getEmployeeId();
            }
        }

        return result;
    }

    /**
     * Indicates whether some other object is "equal to" this Comparator.
     *
     * @param obj the reference object with which to compare
     *
     * @return true only if the specified object is also an EmployeeComparator
     */
    public boolean equals(final Object obj) {
        return obj instanceof EmployeeComparator;
    }

    /** Hash code seed. */
    private static final int HASH_SEED = 17;

    /** Hash multiplier. */
    private static final int HASH_MULTIPLIER = 37;

    /**
     * Returns a hash code value for the object.
     *
     * @return a hash code value for this object
     */
    public int hashCode() {
        int hc = HASH_SEED;
        hc = HASH_MULTIPLIER * hc + Employee.class.hashCode();
        return hc;
    }

}
