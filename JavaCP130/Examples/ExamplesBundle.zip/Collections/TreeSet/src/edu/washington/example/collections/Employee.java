package edu.washington.example.collections;


/**
 * Simple employee representation,all internal values are immutable.
 *
 * @author Russ Moul
 */
public final class Employee implements Comparable {
    /** Last name. */
    private String mLastName;

    /** First name. */
    private String mFirstName;

    /** Employee Id. */
    private int mEmployeeId;

    /**
     * The sole constructor.
     *
     * @param lName the employee's last name
     * @param fName the employee's first name
     * @param empId the employee's employees id
     */
    public Employee(final String lName, final String fName, final int empId) {
        mLastName = lName;
        mFirstName = fName;
        mEmployeeId = empId;
    }

    /**
     * Gets the employee's last name.
     *
     * @return employee last name
     */
    public String getLastName() {
        return mLastName;
    }

    /**
     * Gets the employee's first name.
     *
     * @return employee first name
     */
    public String getFirstName() {
        return mFirstName;
    }

    /**
     * Gets the employee's id.
     *
     * @return employee id
     */
    public int getEmployeeId() {
        return mEmployeeId;
    }

    /**
     * Compares two Employees, two employees are considered equal if they have
     * the employee id.
     *
     * @param o the Object to be compared
     *
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object
     *
     * @throws ClassCastException  if the specified object is not an Cube
     */
    public int compareTo(final Object o) throws ClassCastException {
        Employee otherEmployee = (Employee)o;
        int diff = mEmployeeId - otherEmployee.mEmployeeId;
        return diff;
    }

    /** Hash code seed. */
    private static final int HASH_SEED = 17;

    /** Hash multiplier. */
    private static final int HASH_MULTIPLIER = 37;

    /** Size of int, half size of long. */
    private static final int BITS_32 = 32;

    /**
     * Returns a hash code value for the object.
     *
     * @return a hash code value for this object
     */
    public int hashCode() {
        int hc = HASH_SEED;
        long v;
        hc = HASH_MULTIPLIER * hc + mEmployeeId;
        hc = HASH_MULTIPLIER * hc + mLastName.hashCode();
        hc = HASH_MULTIPLIER * hc + mFirstName.hashCode();
        return hc;
    }

    /**
     * Compares two Cubes, two cubes are considered equal if they have the
     * same width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return true if and only if the width, height and depth are equal.
     */
    public boolean equals(final Object o) {
        boolean eq = false;
        if (o != null && o instanceof Employee) {
            eq = compareTo(o) == 0;
        }
        return eq;
    }

    /**
     * Creates a string of the form "employee_id last_name, firstname".
     *
     * @return a string representation of the Employee as described above
     */
    public String toString() {
        return "" + mEmployeeId + " " + mLastName + ", " + mFirstName;
    }
}
