package edu.washington.example.reflection;

/**
 * A stock, consisting of a ticker symbol and price.
 *
 * @author Russ Moul
 */
public final class Stock {
    /** Maximum length of a ticker. */
    private static final int MAX_TICKER_LEN = 4;

    /** The ticker symbol. */
    private String mTicker = " ";

    /** The stock price. */
    private int mPrice = 0;

    /**
     * Default constructor.
     */
    public Stock() {
    }

    /**
     * Constructor.
     *
     * @param ticker the stock ticker
     * @param price the stock price
     */
    public Stock(final String ticker, final int price) {
        setTicker(ticker);
        setPrice(price);
    }

    /**
     * Sets the ticker.
     *
     * @param ticker the stock ticker
     */
    private void setTicker(final String ticker) {
        String tmpTicker = ticker.trim();

        if ((tmpTicker == null) || (tmpTicker.length() == 0)
                                || (tmpTicker.length() > MAX_TICKER_LEN)) {
            throw new IllegalArgumentException(
                "Ticker must be 1 to 4 chararacters.");
        }

        mTicker = tmpTicker;
    }

    /**
     * Gets the ticker.
     *
     * @return the stock ticker
     */
    public String getTicker() {
        return mTicker;
    }

    /**
     * Sets the price.
     *
     * @param price the stock price
     */
    public void setPrice(final int price) {
        if (price < 0) {
            throw new IllegalArgumentException(
                "Price must be a positive value.");
        }

        mPrice = price;
    }

    /**
     * Gets the price.
     *
     * @return the stock price
     */
    public int getPrice() {
        return mPrice;
    }

    /**
     * Gets the string representation of the stock, <i>ticker</i>:<i>price</i>
     *
     * @return the string
     */
    public String toString() {
        return mTicker + ":" + mPrice;
    }
}
