package demo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/////////////////////////////////////////////////////
// NOTE:                                           //
// The demo.hidden.MessageLooper is not imported,  //
// not available a compile time.                   //
/////////////////////////////////////////////////////

/**
 * Simple demonstration of the use of reflection.  Methods of this class are
 * discovered using reflection and invoked.
 *
 * @author Russ Moul
 */
public final class ReflectDemo {
    /** 4 iterations. */
    private static final int ITERATION_CNT_4 = 4;

    /** 6 iterations. */
    private static final int ITERATION_CNT_6 = 6;

    /** This objects name. */
    private String mName;

    /**
     * Prevent instantiation.
     */
    private ReflectDemo() {
    }

    /**
     * Use reflection to instantiate an object, modify a field and invoke its
     * methods.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        try {
            // get the class
            Class cls;
            cls = Class.forName("demo.hidden.MessageLooper");

            // get the constructor
            String name = "ReflectDemo";
            Class stringClass = name.getClass(); // get the string class
            Class[] constructorArgTypes = {stringClass};
            Constructor constructor = cls.getConstructor(constructorArgTypes);

            // create an instance
            Object[] constructorArgs = {name};
            Object obj = constructor.newInstance(constructorArgs);

            // get the iteration count field
            Field mIterationCountField = cls.getField("mIterationCount");
            mIterationCountField.setInt(obj, ITERATION_CNT_4);

            // get the first iteration method
            Class[] iterMethod1ArgTypes = {stringClass};
            Method method = cls.getMethod("runIteration", iterMethod1ArgTypes);

            // invoke first iteration method
            Object[] iterMethod1Args = {"Hello world!"};
            Integer cnt = (Integer) method.invoke(obj, iterMethod1Args);
            System.out.println("Iterated " + cnt + " times");

            // get the second iteration method
            Class[] iterMethod2ArgTypes = {stringClass, int.class};
            method = cls.getMethod("runIteration", iterMethod2ArgTypes);

            // invoke second iteration method
            Integer iterObj = new Integer(ITERATION_CNT_6);
            Object[] iterMethod2Args = {"Goodbye world!", iterObj};
            cnt = (Integer) method.invoke(obj, iterMethod2Args);
            System.out.println("Iterated " + cnt + " times");
        } catch (NoSuchMethodException ex) {
            System.out.println("Need to add method: test( ");
        } catch (Exception iex) {
            iex.printStackTrace();
            System.out.println("Need to fix method: test( ");
        }
    }
}
