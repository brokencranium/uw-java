package demo.hidden;

/**
 * A class having methods that print a message a specified number of times.
 *
 * @author Russ Moul
 */
public final class MessageLooper {
    /** This objects name. */
    private String mName;

    /** The number of iterations to perform in the runIteration method. */
    public int mIterationCount;

    /**
     * Constructor.
     *
     * @param name the name to be given to this object
     */
    public MessageLooper(final String name) {
        this.mName = name;
    }

    /**
     * Iterate according to the value in the mIterationCount field.
     *
     * @param message the message to print in the iteration
     *
     * @return the number of iterations performed
     */
    public int runIteration(final String message) {
        return runIteration(message, mIterationCount);
    }

    /**
     * Iterate the specifed number of times printing the message.
     *
     * @param message the message to print in the iteration
     * @param iterations the number of iterations to perform
     *
     * @return the number of iterations performed
     */
    public int runIteration(final String message, final int iterations) {
        System.out.println();
        System.out.println(mName + " beginning iteration...");

        for (int i = 0; i < iterations; i++) {
            System.out.println("" + i + ") " + message);
        }

        return iterations;
    }
}
