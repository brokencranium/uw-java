package test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import edu.washington.example.serialization.Cube;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test case for the serializable cube class Cube.
 *
 * @author Russ Moul
 */
public final class CubeTest extends TestCase {

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public CubeTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the serialization.
     */
    public void testSerialization() throws Exception {
        Cube kube = new Cube(2.0, 1.0, 3.0);

        // open the output file and layer an ObjectOutputStream on it
        FileOutputStream f = new FileOutputStream("cube.ser");
        ObjectOutputStream fout = new ObjectOutputStream(f);

        // write the Cube object to file
        fout.writeObject(kube);
        fout.close();

        // open the input file and layer an ObjectInputStream on it
        FileInputStream fis = new FileInputStream("cube.ser");
        ObjectInputStream fin = new ObjectInputStream(fis);

        // read the cube
        Cube c = (Cube) fin.readObject();
        fin.close();

        assertEquals(kube, c);
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(CubeTest.class));
    }
}
