package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import edu.washington.example.serialization.FieldCube;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test case for the serializable cube class Cube.
 *
 * @author Russ Moul
 */
public final class FieldCubeTest extends TestCase {
    private static final double WIDTH = 2.0;
    private static final double HEIGHT = 1.0;
    private static final double DEPTH = 3.0;

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public FieldCubeTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the serialization methods.
     */
    public void testSerialization() throws Exception {
        File serFile = new File("cube.ser");

        FieldCube kube;
        if (!serFile.exists()) {
            kube = new FieldCube(WIDTH, HEIGHT, DEPTH);

            // open the output file and layer an ObjectOutputStream on it
            FileOutputStream f = new FileOutputStream(serFile);
            ObjectOutputStream fout = new ObjectOutputStream(f);

            // write the FieldCube object to file
            fout.writeObject(kube);
            fout.close();
        }

        // open the input file and layer an ObjectInputStream on it
        FileInputStream fis = new FileInputStream(serFile);
        ObjectInputStream fin = new ObjectInputStream(fis);

        // read the cube
        FieldCube c = (FieldCube) fin.readObject();
        fin.close();

        assertEquals(WIDTH, c.getWidth(), 0.0);
        assertEquals(HEIGHT, c.getHeight(), 0.0);
        assertEquals(DEPTH, c.getDepth(), 0.0);
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(FieldCubeTest.class));
    }
}
