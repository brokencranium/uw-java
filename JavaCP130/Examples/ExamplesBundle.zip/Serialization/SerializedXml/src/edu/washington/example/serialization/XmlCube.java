package edu.washington.example.serialization;

/**
 * A simple cube JavaBean that supports XML serialization.
 *
 * @author Russ Moul
 */
public final class XmlCube {
     /** The width. */
    private double mWidth;

    /** The height. */
    private double mHeight;

    /** The depth. */
    private double mDepth;

    /**
     * Default constructor.
     */
     public XmlCube() {
    }

    /**
     * Constructor.
     *
     * @param width the cube's width
     * @param height the cube's height
     * @param depth the cube's height
     */
    public XmlCube(final double width, final double height,
                    final double depth) {
        mWidth = width;
        mHeight = height;
        mDepth = depth;
    }

    /**
     * Get the width.
     *
     * @return the width
     */
    public double getWidth() {
        return mWidth;
    }

    /**
     * Set the width.
     *
     * @param width the width
     */
    public void setWidth(final double width) {
        mWidth = width;
    }

    /**
     * Get the height.
     *
     * @return the height
     */
    public double getHeight() {
        return mHeight;
    }

    /**
     * Set the height.
     *
     * @param height the height
     */
    public void setHeight(final double height) {
        mHeight = height;
    }

    /**
     * Get the depth.
     *
     * @return the depth
     */
    public double getDepth() {
        return mDepth;
    }

    /**
     * Set the depth.
     *
     * @param depth the depth
     */
    public void setDepth(final double depth) {
        mDepth = depth;
    }

    /**
     * Compares two Cubes, two cubes are considered equal if they have the
     * same width, height and depth.  The during comparision the properties in
     * have the following order of significance width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object
     *
     * @throws ClassCastException  if the specified object is not an Cube
     */
    public int compareTo(final Object o) throws ClassCastException {
        XmlCube otherCube = (XmlCube)o;
        double diff = mWidth - otherCube.mWidth;
        if (diff == 0) {
            diff = mHeight - otherCube.mHeight;
        }
        if (diff == 0) {
            diff = mDepth - otherCube.mDepth;
        }
        return (diff < 0) ? -1 : (diff > 0) ? 1 : 0;
    }

    /** Hash code seed. */
    private static final int HASH_SEED = 17;

    /** Hash multiplier. */
    private static final int HASH_MULTIPLIER = 37;

    /** Size of int, half size of long. */
    private static final int BITS_32 = 32;

    /**
     * Returns a hash code value for the object.
     *
     * @return a hash code value for this object
     */
    public int hashCode() {
        int hc = HASH_SEED;
        long v;
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        return hc;
    }


    /**
     * Compares two Cubes, two cubes are considered equal if they have the
     * same width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return true if and only if the width, height and depth are equal.
     */
    public boolean equals(final Object o) {
        boolean eq = false;
        if (o != null && o instanceof XmlCube) {
            eq = compareTo(o) == 0;
        }
        return eq;
    }

    /**
     * Returns a string represnetaion of the Cube object.
     *
     * @return a String representation of this object
     */
    public String toString() {
        return ("Height: " + mHeight
            + "\nWidth:  " + mWidth
            + "\nDepth:  " + mDepth);
    }
}
