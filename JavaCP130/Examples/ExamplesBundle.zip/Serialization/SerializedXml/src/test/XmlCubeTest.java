package test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;

import edu.washington.example.serialization.XmlCube;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test case for the XML serializable cube class XmlCube.
 *
 * @author Russ Moul
 */
public final class XmlCubeTest extends TestCase {

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public XmlCubeTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the serialization.
     */
    public void testSerialization() throws Exception {
        XmlCube kube = new XmlCube(2.0, 1.0, 3.0);

        // open the output file and layer an XMLEncoder on it
        FileOutputStream f = new FileOutputStream("cube.xml");
        XMLEncoder out = new XMLEncoder(f);

        // write the XmlCube object to file
        out.writeObject(kube);
        out.close();

        // open the input file and layer an XMLDecoder on it
        FileInputStream fis = new FileInputStream("cube.xml");
        XMLDecoder in = new XMLDecoder(fis);

        XmlCube c = (XmlCube) in.readObject();
        in.close();

        assertEquals(kube, c);
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(XmlCubeTest.class));
    }
}
