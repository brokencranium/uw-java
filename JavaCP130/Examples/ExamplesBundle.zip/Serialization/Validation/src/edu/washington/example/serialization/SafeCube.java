package edu.washington.example.serialization;

import java.io.InvalidObjectException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectInputValidation;
import java.io.Serializable;

/**
 * A cube class that uses object validation.
 *
 * @author Russ Moul
 */
public final class SafeCube implements Serializable, ObjectInputValidation {
    /** The surface area. */
    private transient double mSurfaceArea;

    /** The volume area. */
    private transient double mVolume;

    /** The height. */
    private double mHeight;

    /** The width. */
    private double mWidth;

    /** The depth. */
    private double mDepth;

    /**
     * Constructor.
     *
     * @param width the cube's width
     * @param height the cube's height
     * @param depth the cube's height
     */
     public SafeCube(final double width, final double height,
                     final double depth) {
        mWidth = width;
        mHeight = height;
        mDepth = depth;
        init();
    }

    /**
     * Initialize the transient fields.
     */
    public void init() {
        mSurfaceArea = ((mWidth * mHeight) + (mWidth * mDepth)
                     + (mHeight * mDepth)) * 2;
        mVolume = mWidth * mHeight * mDepth;
    }

    /**
     * Validates the object.  If validation is successful the transient fields
     * are initialized.
     *
     * @throws InvalidObjectException if the width, height or depth is less than
     *                                or equal to zero
     */
    public void validateObject() throws InvalidObjectException {
        if ((mHeight <= 0) || (mWidth <= 0) || (mDepth <= 0)) {
            throw new InvalidObjectException("Cube is not three dimensional!");
        }

        System.out.println("Initializing surface area and volume.");
        init();
    }

    /**
     * Reads the object from stream.
     *
     * @param in the stream to read the object from
     *
     * @throws IOException if any I/O exceptions occur
     * @throws ClassNotFoundException if the read object's class can't be loaded
     */
    private void readObject(final ObjectInputStream in)
        throws IOException, ClassNotFoundException {
        in.registerValidation(this, 0);
        in.defaultReadObject();
    }

    /**
     * Compares two SafeCubes, two cubes are considered equal if they have the
     * same width, height and depth.  The during comparision the properties in
     * have the following order of significance width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object
     *
     * @throws ClassCastException  if the specified object is not an SafeCube
     */
    public int compareTo(final Object o) throws ClassCastException {
        SafeCube otherCube = (SafeCube)o;
        double diff = mWidth - otherCube.mWidth;
        if (diff == 0) {
            diff = mHeight - otherCube.mHeight;
        }
        if (diff == 0) {
            diff = mDepth - otherCube.mDepth;
        }
        return (diff < 0) ? -1 : (diff > 0) ? 1 : 0;
    }

    /** Hash code seed. */
    private static final int HASH_SEED = 17;

    /** Hash multiplier. */
    private static final int HASH_MULTIPLIER = 37;

    /** Size of int, half size of long. */
    private static final int BITS_32 = 32;

    /**
     * Returns a hash code value for the object.
     *
     * @return a hash code value for this object
     */
    public int hashCode() {
        int hc = HASH_SEED;
        long v;
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        return hc;
    }

    /**
     * Compares two SafeCubes, two cubes are considered equal if they have the
     * same width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return true if and only if the width, height and depth are equal.
     */
    public boolean equals(final Object o) {
        boolean eq = false;
        if (o != null && o instanceof SafeCube) {
            eq = compareTo(o) == 0;
        }
        return eq;
    }

    /**
     * Returns a string represnetaion of the SafeCube object.
     *
     * @return a String representation of this object
     */
    public String toString() {
        return ("Height: " + mHeight
            + "\nWidth:  " + mWidth
            + "\nDepth:  " + mDepth
            + "\nArea:   " + mSurfaceArea
            + "\nVolume: " + mVolume);
    }

}
