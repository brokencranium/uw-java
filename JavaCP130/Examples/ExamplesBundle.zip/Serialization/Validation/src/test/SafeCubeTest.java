package test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import edu.washington.example.serialization.SafeCube;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test case for the cube class SafeCube.
 *
 * @author Russ Moul
 */
public final class SafeCubeTest extends TestCase {

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public SafeCubeTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the serialization.
     */
    public void testSerialization() throws Exception {
        SafeCube kube = new SafeCube(2.0, 1.0, 3.0);

        // open the output file and layer an ObjectOutputStream on it
        FileOutputStream f = new FileOutputStream("cube.ser");
        ObjectOutputStream fout = new ObjectOutputStream(f);

        // write the SafeCube object to file
        fout.writeObject(kube);
        fout.close();

        // open the input file and layer an ObjectInputStream on it
        FileInputStream fis = new FileInputStream("cube.ser");
        ObjectInputStream fin = new ObjectInputStream(fis);

        SafeCube c = (SafeCube) fin.readObject();
        fin.close();

        assertEquals(kube, c);

        kube = new SafeCube(2.0, 1.0, -1.0);

        try {
            // open the output file and layer an ObjectOutputStream on it
            f = new FileOutputStream("cube.ser");
            fout = new ObjectOutputStream(f);

            // write the SafeCube object to file
            fout.writeObject(kube);
            fout.close();

            // open the input file and layer an ObjectInputStream on it
            fis = new FileInputStream("cube.ser");
            fin = new ObjectInputStream(fis);

            c = (SafeCube) fin.readObject();
            fin.close();

            fail("Should have detected the invalid cube.");
        } catch (InvalidObjectException ex) {
        }
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(SafeCubeTest.class));
    }
}
