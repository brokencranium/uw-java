package edu.washington.example.rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;


/**
 * Provides a source for unique integer keys.  The server provides a sequence
 * of integer keys, without repeating.
 *
 * @author Russ Moul
 */
public final class SeqKeyServer extends UnicastRemoteObject implements SeqKey {
    /** Default naming/registry port */
    private static final int DEFAULT_REGISTRY_PORT = 1099;

    /** The value of the next key. */
    private long mKey = 1;

    /**
     * Creates a server instance.
     *
     * @throws RemoteException if the remote export fails
     */
    public SeqKeyServer() throws RemoteException {
    }

    /**
     * Gets the next key in the sequence.
     *
     * @return the key
     *
     * @throws RemoteException if the remote invocation fails
     */
    public synchronized long getKey() throws RemoteException {
        return mKey++;
    }

    /**
     * Gets the next count keys in the sequence.
     *
     * @param count the number of keys to be provided
     *
     * @return an array of consecutive keys
     *
     * @throws RemoteException if the remote invocation fails
     */
    public synchronized long[] getKey(final int count) throws RemoteException {
        // less than optimal solution to encourage locking if not synchronized
        long[] keys = new long[count];

        for (int i = 0; i < count; i++) {
            keys[i] = mKey++;
        }

        return keys;
    }

    /**
     * Starts the server running.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        //System.setSecurityManager( new java.rmi.RMISecurityManager() );
        Registry reg = null;

        // locate or create a rmiregistry
        try {
            reg = LocateRegistry.createRegistry(DEFAULT_REGISTRY_PORT);
            System.out.println("Using new Registry server");
        } catch (RemoteException createEx) {
            System.out.println(
                "Can't create registry locating existing registry");

            try {
                reg = LocateRegistry.getRegistry();
                System.out.println("Using existing Registry server");
            } catch (RemoteException locateEx) {
                System.out.println("Can't LocateRegistry");
                System.exit(1);
            }
        }

        try {
            SeqKeyServer server = new SeqKeyServer();
            reg.rebind("KeyServer", server);
            System.out.println("Sequence server is ready!");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
}
