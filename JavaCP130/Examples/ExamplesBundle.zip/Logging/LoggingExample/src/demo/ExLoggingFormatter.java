package demo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;


/**
 * A logging formatter that writes a single line.  The following format is used:
 * <pre>
 *   [yyyy/mm/dd hh:mm:ss:SSSS] LEVEL: class.method: message text
 * </pre>
 *
 * <p>
 * The edu.washington.ext.cp130.util.BriefLogFormatter.fullClassNames log
 * manager property may be used to instruct the formatter to use fully qualified
 * class names.
 *
 * @author Russ Moul
 */
public final class ExLoggingFormatter extends Formatter {
    /** The platform specific line termination character(s). */
    private static final String LINE_TERM =
                                System.getProperty("line.separator");

    /** Date format string */
    private static final String DATE_FMT = "[yyyy/MM/dd HH:mm:ss:SSSS]";

    /** Date formatting object */
    private SimpleDateFormat mDateFormatter = new SimpleDateFormat(DATE_FMT);

    /** Indicates whether full class names should be used, default is false. */
    private boolean mUseFullClassNames = false;

    /**
     * Constructor.
     */
    public ExLoggingFormatter() {
        LogManager m = LogManager.getLogManager();
        String propName = this.getClass().getName() + ".fullClassNames";
        String prop = m.getProperty(propName);

        if (prop != null) {
            mUseFullClassNames = Boolean.valueOf(prop).booleanValue();
        }
    }

    /**
     * Constructor.
     *
     * @param useFullClassNames should fully qualified path names be used
     */
    public ExLoggingFormatter(final boolean useFullClassNames) {
        mUseFullClassNames = useFullClassNames;
    }

    /**
     * Format the given log record and return the formatted string.
     *
     * @param record the log record to be formatted
     *
     * @return the formatted string
     */
    public String format(final LogRecord record) {
        String time = mDateFormatter.format(new Date(record.getMillis()));
        String className = record.getSourceClassName();

        if (!mUseFullClassNames) {
            int ndx = className.lastIndexOf('.');

            if (ndx != -1) {
                className = className.substring(ndx + 1);
            }
        }

        StringBuffer buf = new StringBuffer(time);
        buf.append(" ");
        buf.append(record.getLevel().toString());
        buf.append(":");
        buf.append(className);
        buf.append(".");
        buf.append(record.getSourceMethodName());
        buf.append(":");
        buf.append(formatMessage(record));
        buf.append(LINE_TERM);
     
        Throwable t = record.getThrown();
        if (t != null) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            t.printStackTrace(pw);
            pw.close();
            buf.append(sw.toString());
            buf.append(LINE_TERM);
        }

        return buf.toString();
    }
}

