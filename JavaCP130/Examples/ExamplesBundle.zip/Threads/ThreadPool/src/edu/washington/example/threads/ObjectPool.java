package edu.washington.example.threads;

import java.util.Stack;

/**
 * A simple implementation of an object pool.
 *
 * @author Russ Moul
 */
public abstract class ObjectPool {
    /** The pool. */
    private Stack mStack = new Stack();

    /**
     * Obtains an available object from the pool.  If no objects are available
     * in the pool block until one becomes available.
     *
     * @return the object obtained from the pool
     */
    public final synchronized Object pull() {
        while (mStack.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException ie) {
                ie.printStackTrace();
            }
        }

        Object obj = mStack.pop();

        return obj;
    }

    /**
     * Place an object back into the pool.
     *
     * @param obj the object to be placed in the pool
     */
    public final synchronized void push(final Object obj) {
        mStack.push(obj);
        notify();
    }
}
