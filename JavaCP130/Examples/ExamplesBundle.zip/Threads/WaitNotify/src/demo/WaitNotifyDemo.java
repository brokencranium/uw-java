package demo;

/**
 * Demonstrates how the order in which threads call wait and notify may effect
 * a program - allowing it to run or deadlock.  The the test program is ran
 * with no arguments the program runs fine, if any arguments are provided it
 * deadlocks.  The example manipulates an internal value which is
 * initialized to zero.
 *
 * @author Russ Moul
 */
public final class WaitNotifyDemo {
    /** The lock. */
    private Object mLock = new Object();

    /** The value to be incremented. */
    private int mValue = 0;

    /**
     * Increments an internal value, prints a message announcing the thread is
     * calling wait() and then calls wait(). Upon resuming from wait() prints a
     * message announcing this, decements the internal value and prints it.
     */
    void method1() {
        synchronized (mLock) {
            ++mValue;

            try {
                System.out.println(Thread.currentThread().getName()
                                 + " calling wait");
                mLock.wait();
                System.out.println(Thread.currentThread().getName()
                                 + " continuing after wait");
            } catch (InterruptedException ex) {
                System.out.println(ex);
            } finally {
                --mValue;
                System.out.println(mValue);
            }
        }
    }

    /**
     * Prints a message announcing the thread is calling notify() and then calls
     * notify() and prints a message announcing this has been accomplished.
     */
    void method2() {
        synchronized (mLock) {
            System.out.println(Thread.currentThread().getName()
                             + " calling notify");
            mLock.notify();
            System.out.println(Thread.currentThread().getName()
                             + " called notify");
            --mValue;
        }
    }

    /**
     * Creates one instance each of TestThread1 and TestThread2, providing each
     * with a unique name and initializing them with a refernce to the same
     * WaitNotifyDemo object.  If no arguments are passed TestThread1 is started
     * followed by TestThread2, if an argument is provided the order is
     * reversed.
     *
     * @param args if no arguments are provided TestThread1 is started followed
     *             by TestThread2, otherwise the order is reversed.
     */
    public static void main(final String[] args) {
        WaitNotifyDemo obj = new WaitNotifyDemo();
        Thread t1 = new TestThread1("T1", obj);
        Thread t2 = new TestThread2("T2", obj);

        if (args.length == 0) {
            t1.start();
            System.out.println("Thread 1 started");
            t2.start();
            System.out.println("Thread 2 started");
        } else {
            t2.start();
            System.out.println("Thread 2 started");
            t1.start();
            System.out.println("Thread 1 started");

            // Note that t1 never gets done
        }
    }
}


/**
 * A test thread whose run method simply calls method1() on the WaitNotifyDemo
 * object.
 *
 * @author Russ Moul
 */
final class TestThread1 extends Thread {
    private WaitNotifyDemo mWaitNotify;

    /**
     * Constructs the thread, giving it a name and WaitNotifyDemo object to
     * invoke method1() on.
     *
     * @param name for the thread
     * @param o the WaitNotifyDemo object
     */
    public TestThread1(final String name, final WaitNotifyDemo o) {
        super(name);
        mWaitNotify = o;
    }

    /**
     * Call method1() on the WaitNotifyDemo object and then prints a message
     * indicating this thread is done and terminates.
     */
    public void run() {
        mWaitNotify.method1();
        System.out.println(getName() + " done");
    }
}


/**
 * A test thread whose run method simply calls method2() on the WaitNotifyNotify
 * object.
 *
 * @author Russ Moul
 */
final class TestThread2 extends Thread {
    private WaitNotifyDemo mWaitNotify;

    /**
     * Constructs the thread, giving it a name and WaitNotifyDemo object to
     * invoke method2() on.
     *
     * @param name for the thread
     * @param o the WaitNotifyDemo object
     */
    public TestThread2(final String name, final WaitNotifyDemo o) {
        super(name);
        mWaitNotify = o;
    }

    /**
     * Call method2() on the WaitNotifyDemo object and then prints a message
     * indicating this thread is done and terminates.
     */
    public void run() {
        mWaitNotify.method2();
        System.out.println(getName() + " done");
    }
}
