package demo;

import java.util.Iterator;
import java.util.LinkedList;

import edu.washington.example.threads.ReadWriteLock;

/**
 * Demonstrates a read write lock by allowing separate threads to add to delete
 * from and print the contents of a list.
 *
 * @author Russ Moul
 */
public final class RWLockDemo {
    /**
     * Set up and run the test.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        LinkedList list = new LinkedList();
        ReadWriteLock lock = new ReadWriteLock();

        ListAdder addr = new ListAdder(list, lock);
        addr.start();

        ListPrinter prntr1 = new ListPrinter(list, lock, "");
        prntr1.start();

        ListPrinter prntr2 = new ListPrinter(list, lock, "          ");
        prntr2.start();

        ListDeleter delr = new ListDeleter(list, lock);
        delr.start();
    }
}


/**
 * Uses a read-write lock to repeatedly obtain access to a list and add a value
 * to the list.
 *
 * @author Russ Moul
 */
final class ListAdder extends Thread {
    /** The list. */
    LinkedList mList;

    /** The read-write lock. */
    ReadWriteLock mLock;

    /**
     * Constructs an instance providing the list and lock object to be used.
     *
     * @param list the list to add items to
     * @param lock the read-write lock
     */
    public ListAdder(final LinkedList list, final ReadWriteLock lock) {
        mList = list;
        mLock = lock;
    }

    /**
     * Repeatedly aquires the write lock and if the list is not adds an item to
     * the list.
     */
    public void run() {
        while (true) {
            mLock.acquireWrite();

            int size = mList.size();

            if (size < 10) {
                System.out.println("====== ADDING ======");
                mList.addLast(new Integer(size));
            }

            mLock.releaseWrite();

            // cause an artificial delay
            int delay = (int) (Math.random() * 100.0);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}


/**
 * Uses a read-write lock to repeatedly obtain write access to a list and delete
 * a value from the list.
 *
 * @author Russ Moul
 */
final class ListDeleter extends Thread {
    /** The list. */
    LinkedList mList;

    /** The read-write lock. */
    ReadWriteLock mLock;

    /**
     * Constructs an instance providing the list and lock object to be used.
     *
     * @param list the list to delete items from
     * @param lock the read-write lock
     */
    public ListDeleter(final LinkedList list, final ReadWriteLock lock) {
        mList = list;
        mLock = lock;
    }

    /**
     * Aquires the write lock and if the list is not empty deletes an item from
     * the list.
     */
    public void run() {
        while (true) {
            mLock.acquireWrite();

            if (mList.size() > 0) {
                System.out.println("===== DELETING =====");
                mList.removeLast();
            }

            mLock.releaseWrite();

            // cause an artificial delay
            int delay = (int) (Math.random() * 100.0);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}


/**
 * Uses a read-write lock to repeatedly obtain read access to a list and print
 * its contents.
 *
 * @author Russ Moul
 */
final class ListPrinter extends Thread {
    /** The list. */
    LinkedList mList;

    /** The read-write lock. */
    ReadWriteLock mLock;

    String mPrefix;

    /**
     * Constructs an instance providing the list and lock object to be used.
     *
     * @param list the list to print items from
     * @param lock the read-write lock
     * @param prefix preceed all status messages with this prefix
     */
    public ListPrinter(final LinkedList list, final ReadWriteLock lock,
                       final String prefix) {
        mList = list;
        mLock = lock;
        mPrefix = prefix;
    }

    /**
     * Aquires the read lock and prints the contents of the list the list.  Each
     * item is preceeded by this instances prefix.
     */
    public void run() {
        while (true) {
            mLock.acquireRead();

            Iterator iter = mList.iterator();

            while (iter.hasNext())
                System.out.println(mPrefix + iter.next());

            iter = null;
            mLock.releaseRead();

            // cause an artificial delay
            int delay = (int) (Math.random() * 100.0);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}
