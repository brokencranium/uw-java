package edu.washington.example.threads;

import java.util.LinkedList;


/**
 * Produces integers within a range and places them in a linked list.
 *
 * @author Russ Moul
 */
public final class Producer extends Thread {
    /** Maximum delay. */
    private static final double MAX_DELAY = 100.0;

    /** The list to populate. */
    private LinkedList mList;

    /** The starting value for the producer. */
    private int mStart;

    /** The limiting value for the producer. */
    private int mLimit;

    /**
     * Constructs a producer specifying the list to populate and the range of
     * values to populate the list with.
     *
     * @param name a name for identifying the thread
     * @param list the list to populate
     * @param start the beginning value to populate the list with
     * @param limit the limit value, only values less than this will populate
     *              the list
     */
    public Producer(final String name, final LinkedList list,
                    final int start, final int limit) {
        super(name);
        mList = list;
        mStart = start;
        mLimit = limit;
    }

    /**
     * Populates the list with values notifying consumers after placing an item
     * in the list.
     */
    public void run() {
        int i = mStart;

        do {
            Integer item = new Integer(i);

            synchronized (mList) {
                mList.addLast(item);
                System.out.println(getName() + " Produced: " + item);
                mList.notify();
            }

            // cause an artificial delay
            int delay = (int) (Math.random() * MAX_DELAY);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        } while (i++ < mLimit);
        System.out.println(getName() + " termintaing!");
    }
}
