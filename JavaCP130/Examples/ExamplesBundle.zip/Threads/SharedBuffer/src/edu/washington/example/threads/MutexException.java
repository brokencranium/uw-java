package edu.washington.example.threads;

/**
 * Thrown when a thread that does not have ownership of a mutex attempts to
 * unlock the mutex.
 *
 * @author Russ Moul
 */
public final class MutexException extends RuntimeException {
    /**
     * Default constructor.
     */
    public MutexException() {
        super("Realeasing Thread does not own mutex");
    }
}
