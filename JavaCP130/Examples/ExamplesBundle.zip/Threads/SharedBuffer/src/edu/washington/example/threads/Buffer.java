package edu.washington.example.threads;

/**
 * Interface defining a simple buffer for holding integer values.
 *
 * @author Russ Moul
 */
public interface Buffer {
    /**
     * Places a value in the buffer.
     *
     * @param value the value to be placed in the buffer
     */
    void put(int value);

    /**
     * Gets a value from the buffer.
     *
     * @return a value from the buffer
     */
    int get();
}
