package edu.washington.example.threads;

/**
 * A simple mutex implementation.
 *
 * @author Russ Moul
 */
public final class Mutex {
    /** The thread currently holding the mutex. */
    private Thread mOwner;

    /** The lock count. */
    private int mLockCount;

    /**
     * Default constructor.
     */
    public Mutex() {
    }

    /**
     * Locks the mutex.  If no thread owns this mutex the thread takes ownership
     * and sets the lock count to 1, if the thread is already owned by this
     * thread the lock count is incremented, otherwise this thread waits until
     * it can obtain ownership.
     */
    public synchronized void lock() {
        boolean acquired = false;

        while (!acquired) {
            if (mOwner == null) {
                mOwner = Thread.currentThread();
                mLockCount = 1;
                acquired = true;
            } else if (mOwner == Thread.currentThread()) {
                mLockCount++;
                acquired = true;
            } else {
                try {
                    wait();
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    /**
     * Unlocks the mutex.  If the calling thread is the owns the mutex the lock
     * count is decremented, it the lock count reaches 0 ownership is released.
     */
    public synchronized void unlock() {
        if (mOwner != Thread.currentThread()) {
            throw new MutexException();
        }

        if (--mLockCount <= 0) {
            mOwner = null;
            notify(); // notify waiting threads
        }
    }
}
