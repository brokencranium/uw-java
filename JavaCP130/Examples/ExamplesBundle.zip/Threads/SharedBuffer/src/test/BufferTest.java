package test;

import edu.washington.example.threads.Buffer;
import edu.washington.example.threads.MutexCVBuffer;
import edu.washington.example.threads.SyncBuffer;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test case shared buffer classes.
 *
 * @author Russ Moul
 */
public final class BufferTest extends TestCase {

    /**
     * Simple constructor.
     *
     * @param testName the name the test is to be identified by
     */
    public BufferTest(final String testName) {
        super(testName);
    }

    /**
     * Tests the SyncBuffer.
     */
    public void testSyncBuffer() {
        Buffer buffer = null;
        int[] nextBuf = {0};
        int[] check = new int[1000];
        Consumer.resetBuffer(check);
        buffer = new SyncBuffer();

        // create and start 2 producers and consumers
        Thread c1 = new Consumer("Consumer_1", buffer, check);
        c1.start();

        Thread p1 = new Producer(buffer, nextBuf);
        p1.start();
        Thread c2 = new Consumer("Consumer_2", buffer, check);
        c2.start();
        Thread p2 = new Producer(buffer, nextBuf);
        p2.start();

        try {
            c1.join();
            c2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        assertTrue(Consumer.checkBuffer(check));
    }

    /**
     * Tests the MutexCVBuffer.
     */
    public void testMutexCVBuffer() {
        Buffer buffer = null;
        int[] nextBuf = {0};
        int[] check = new int[1000];
        Consumer.resetBuffer(check);
        buffer = new MutexCVBuffer();

        // create and start 2 producers and consumers
        Thread c1 = new Consumer("Consumer_1", buffer, check);
        c1.start();
        Thread p1 = new Producer(buffer, nextBuf);
        p1.start();
        Thread c2 = new Consumer("Consumer_2", buffer, check);
        c2.start();
        Thread p2 = new Producer(buffer, nextBuf);
        p2.start();

        try {
            c1.join();
            c2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        assertTrue(Consumer.checkBuffer(check));
    }

    /**
     * Runs the test suite.
     *
     * @param args (unused)
     */
    public static void main(final String[] args) {
        junit.textui.TestRunner.run(new TestSuite(BufferTest.class));
    }
}
