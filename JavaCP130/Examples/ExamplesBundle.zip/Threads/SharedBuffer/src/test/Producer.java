package test;

import edu.washington.example.threads.Buffer;

/**
 * A simple producer thread, produces integers in sequence an places them in
 * a buffer.  The integer sequence is shared by multiple instances of this class
 * so multiple instances of this class will not produce a given number more
 * than once.
 *
 * @author Russ Moul
 */
public class Producer extends Thread {
    /** The next value. */
    private int mNextValue[];

    /** The buffer. */
    private Buffer mBuf;

    /**
     * Constructor, creates a producer which will populate the specified buffer.
     *
     * @param buffer the buffer to populate with integers
     * @param nextValueBuf a single element buffer to hold a shared next value
     */
    public Producer(Buffer buffer, int[] nextValueBuf) {
        mBuf = buffer;
        mNextValue = nextValueBuf;
        setDaemon(true);
    }

    /**
     * Does the work, continually places the next integer in the sequence in the
     * buffer.
     */
    public void run() {
        while (true) {
            int x;

            synchronized (Producer.class) { // have to do this because the
                                            //increment may be interupted
                x = mNextValue[0]++;
            }

            mBuf.put(x);

            // cause an artificial delay
            int delay = (int) (Math.random() * 10.0);

            if ((delay % 2) == 0) {
                try {
                    sleep(delay);
                } catch (InterruptedException ex) {
                    return;
                }
            }
        }
    }
}
