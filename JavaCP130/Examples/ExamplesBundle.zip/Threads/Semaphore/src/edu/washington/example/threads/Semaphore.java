package edu.washington.example.threads;

/**
 * A simple semaphore as defined by Dijkstra.
 *
 * @author Russ Moul
 */
public final class Semaphore {
    /**
     * Used to configure a binary semaphore, or mutex.
     */
    public static final int MUTEX = 1; // binary semaphore

    /** Number of resources controlled by semaphore. */
    private int mResourceCnt;

    /**
     * Creates a semaphore for a specified number of resources.
     *
     * @param cnt the numer or resources controled by the semaphore
     */
    public Semaphore(final int cnt) {
        mResourceCnt = cnt;
    }

    /**
     * Releases a resource and increments the resource count and notifies
     * waiting threads.
     */
    public synchronized void up() {
        ++mResourceCnt;
        notify();
    }

    /**
     * Releases a resource and increments the resource count and notifies
     * waiting threads.  Dijkstra terminology, Dutch "Verhogen", to increment.
     */
    public void V() {
        up();
    }

    /**
     * If no resources are available wait, otherwise decrement the resource
     * count and proceed.
     */
    public synchronized void down() {
        while (mResourceCnt == 0) {
            try {
                wait();
            } catch (InterruptedException ex) {
               ex.printStackTrace();
            }
        }

        mResourceCnt--;
    }

    /**
     * If no resources are available wait, otherwise decrement the resource
     * count and proceed.  Dijkstra terminology, Dutch "Proberen", to test.
     */
    public void P() {
        down();
    }
}
