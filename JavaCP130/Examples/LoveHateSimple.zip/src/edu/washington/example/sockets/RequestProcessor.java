package edu.washington.example.sockets;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.net.Socket;

/**
 * A simple request processor for the love/hate server.
 *
 * @author Russ Moul
 */
public final class RequestProcessor implements Runnable {
    /** The request socket. */
    private Socket mSocket;

    /**
     * Constructor.
     *
     * @param sock the request socket
     */
    public RequestProcessor(final Socket sock) {
        mSocket = sock;
    }

    /**
     * Processes request on the socket.
     */
    public void run() {
        InputStream inStrm = null;
        OutputStream outStrm = null;

        try {
            boolean more = true;
            inStrm = mSocket.getInputStream();

            InputStreamReader in = new InputStreamReader(inStrm);
            BufferedReader br = new BufferedReader(in);
            outStrm = mSocket.getOutputStream();

            PrintWriter wrtr = new PrintWriter(outStrm, true);

            while (more) {
                String command = br.readLine();

                if (command.equals("loveme")) {
                    wrtr.println("I love you!");
                } else if (command.equals("hateme")) {
                    wrtr.println("I don't hate you!");
                } else if (command.equals("why")) {
                    wrtr.println("Because you are the way you are.");
                } else if (command.equals("quit")) {
                    wrtr.println("Bye.");
                    more = false;
                }
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            try {
                if (inStrm != null) {
                    inStrm.close();
                }

                if (outStrm != null) {
                    outStrm.close();
                }

                if (mSocket != null) {
                    mSocket.close();
                }
            } catch (IOException ioex) {
                ioex.printStackTrace();
            }
        }
    }
}
