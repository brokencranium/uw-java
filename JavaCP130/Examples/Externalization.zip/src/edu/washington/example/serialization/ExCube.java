package edu.washington.example.serialization;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * An externalizable cube.
 *
 * @author Russ Moul
 */
public final class ExCube implements java.io.Externalizable {
    /** The surface area. */
    private transient double mSurfaceArea;

    /** The volume area. */
    private transient double mVolume;

    /** The height. */
    private double mHeight;

    /** The width. */
    private double mWidth;

    /** The depth. */
    private double mDepth;

    /**
     * Default, no argument, constructor.
     */
    public ExCube() {
    }

    /**
     * Constructor.
     *
     * @param width the cube's width
     * @param height the cube's height
     * @param depth the cube's height
     */
    public ExCube(final double width, final double height, final double depth) {
        this.mHeight = mHeight;
        this.mWidth = mWidth;
        this.mDepth = mDepth;
        init();
    }

    /**
     * Set the serface area and volume.
     */
    private void init() {
        mSurfaceArea = ((mWidth * mHeight)
                     + (mWidth * mDepth)
                     + (mHeight * mDepth)) * 2;
        mVolume = mWidth * mHeight * mDepth;
    }

    /**
     * Writes the object to stream.
     *
     * @param out the stream to write the object to
     *
     * @throws IOException if any I/O exceptions occur
     */
    public void writeExternal(final ObjectOutput out) throws IOException {
        out.writeDouble(mWidth);
        out.writeDouble(mHeight);
        out.writeDouble(mDepth);
    }

    /**
     * Reads the object from stream, and initializes the transient fields.
     *
     * @param in the stream to read the object from
     *
     * @throws IOException if any I/O exceptions occur
     */
    public void readExternal(final ObjectInput in)
        throws IOException {
        mWidth = in.readDouble();
        mHeight = in.readDouble();
        mDepth = in.readDouble();
        init();
    }

    /**
     * Compares two ExCubes, two cubes are considered equal if they have the
     * same width, height and depth.  The during comparision the properties in
     * have the following order of significance width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object
     *
     * @throws ClassCastException  if the specified object is not an ExCube
     */
    public int compareTo(final Object o) throws ClassCastException {
        ExCube otherCube = (ExCube)o;
        double diff = mWidth - otherCube.mWidth;
        if (diff == 0) {
            diff = mHeight - otherCube.mHeight;
        }
        if (diff == 0) {
            diff = mDepth - otherCube.mDepth;
        }
        return (diff < 0) ? -1 : (diff > 0) ? 1 : 0;
    }

    /** Hash code seed. */
    private static final int HASH_SEED = 17;

    /** Hash multiplier. */
    private static final int HASH_MULTIPLIER = 37;

    /** Size of int, half size of long. */
    private static final int BITS_32 = 32;

    /**
     * Returns a hash code value for the object.
     *
     * @return a hash code value for this object
     */
    public int hashCode() {
        int hc = HASH_SEED;
        long v;
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        v = Double.doubleToLongBits(mWidth);
        hc = HASH_MULTIPLIER * hc + (int)(v ^ (v >>> BITS_32));
        return hc;
    }

    /**
     * Compares two ExCubes, two cubes are considered equal if they have the
     * same width, height and depth.
     *
     * @param o the Object to be compared
     *
     * @return true if and only if the width, height and depth are equal.
     */
    public boolean equals(final Object o) {
        boolean eq = false;
        if (o != null && o instanceof ExCube) {
            eq = compareTo(o) == 0;
        }
        return eq;
    }

    /**
     * Returns a string represnetaion of the ExCube object.
     *
     * @return a String representation of this object
     */
    public String toString() {
        return ("Height: " + mHeight + "\nWidth:  " + mWidth
              + "\nDepth:  " + mDepth + "\nArea:   " + mSurfaceArea
              + "\nVolume: " + mVolume);
    }

}
