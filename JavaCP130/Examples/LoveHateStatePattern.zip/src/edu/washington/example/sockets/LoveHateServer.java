package edu.washington.example.sockets;

import java.io.IOException;

import java.net.ServerSocket;
import java.net.Socket;

/**
 * Simple implementation of the love/hate server.
 *
 * @author Russ Moul
 */
public final class LoveHateServer implements Runnable {
    /** The connection listening port. */
    private int mPort;

    /**
     * Constructor.
     *
     * @param port the connection listening port
     */
    public LoveHateServer(final int port) {
        mPort = port;
    }

    /**
     * Listens for connections and hand tehm off for processing.
     */
    public void run() {
        ServerSocket servSock = null;

        try {
            servSock = new ServerSocket(mPort);
            System.out.println("Server ready...");

            while (true) {
                Socket sock = servSock.accept(); // blocks
                RequestProcessor req = new RequestProcessor(sock);
                Thread t = new Thread(req);
                t.start();
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            if (servSock != null) {
                try {
                    servSock.close();
                } catch (IOException ioex) {
                    ioex.printStackTrace();
                }
            }
        }
    }

    /**
     * Runs the class.
     *
     * @param args input arguments args[0] = port
     */
    public static void main(final String[] args) {
        int port;

        if (args.length == 1) {
            port = Integer.parseInt(args[0]);

            LoveHateServer server = new LoveHateServer(port);
            Thread t = new Thread(server);
            t.start();
        } else {
            System.out.println("port required!");
        }
    }
}
