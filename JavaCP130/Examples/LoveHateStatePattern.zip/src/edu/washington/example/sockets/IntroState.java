package edu.washington.example.sockets;

import java.io.PrintWriter;

/**
 * Implementation of the RequestState interface for the initial state.  This is
 * to state of the conversation is initialized with.
 *
 * @author Russ Moul
 */
public final class IntroState implements RequestState {
    /**
     * The loveme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return the love me state
     */
    public RequestState loveme(final PrintWriter out) {
        out.println("I love you.");

        return new LoveMeState();
    }

    /**
     * The hateme request handler.
     *
     * @param out the writer to write the response to
     *
     * @return the hate me state
     */
     public RequestState hateme(final PrintWriter out) {
        out.println("I don't hate you.");

        return new HateMeState();
    }

    /**
     * The why request handler.
     *
     * @param out the writer to write the response to
     *
     * @return itself, this request does not change the state
     */
    public RequestState why(final PrintWriter out) {
        out.println("Why what?");

        return this;
    }

    /**
     * The quit request handler.
     *
     * @param out the writer to write the response to
     *
     * @return null, the conversation is over
     */
    public RequestState quit(final PrintWriter out) {
        out.println("Bye.");

        return null;
    }
}
