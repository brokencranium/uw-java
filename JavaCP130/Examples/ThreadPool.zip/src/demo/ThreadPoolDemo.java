package demo;

import java.util.Random;

import edu.washington.example.threads.ThreadPool;

/**
 * Simple demonstration using the thread pool.
 */
public final class ThreadPoolDemo {
    /**
     * Create a pool of 10 threads and use these to perform 100 pieces of work.
     */
    public void test() {
        ThreadPool pool = new ThreadPool(10, true);

        for (int i = 0; i < 100; i++) {
            pool.work(new ExampleWorker());
        }
    }

    /**
     * Run the test.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        ThreadPoolDemo demo = new ThreadPoolDemo();
        demo.test();
    }

    /**
     * Runnable defining a piece of work.  Prints the name of the thread and
     * sleeps for upto 2 seconds.
     */
    final class ExampleWorker implements Runnable {
        public void run() {
            try {
                Random rand = new Random();
                int delay = rand.nextInt(2000);
                System.out.println(Thread.currentThread().getName() +
                    " sleeping for " + delay + " milliseconds");
                Thread.currentThread().sleep(delay);
            } catch (Exception ex) {
            }
        }
    }
}
