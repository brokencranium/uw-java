package edu.washington.example.threads;

/**
 * Interface for objects which may be pooled.  While any object may be placed in
 * an object pool PooledObjects have awareness of their pool, allowing them to
 * be returned to the pool without knowledge of the pool itself.
 */
public interface PooledObject {
    /**
     * Sets the pool this object is a member of.
     *
     * @param pool the object pool this object is to be a member of
     */
    void setPool(ObjectPool pool);

    /**
     * Retuns this object to its pool
     */
    void returnToPool();
}
