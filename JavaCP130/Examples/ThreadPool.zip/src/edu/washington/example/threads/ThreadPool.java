package edu.washington.example.threads;

/**
 * A speialized pool class for Threads.
 *
 * @author Russ Moul
 */
public final class ThreadPool extends ObjectPool {
    /**
     * Construct the pool with the specified number of threads.
     *
     * @param size the initial size of the pool
     * @param daemon are the pooled threads to be daemon threads
     */
    public ThreadPool(final int size, final boolean daemon) {
        for (int i = 0; i < size; i++) {
            PooledThread pt = new PooledThread();
            pt.setDaemon(daemon);
            pt.setPool(this);
            pt.start();
            push(pt);
        }
    }

    /**
     * Causes the task defined by the provided Runnable's run method to be
     * executed by the next available work thread.
     *
     * @param rbl the runnable that performs the work
     */
    public void work(final Runnable rbl) {
        PooledThread th = (PooledThread) pull();
        th.work(rbl);
    }

    /**
     * Work thread, a PooledObject capable of placing itself back in the pool
     * when its work is complete.
     */
    final class PooledThread extends Thread implements PooledObject {
        /** The pool. */
        private ObjectPool mPool;

        /** Work to be performed. */
        private Runnable mWork;

        /**
         * Sets the pool this object is a member of.
         *
         * @param pool the object pool this object is to be a member of
         */
        public void setPool(final ObjectPool pool) {
            mPool = pool;
        }

        /**
         * Starts the thread working on a task.
         *
         * @param work the Runnable defining the task to execute
         */
        public synchronized void work(final Runnable work) {
            mWork = work;
            notify();
        }

        /**
         * Performs a unit of work and then places itself back in the pool.
         */
        public void run() {
            while (true) {
                synchronized (this) {
                    while (mWork == null) {
                        try {
                            wait();
                        } catch (InterruptedException ie) {
                            ie.printStackTrace();
                        }
                    }
                }

                mWork.run();

                if (mWork instanceof PooledObject) {
                    ((PooledObject) mWork).returnToPool();
                }

                mWork = null;
                returnToPool();
            }
        }

        /**
         * Returns this object to its pool
         */
        public void returnToPool() {
            if (mPool != null) {
                mPool.push(this);
            }
        }
    }
}
