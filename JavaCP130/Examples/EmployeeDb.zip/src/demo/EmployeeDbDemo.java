package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


/**
 * An example of JDBC usage, most aspects of JBDC are illustrated in this
 * example.
 *
 * @author Russ Moul
 */
public final class EmployeeDbDemo {
    /** Index to the calculated sum colum. */
    private static final int SUM_COLUMN_NDX = 1;

    /** Index to the calculated average colum. */
    private static final int AVG_COLUMN_NDX = 2;

    /** Index to the calculated max colum. */
    private static final int MAX_COLUMN_NDX = 3;

    /** Index to the calculated min colum. */
    private static final int MIN_COLUMN_NDX = 4;

    /**
     * Prevent instantiation.
     */
    private EmployeeDbDemo() {
    }

    /**
     * Illustrate JDBC usage.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        Connection conn = null;
        String dbUrl = "jdbc:hsqldb:EmployeeDB";
        String driverClassName = "org.hsqldb.jdbcDriver";
        String username = "sa";
        String password = "";

        try {
            Class.forName(driverClassName);
            conn = DriverManager.getConnection(dbUrl, username, password);

            Statement stmnt = conn.createStatement();
            ResultSet rs;

            // CREATE TABLE
            //*
            System.out.println("Creating employees table...");
            stmnt.executeUpdate("CREATE TABLE employee"
                + "( employee_id INTEGER IDENTITY," + "  employee_name VARCHAR,"
                + "  salary INTEGER NOT NULL," + "  photo LONGVARBINARY )");

            System.out.println("Creating dependent_type table...");
            stmnt.executeUpdate("CREATE TABLE dependent_type"
                + "( relationship VARCHAR PRIMARY KEY )");

            System.out.println("Creating dependent table...");
            stmnt.executeUpdate("CREATE TABLE dependent"
                + "( employee_id INTEGER NOT NULL,"
                + "  dependent_name VARCHAR NOT NULL,"
                + "  relationship VARCHAR NOT NULL,"
                + "  PRIMARY KEY(employee_id,dependent_name),"
                + "  FOREIGN KEY(employee_id) REFERENCES employee(employee_id),"
                + "  FOREIGN KEY(relationship) REFERENCES "
                +                             "dependent_type(relationship) )");

            stmnt.executeUpdate(
                "CREATE UNIQUE INDEX name_index ON employee(employee_name)");

            // INSERT
            System.out.println("Inserting Fred, Barney and Mr. Slate...");
            stmnt.executeUpdate("INSERT INTO employee (employee_name, salary) "
                              + "VALUES ('Fred Flintstone', 55000)");
            stmnt.executeUpdate("INSERT INTO employee (employee_name, salary) "
                              + "VALUES ('Barney Rubble', 45000 )");
            stmnt.executeUpdate("INSERT INTO employee (employee_name, salary) "
                              + "VALUES ('Mr. Slate', 90000)");
            stmnt.executeUpdate("INSERT INTO employee (employee_name, salary) "
                              + "VALUES ('Joe Rockhead', 25000)");

            System.out.println("Inserting dependent types...");
            stmnt.executeUpdate("INSERT INTO dependent_type "
                              + "VALUES ('SPOUSE')");
            stmnt.executeUpdate("INSERT INTO dependent_type "
                              + "VALUES ('CHILD')");

            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                  + "  FROM employee"
                                  + " ORDER BY employee_name");
            stmnt.executeUpdate("INSERT INTO dependent "
                             +  "(employee_id, dependent_name, relationship) "
                              + "VALUES ( 0, 'Wilma Flintston', 'SPOUSE' )");
            stmnt.executeUpdate("INSERT INTO dependent "
                              + "(employee_id, dependent_name, relationship) "
                              + "VALUES ( 0, 'Pebbles Flintston', 'CHILD' )");
            stmnt.executeUpdate("INSERT INTO dependent "
                              + "(employee_id, dependent_name, relationship) "
                              + "VALUES ( 1, 'Betty Rubble', 'SPOUSE' )");
            stmnt.executeUpdate("INSERT INTO dependent "
                              + "(employee_id, dependent_name, relationship) "
                              + "VALUES ( 1, 'Bambam Rubble', 'CHILD' )");

            // SELECT
            System.out.println("List all employees...");
            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                  + "  FROM employee"
                                  + " ORDER BY employee_name");

            while (rs.next()) {
                System.out.print(rs.getInt("salary") + "   ");
                System.out.println(rs.getString("employee_name"));
            }

            System.out.println();

            // SELECT JOIN
            System.out.println("List all employees and dependents...");
            rs = stmnt.executeQuery(
                           "SELECT employee_name, dependent_name"
                         + "  FROM employee, dependent"
                         + " WHERE employee.employee_id = dependent.employee_id"
                         + " ORDER BY employee_name, dependent_name");

            while (rs.next()) {
                System.out.print(rs.getString("employee_name") + "   ");
                System.out.println(rs.getString("dependent_name"));
            }

            System.out.println();

            // SELECT using FUNCTIONS
            System.out.println("List sum, avg, max and min salaries...");
            rs = stmnt.executeQuery("SELECT SUM(salary), AVG(salary),"
                                  + " MAX(salary), MIN(salary)"
                                  + "  FROM employee");

            while (rs.next()) {
                System.out.print(rs.getInt(SUM_COLUMN_NDX) + "   ");
                System.out.print(rs.getDouble(AVG_COLUMN_NDX) + "   ");
                System.out.print(rs.getInt(MAX_COLUMN_NDX) + "   ");
                System.out.println(rs.getInt(MIN_COLUMN_NDX));
            }

            System.out.println();

            // SELECT UNION
            System.out.println("List employees and dependents...");
            rs = stmnt.executeQuery("SELECT employee_name"
                                  + "  FROM employee"
                                  + " UNION "
                                  + "SELECT dependent_name"
                                  + "  FROM dependent"
                                  + " ORDER BY 1");

            while (rs.next()) {
                System.out.println(rs.getString(1));
            }

            System.out.println();

            // SELECT using Subquery
            System.out.println("List employees making more than Barney...");
            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                + "  FROM employee"
                                + " WHERE salary > "
                                + "(SELECT DISTINCT e.salary"
                                + "   FROM employee e"
                                + "  WHERE e.employee_name = 'Barney Rubble')");

            while (rs.next()) {
                System.out.print(rs.getInt("salary") + "   ");
                System.out.println(rs.getString("employee_name"));
            }

            System.out.println();

            // UPDATE
            System.out.println("Give Barney a raise to 51000...");
            stmnt.executeUpdate("UPDATE employee "
                              + "   SET salary = 51000"
                              + " WHERE employee_name = 'Barney Rubble'");

            // SELECT
            System.out.println("List employees having salaries > 50000...");
            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                  + "  FROM employee "
                                  + " WHERE salary > 50000"
                                  + " ORDER BY salary, employee_name");

            while (rs.next()) {
                System.out.print(rs.getInt("salary") + "   ");
                System.out.println(rs.getString("employee_name"));
            }

            System.out.println();

            // UPDATE
            System.out.println("Give Barney a raise to 52000...");
            stmnt.executeUpdate(
                            "UPDATE employee "
                          + "   SET salary = 52000"
                          + " WHERE employee_id = (SELECT DISTINCT employee_id"
                          + "  FROM employee e"
                          + " WHERE e.employee_name = 'Barney Rubble')");

            // SELECT
            System.out.println("List employees having salaries > 50000...");
            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                  + "  FROM employee "
                                  + " WHERE salary > 50000"
                                  + " ORDER BY salary, employee_name");

            while (rs.next()) {
                System.out.print(rs.getInt("salary") + "   ");
                System.out.println(rs.getString("employee_name"));
            }

            System.out.println();

            // DELETE
            System.out.println("Fire Fred (again!)...");

            // delete his dependents first
            stmnt.executeUpdate(
                           "DELETE FROM dependent "
                         + " WHERE employee_id = (SELECT DISTINCT employee_id"
                         + "  FROM employee e"
                         + " WHERE e.employee_name = 'Fred Flintstone')");
            stmnt.executeUpdate("DELETE FROM employee "
                              + " WHERE employee_name = 'Fred Flintstone'");

            // SELECT
            System.out.println("List all employees...");
            rs = stmnt.executeQuery("SELECT employee_name, salary"
                                  + "  FROM employee"
                                  + " ORDER BY employee_name");

            while (rs.next()) {
                System.out.print(rs.getInt("salary") + "   ");
                System.out.println(rs.getString("employee_name"));
            }

            System.out.println();

            // DROP TABLE
            System.out.println("Dropping tables...");
            stmnt.executeUpdate("DROP TABLE dependent");
            stmnt.executeUpdate("DROP TABLE dependent_type");
            stmnt.executeUpdate("DROP TABLE employee");
        } catch (Exception ex) {
            System.out.println(ex);
        }

        System.exit(0);
    }
}
