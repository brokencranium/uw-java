package edu.washington.example.junit;


/**
 * A simple roman mumeral class constructed for the purpose of demonstrating
 * the use of JUnit tests.
 *
 * @author Russ Moul
 */
public final class RomanNumeral {
     /** Value of roman M. */
    private static final int M_VALUE = 1000;

     /** Value of roman CM. */
    private static final int CM_VALUE = 900;

     /** Value of roman D. */
    private static final int D_VALUE = 500;


     /** Value of roman CD. */
    private static final int CD_VALUE = 400;


     /** Value of roman C. */
    private static final int C_VALUE = 100;


     /** Value of roman XC. */
    private static final int XC_VALUE = 90;


     /** Value of roman L. */
    private static final int L_VALUE = 50;


     /** Value of roman XL. */
    private static final int XL_VALUE = 40;

     /** Value of roman X. */
    private static final int X_VALUE = 10;

     /** Value of roman IX. */
    private static final int IX_VALUE = 9;

     /** Value of roman V. */
    private static final int V_VALUE = 5;

     /** Value of roman IV. */
    private static final int IV_VALUE = 4;

     /** Value of roman I. */
    private static final int I_VALUE = 1;

    /** Map of important roman numeral equivalents. */
    private static RomanEquiv[] romanMap = {
        new RomanEquiv(M_VALUE,  "M"),
        new RomanEquiv(CM_VALUE, "CM"),
        new RomanEquiv(D_VALUE,  "D"),
        new RomanEquiv(CD_VALUE, "CD"),
        new RomanEquiv(C_VALUE,  "C"),
        new RomanEquiv(XC_VALUE, "XC"),
        new RomanEquiv(L_VALUE,  "L"),
        new RomanEquiv(XL_VALUE, "XL"),
        new RomanEquiv(X_VALUE,  "X"),
        new RomanEquiv(IX_VALUE, "IX"),
        new RomanEquiv(V_VALUE,  "V"),
        new RomanEquiv(IV_VALUE, "IV"),
        new RomanEquiv(I_VALUE,  "I")
    };

    /** Value of this roman numeral object. */
    private int mValue;

    /** Roman numeral representation. */
    private String mStringRep;

    /**
     * Constructor.
     *
     * @param v integer value of the roman numeral to be created
     */
    public RomanNumeral(final int v) {
        mValue = v;
    }

    /**
     * Constructor.
     *
     * @param s roman numeral string representation of the roman numeral to be
     *          created
     */
    public RomanNumeral(final String s) {
        mValue = parseInt(s);
        mStringRep = s;
    }

    /**
     * Gets the integer value of this object.
     *
     * @return the integer value
     */
    public int getValue() {
        return mValue;
    }

    /**
     * Sets the integer value of this object.
     *
     * @param v the value to be assigned to this object
     */
    public void setValue(final int v) {
        mValue = v;
        mStringRep = null;
    }

    /**
     * Sets the value of this object.
     *
     * @param s the roman numeral representation of the value to be assigned to
     *          this object
     */
    public void setValue(final String s) {
        mValue = parseInt(s);
        mStringRep = s;
    }

    /**
     * Gets the roman numeral representation of this objects value.
     *
     * @return the roman numeral representation of this objects value
     */
    public String toString() {
        if (mStringRep == null) {
            mStringRep = toRoman(mValue);
        }

        return mStringRep;
    }

    /**
     * Compares this objects value to the value of the object provided.  If two
     * objects have the same value they are deemed equal.
     *
     * @param obj the object to be compared to this object
     *
     * @return true if they have the same value
     */
    public boolean equals(final Object obj) {
        boolean equal = false;

        if (obj != null && obj instanceof RomanNumeral) {
            equal = mValue == ((RomanNumeral) obj).mValue;
        }

        return equal;
    }

    /**
     * Calculates this objects hash code.  Any two objects with the same value
     * will have the same hash code.
     *
     * @return this objects hash code
     */
    public int hashCode() {
        return mValue;
    }


    /**
     * Composes the roman numeral representation for the provided integer value.
     *
     * @param value the integer value to determine the roman numeral
     *              representaion of
     *
     * @return the roman numeral string
     */
    public static String toRoman(final int value) {
        int tmp = value;
        String s = "";

        for (int i = 0; i < romanMap.length; ++i) {
            RomanEquiv re = romanMap[i];

            while (tmp >= re.mValue) {
                tmp -= re.mValue;
                s += re.mRomanDigits;
            }
        }

        return s;
    }

    /**
     * Parses a roman numeral string to derive its integer value.
     *
     * @param s the roman numeral string
     *
     * @return the integer value of the roman numeral string
     */
    public static int parseInt(final String s) {
        String tmp = s;
        int x = 0;

        for (int i = 0; i < romanMap.length; ++i) {
            RomanEquiv re = romanMap[i];

            while (tmp.startsWith(re.mRomanDigits)) {
                x += re.mValue;
                tmp = tmp.substring(re.mRomanDigits.length());
            }
        }

        return x;
    }

    /**
     * Captures equivalent integer and roman numeral equivalents.
     */
    static class RomanEquiv {
        /** Integer value. */
        private int mValue;

        /** Roman numeral equivalent. */
        private String mRomanDigits;

        /**
         * Constructor.
         *
         * @param n the integer value
         * @param s the roman numeral representation
         */
        public RomanEquiv(final int n, final String s) {
            mValue = n;
            mRomanDigits = s;
        }
    }
}
