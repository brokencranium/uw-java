package demo;

import edu.washington.example.threads.Semaphore;

/**
 * A test program for the Semaphore class.
 *
 * @author Russ Moul
 */
public final class SemaphoreDemo {

    /**
     * Creates a single SequenceGenerator, 5 SingleConsumer objects, and 2
     * MultiConsumer objects and starts them running.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        int samplings = 100;
        SequenceGenerator gen = new SequenceGenerator();
        SingleConsumer sc1 = new SingleConsumer("SC1", gen, samplings);
        SingleConsumer sc2 = new SingleConsumer("SC2", gen, samplings);
        SingleConsumer sc3 = new SingleConsumer("SC3", gen, samplings);
        SingleConsumer sc4 = new SingleConsumer("SC4", gen, samplings);
        SingleConsumer sc5 = new SingleConsumer("SC5", gen, samplings);
        samplings = 50;
        MultiConsumer mc1 = new MultiConsumer("MC1", gen, samplings);
        MultiConsumer mc2 = new MultiConsumer("MC2", gen, samplings);
        Thread t1 = new Thread(sc1);
        Thread t2 = new Thread(sc2);
        Thread t3 = new Thread(sc3);
        Thread t4 = new Thread(sc4);
        Thread t5 = new Thread(sc5);
        Thread t6 = new Thread(mc1);
        Thread t7 = new Thread(mc2);

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();

        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
            t5.join();
            t6.join();
            t7.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        System.out.println("Terminating!");
        System.exit(0);
    }
}


/**
 * Integer sequence generator for testing the Semaphore class.  This class'
 * thread safety is implemented using the Semaphore class as a mutex to limit
 * access to the generator.
 *
 * @Author Russ Moul
 */
final class SequenceGenerator {
    /** The next value in the squence. */
    private int mNextValueInSequence = 1;

    /** Controlling semaphore. */
    private Semaphore mSemaphore;

    /**
     * Creates the generator, initializing the value to 1.
     */
    public SequenceGenerator() {
        mSemaphore = new Semaphore(Semaphore.MUTEX);
    }

    /**
     * Gets the next integer from the sequence generator.
     *
     * @return the next value in the sequence.
     */
    public int next() {
        mSemaphore.down();

        int v = mNextValueInSequence++;
        mSemaphore.up();

        return v;
    }

    /**
     * Gets the next cnt integers from the sequence generator.
     *
     * @return the next cnt values in the sequence.
     */
    public int[] next(int cnt) {
        int[] v = new int[cnt];
        mSemaphore.down();

        for (int i = 0; i < v.length; i++)
            v[i] = mNextValueInSequence++;

        mSemaphore.up();

        return v;
    }
}


/**
 * Integer consumer for testing the Semaphore class.  This consumer consumes
 * 1 integer at a time.
 *
 * @Author Russ Moul
 */
final class SingleConsumer implements Runnable {
    /** The sequesnce generator. */
    private SequenceGenerator mGenerator;

    /** This consumers name. */
    private String mName;

    /** The number of values to read. */
    private int mSampleSize;

    /**
     * Creates a consumer giving it a name and providing a generator to get
     * values from.
     *
     * @param name identifying name for this consumer
     * @param gen integer generator to provide values to this consumer
     * @param sampleSize number of values to consume
     */
    public SingleConsumer(final String name, final SequenceGenerator gen,
                          final int sampleSize) {
        mName = name;
        mGenerator = gen;
        mSampleSize = sampleSize;
    }

    /**
     * Consumes a single integer and prints it.
     */
    public void run() {
        for (int i = 0; i < mSampleSize; i++) {
            System.out.println(mName + ": " + mGenerator.next());

            // cause an artificial delay
            int delay = (int) (Math.random() * 100.0);

            if ((delay % 2) == 0) {
                try {
                    Thread.currentThread().sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}


/**
 * Integer consumer for testing the Semaphore class.  This consumer consumes
 * 999999 integers at a time, and verifies there are no gaps in the series.
 *
 * @Author Russ Moul
 */
final class MultiConsumer implements Runnable {
    /** THe size of the sample to be tested. */
    private static int SIZE = 999999;

    /** The sequesnce generator. */
    private SequenceGenerator mGenerator;

    /** This consumers name. */
    private String mName;

    /** The number of values to read. */
    private int mSampleSize;

    /**
     * Creates a consumer giving it a name and providing a generator to get
     * values from.
     *
     * @param name identifying name for this consumer
     * @param gen integer generator to provide values to this consumer
     * @param sampleSize number of values to consume
     */
    public MultiConsumer(final String name, final SequenceGenerator gen,
                         final int sampleSize) {
        mName = name;
        mGenerator = gen;
        mSampleSize = sampleSize;
    }

    /**
     * Consumes a single integer and prints it.
     */
    public void run() {
        for (int i = 0; i < mSampleSize; i++) {
            int[] x = mGenerator.next(SIZE + 1);

            if ((x[SIZE] - x[0]) != SIZE) // are there any gaps?
             {
                System.out.println("Error");
                System.exit(0);
            } else {
                System.out.println(mName + ": " + x[0] + " - " + x[SIZE]);
            }

            // cause an artificial delay
            int delay = (int) (Math.random() * 100.0);

            if ((delay % 2) == 0) {
                try {
                    Thread.currentThread().sleep(delay);
                } catch (InterruptedException ex) {
                }
            }
        }
    }
}
