package edu.washington.example.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;


/**
 * Defines an interface for a source of unique integer keys.
 *
 * @author Russ Moul
 */
public interface SeqKey extends Remote {
    /**
     * Gets the next key in the sequence.
     *
     * @return the key
     *
     * @throws RemoteException if the remote invocation fails
     */
    long getKey() throws RemoteException;

    /**
     * Gets the next count keys in the sequence.
     *
     * @param count the number of keys to be provided
     *
     * @return an array of consecutive keys
     *
     * @throws RemoteException if the remote invocation fails
     */
    long[] getKey(int count) throws RemoteException;
}
