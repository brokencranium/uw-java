package edu.washington.example.rmi;

import java.rmi.Naming;
import java.rmi.Remote;


/**
 * Client application with the purpose of exercising a server implementing
 * the SeqKey interface.
 *
 * @author Russ Moul
 */
public final class SeqKeyClient {
    /** The number of individual keys to be requested. */
    private static final int INDIVIDUAL_KEY_QTY = 10;

    /** The number of sequential keys to be requested. */
    private static final int SEQUENTIAL_KEY_QTY = 5;

    /**
     * Prevents instantiation.
     */
    private SeqKeyClient() {
    }

    /**
     * Test client.
     *
     * @param args args[0] = registry host
     */
    public static void main(final String[] args) {
        long[] keys;

        try {
            // bind to the server
            Remote remoteObj = Naming.lookup("rmi://" + args[0] + "/KeyServer");
            SeqKey server = (SeqKey) remoteObj;

            // get 10 individual keys
            for (int i = 0; i < INDIVIDUAL_KEY_QTY; i++) {
                System.out.println("Key = " + server.getKey());

                //Thread.currentThread().sleep( 1000 );
            }

            // get the next 5 keys
            keys = server.getKey(SEQUENTIAL_KEY_QTY);

            for (int i = 0; i < keys.length; i++) {
                System.out.println("Keys[" + i + "] = " + keys[i]);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
}
