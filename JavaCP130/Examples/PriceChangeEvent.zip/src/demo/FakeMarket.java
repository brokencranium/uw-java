package demo;

import java.util.Random;

import javax.swing.event.EventListenerList;

import edu.washington.example.reflection.PriceChangeEvent;
import edu.washington.example.reflection.PriceChangeListener;
import edu.washington.example.reflection.Stock;

/**
 * A simulated market.
 *
 * @author Russ Moul
 */
public final class FakeMarket extends Thread {
    /** Initial price for IBM. */
    private static final int INIT_IBM_PRICE = 10000;

    /** Initial price for BA. */
    private static final int INIT_BA_PRICE = 4000;

    /** Initial price for MSFT. */
    private static final int INIT_MSFT_PRICE = 6000;

    /** Half second. */
    private static final int HALF_SECOND = 500;

    /** Tenth of a second. */
    private static final int TENTH_SECOND = 100;

    /** Tenth of a second. */
    private static final int PERCENT = 100;

    /** Indicates if prices are adjusting or not. */
    private boolean mAdjusting = true;

    /** The stocks in the market. */
    private Stock[] mStocks = {new Stock("IBM", INIT_IBM_PRICE),
                               new Stock("BA", INIT_BA_PRICE),
                               new Stock("MSFT", INIT_MSFT_PRICE)};

    /** The markets listeners. */
    private EventListenerList mListenerList = new EventListenerList();

    /**
     * Constructs the market and starts adjusting prices.
     */
    public FakeMarket() {
        start();
    }

    /**
     * Performs the price adjustments.
     */
    public void run() {
        Random rand = new Random();

        while (mAdjusting) {
            try {
                // get random delay, within range
                int interval = TENTH_SECOND
                             + (int) (rand.nextDouble() * HALF_SECOND);

                // get random ticker
                int ndx = rand.nextInt(mStocks.length);

                // get random adjustment <= 1%
                int price = mStocks[ndx].getPrice();
                int adjustment = rand.nextInt() % (price / PERCENT);
                price += adjustment;
                mStocks[ndx].setPrice(price);
                firePriceChangeEvent(new PriceChangeEvent(this,
                        mStocks[ndx].getTicker(), price));
                sleep(interval);
            } catch (InterruptedException iex) {
                System.out.println("Adjusting thread interrupted.");
            }
        }
    }

    /**
     * Stop the price adjustment.
     */
    public void close() {
        mAdjusting = false;
    }

    /**
     * Adds a price change listener.
     *
     * @param l the listener to add
     */
    public synchronized void addPriceChangeListener(
                                           final PriceChangeListener l) {
        mListenerList.add(PriceChangeListener.class, l);
    }

    /**
     * Removes a price change listener.
     *
     * @param l the listener to remove
     */
    public synchronized void removePriceChangeListener(
                                              final PriceChangeListener l) {
        mListenerList.remove(PriceChangeListener.class, l);
    }

    /**
     * Fires a price changed event.
     *
     * @param evnt the event to be fired
     */
    protected void firePriceChangeEvent(final PriceChangeEvent evnt) {
        Object[] listeners = mListenerList.getListenerList();

        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == PriceChangeListener.class) {
                ((PriceChangeListener) listeners[i + 1]).priceChanged(evnt);
            }
        }
    }
}
