package edu.washington.example.io;

/**
 * Enables simple console input.  Methods are provided to read values for the
 * primative types from the console.  Each method returns a default value in the
 * event any exceptions occur.
 *
 * @author Russ Moul
 */
public final class ConsoleIn {
    /** Data reader used to read the console. */
    private static DataInputReader dir = new DataInputReader(System.in);

    /**
     * Prevent instantiation.
     */
    private ConsoleIn() {
    }

    /**
     * Reads a boolean value from the console.  The case insensitive string
     * "true" is interpreted as true all other values are false.
     *
     * @return the boolean value represented by the input string, false is
     *         returned in the event of an exception.
     */
    public static boolean readBoolean() {
        boolean value = false;

        try {
            value = dir.readBoolean();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a byte value from the console.
     *
     * @return the byte value represented by the input string, 0 is
     *         returned in the event of an exception.
     */
    public static byte readByte() {
        byte value = 0;

        try {
            value = dir.readByte();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a short value from the console.
     *
     * @return the short value represented by the input string, 0 is
     *         returned in the event of an exception.
     */
    public static short readShort() {
        short value = 0;

        try {
            value = dir.readShort();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads an int value from the console.
     *
     * @return the int value represented by the input string, 0 is
     *         returned in the event of an exception.
     */
    public static int readInt() {
        int value = 0;

        try {
            value = dir.readInt();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a long value from the console.
     *
     * @return the long value represented by the input string, 0L is
     *         returned in the event of an exception.
     */
    public static long readLong() {
        long value = 0;

        try {
            value = dir.readLong();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a float value from the console.
     *
     * @return the float value represented by the input string, 0.0F is
     *         returned in the event of an exception.
     */
    public static float readFloat() {
        float value = 0.0F;

        try {
            value = dir.readFloat();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a double value from the console.
     *
     * @return the double value represented by the input string, 0.0 is
     *         returned in the event of an exception.
     */
    public static double readDouble() {
        double value = 0.0;

        try {
            value = dir.readDouble();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a char value from the console.
     *
     * @return the first char of the input string, 0 is
     *         returned in the event of an exception.
     */
    public static char readChar() {
        char value = 0;

        try {
            value = dir.readChar();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Reads a String from the console.
     *
     * @return the the input string, an empty string is
     *         returned in the event of an exception.
     */
    public static String readString() {
        String value = "";

        try {
            value = dir.readLine();
        } catch (Exception ex) {
            handleException(ex);
        }

        return value;
    }

    /**
     * Handle exceptions in a uniform way - do nothing for now.
     *
     * @param ex the exception to process
     */
     private static void handleException(final Exception ex) {
     }
}
