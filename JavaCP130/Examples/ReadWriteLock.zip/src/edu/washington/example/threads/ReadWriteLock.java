package edu.washington.example.threads;

/**
 * An implementation of a read/write lock.  Allows any number of threads to
 * read simultaniously but provides exclusive access to threads performing write
 * access.  The lock prevents read and write starvation.
 *
 * @author Russ Moul
 */
public final class ReadWriteLock {
    /** The number of waiting reads. */
    private int mReadQueDepth = 0;

    /** Has the write lock been acquired. */
    private boolean mWriting = false;

    /** The number of waiting writes. */
    private int mWriteQueDepth = 0; // used to prevent write starvation

    /** Do read requests have priority. */
    private boolean mReadPriority = false; // used to prevent read starvation

    /**
     * Aquires a read lock so the controlled resource may be safely read from.
     * Obtains lock unless there is currently a thead writing or there are
     * waiting write threads and read priority has not been explicitly set.
     */
    public synchronized void acquireRead() {
        while (mWriting || ((mWriteQueDepth > 0) && !mReadPriority)) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        mReadQueDepth++;
    }

    /**
     * Releases an aquired read lock.  Explicitly turns off read priority.
     */
    public synchronized void releaseRead() {
        mReadQueDepth--;
        mReadPriority = false;

        if (mReadQueDepth == 0) {
            notifyAll();
        }
    }

    /**
     * Aquires a write lock so the controlled resource may be safely written to.
     * Obtains lock unless there is currently a thead writing or the read queue
     * depth exceeds 0.
     */
    public synchronized void acquireWrite() {
        while ((mReadQueDepth > 0) || mWriting) {
            mWriteQueDepth++;

            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            mWriteQueDepth--;
        }

        mWriting = true;
    }

    /**
     * Releases an aquired write lock.  Explicitly turns on the read priority.
     */
    public synchronized void releaseWrite() {
        mWriting = false;
        mReadPriority = true;
        notifyAll();
    }
}
