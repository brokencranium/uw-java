package demo;

import java.util.Date;

import edu.washington.example.jdbc.DbLog;

/**
 * Demonstrate the use of the database logging.
 *
 * @author Russ Moul
 */
public final class DbLogDemo {
    /**
     * Prevent instantiation.
     */
    private DbLogDemo() {
    }

    /**
     * Demonstrate the DbLog class.
     *
     * @param args arg[0], the message to be logged in place of the default
     *             message
     *
     * @throws Exception if any exceptions occur - let the VM deal with them
     */
    public static void main(final String[] args)
        throws Exception {
        DbLog log = new DbLog("jdbc:hsqldb:EventLogDB", "org.hsqldb.jdbcDriver",
                              "sa", "");
        Date dt = new Date();
        String msg;

        if (args.length > 0) {
            msg = args[0] + " (posted " + dt + ")";
        } else {
            msg = "Simple test message (posted " + dt + ")";
        }

        System.out.println("Message: " + msg);
        log.logMessage(msg);
        log.dump();
        System.exit(0);
    }
}
