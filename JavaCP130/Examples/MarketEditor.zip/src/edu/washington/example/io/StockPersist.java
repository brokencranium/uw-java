package edu.washington.example.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Reads and writes stock records from/to a record based binary file.  Each
 * record consists of four bytes for the ticker (each holding a character of
 * the symbol) followed by a four byte integer.  Tickers consisting of fewer
 * than four characters are padded with spaces, which are stripped when the
 * ticker is read.
 */
public final class StockPersist {
    /** The stock record file. */
    private RandomAccessFile mRandomFile;

    /**
     * Constructor.
     *
     * @param fileName the name of the stock record file
     *
     * @throws FileNotFoundException if the file does not exist
     */
    public StockPersist(final String fileName) throws FileNotFoundException {
        mRandomFile = new RandomAccessFile(fileName, "rw");
    }

    /**
     * Constructor.
     *
     * @param file the stock record file
     *
     * @throws FileNotFoundException if the file does not exist
     */
    public StockPersist(final File file) throws FileNotFoundException {
        mRandomFile = new RandomAccessFile(file, "rw");
    }

    /**
     * Write the a stock to the file as a record.
     *
     * @param stock the stock to write
     *
     * @throws IOException if an error occurs while writing to file
     */
    public void writeStock(final Stock stock) throws IOException {
        byte[] tickerChars = {' ', ' ', ' ', ' '};
        String ticker = stock.getTicker();
        int len = ticker.length();

        for (int i = 0; i < len; i++) {
            tickerChars[i] = (byte) ticker.charAt(i);
        }

        mRandomFile.write(tickerChars);
        mRandomFile.writeInt(stock.getPrice());
    }

    /**
     * Reads the next stock record from the file and constructs a Stock object.
     *
     * @return the stock constructed from the read record, or null if the read
     *         fails or EOF is reached
     */
    public Stock readStock() {
        Stock stock;

        try {
            byte[] tickerChars = {' ', ' ', ' ', ' '};
            mRandomFile.read(tickerChars);

            String ticker = new String(tickerChars);
            int price = mRandomFile.readInt();
            stock = new Stock(ticker, price);
        } catch (IOException ex) {
            stock = null;
        }

        return stock;
    }

    /**
     * Close the stock record file.
     */
    public void close() {
        try {
            mRandomFile.close();
        } catch (IOException ex) {
           System.err.println("Error closing stock file.");
        }
    }
}
