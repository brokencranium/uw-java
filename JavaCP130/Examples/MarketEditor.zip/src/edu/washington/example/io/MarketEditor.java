package edu.washington.example.io;

import java.awt.Event;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.File;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;


/**
 * A graphical editor for editing the contents of a binary stock file.
 *
 * @author Russ Moul
 */
public final class MarketEditor {
    /** Initial/default size of the Vector */
    private static final int DEFAULT_VECTOR_SIZE = 10;

    /** The vector increment size. */
    private static final int DEFAULT_VECTOR_INCREMENT = 10;

    /** The grid bag internal x padding. */
    private static final int INTERNAL_X_PAD = 8;

    /** The editor panel. */
    private MarketEditorPanel mEditor;

    /** The save menu. */
    private JMenuItem mSaveMenu;

    /** The save as menu. */
    private JMenuItem mSaveAsMenu;

    /** The frame. */
    private JFrame mFrame;

    /** The current/last working directory. */
    private File mCurDir = new File(System.getProperty("user.dir"));

    /** The current stock file. */
    private File mCurFile;

    /**
     * Constructor.
     */
    public MarketEditor() {
        mFrame = new JFrame("Market Editor (untitled)");

        // create menus
        JMenu fileMenu = new JMenu("File");

        JMenuItem newMenu = new JMenuItem("New", 'N');
        KeyStroke newKey = KeyStroke.getKeyStroke('N', Event.ALT_MASK);
        newMenu.setAccelerator(newKey);
        fileMenu.add(newMenu);

        JMenuItem openMenu = new JMenuItem("Open...", 'O');
        KeyStroke openKey = KeyStroke.getKeyStroke('O', Event.ALT_MASK);
        openMenu.setAccelerator(openKey);
        fileMenu.add(openMenu);

        fileMenu.addSeparator();

        mSaveMenu = new JMenuItem("Save...", 'S');

        KeyStroke saveKey = KeyStroke.getKeyStroke('S', Event.ALT_MASK);
        mSaveMenu.setAccelerator(saveKey);
        fileMenu.add(mSaveMenu);

        mSaveAsMenu = new JMenuItem("Save As...");
        fileMenu.add(mSaveAsMenu);

        fileMenu.addSeparator();

        JMenuItem quitMenu = new JMenuItem("Quit", 'Q');
        KeyStroke quitKey = KeyStroke.getKeyStroke('Q', Event.ALT_MASK);
        quitMenu.setAccelerator(quitKey);
        fileMenu.add(quitMenu);

        JMenuBar menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        mFrame.setJMenuBar(menuBar);

        mFrame.getContentPane().setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.ipadx = INTERNAL_X_PAD;
        gbc.ipady = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        mEditor = new MarketEditorPanel();
        mFrame.getContentPane().add(mEditor, gbc);
        mFrame.pack();

        //mFrame.setSize( 200, 300 );
        mFrame.setDefaultCloseOperation(mFrame.DO_NOTHING_ON_CLOSE);
        mFrame.addWindowListener(new WindowAdapter() {
                public void windowClosing(final WindowEvent e) {
                    if (verifyFileChange()) {
                        mFrame.dispose();
                        System.exit(0);
                    }
                }
            });

        newMenu.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent evnt) {
                    if (verifyFileChange()) {
                        openNew();
                        mCurFile = null;
                        mFrame.setTitle("Market Editor (untitled)");
                    }
                }
            });

        openMenu.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent evnt) {
                    if (verifyFileChange()) {
                        JFileChooser chooser = new JFileChooser();
                        chooser.setDialogType(JFileChooser.OPEN_DIALOG);
                        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                        chooser.setCurrentDirectory(mCurDir);

                        int status = chooser.showOpenDialog(mFrame);

                        if (status == JFileChooser.APPROVE_OPTION) {
                            mCurFile = chooser.getSelectedFile();
                            open(mCurFile);
                            mFrame.setTitle(
                                "Market Editor (" + mCurFile.getName() + ")");
                        }
                    }
                }
            });

        mSaveMenu.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent e) {
                    if (mCurFile == null) {
                        JFileChooser chooser = new JFileChooser();
                        chooser.setDialogType(JFileChooser.SAVE_DIALOG);
                        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                        chooser.setCurrentDirectory(mCurDir);

                        int status = chooser.showSaveDialog(mFrame);

                        if (status == JFileChooser.APPROVE_OPTION) {
                            mCurFile = chooser.getSelectedFile();
                        }
                    }

                    if (mCurFile != null) {
                        save(mCurFile);
                        mFrame.setTitle(
                            "Market Editor (" + mCurFile.getName() + ")");
                    }
                }
            });

        mSaveAsMenu.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent e) {
                    JFileChooser chooser = new JFileChooser();
                    chooser.setDialogType(JFileChooser.SAVE_DIALOG);
                    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    chooser.setCurrentDirectory(mCurDir);
                    chooser.setDialogTitle("Save As");

                    int status = chooser.showSaveDialog(mFrame);

                    if (status == JFileChooser.APPROVE_OPTION) {
                        mCurFile = chooser.getSelectedFile();
                        save(mCurFile);
                        mFrame.setTitle(
                            "Market Editor (" + mCurFile.getName() + ")");
                    }
                }
            });

        quitMenu.addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent evnt) {
                    if (verifyFileChange()) {
                        mFrame.dispose();
                        System.exit(0);
                    }
                }
            });

        // done - display the window
        mFrame.setVisible(true);
    }

    /**
     * Posts a dialog to verify the user wants to begin working on a differnt
     * file and offers an oppertunity to save the current file.
     *
     * @return true if the user elects to proceed with the new file
     */
    private boolean verifyFileChange() {
        boolean proceed = true;

        if (mEditor.isChanged()) {
            int option = JOptionPane.showConfirmDialog(mFrame,
                    "Changes have not been saved, save them now?",
                    "Save changes?", JOptionPane.YES_NO_CANCEL_OPTION);

            switch (option) {
                case JOptionPane.YES_OPTION:
                    if (mCurFile == null) {
                        JFileChooser chooser = new JFileChooser();
                        chooser.setDialogType(JFileChooser.SAVE_DIALOG);
                        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                        chooser.setCurrentDirectory(mCurDir);

                        int status = chooser.showSaveDialog(mFrame);

                        if (status == JFileChooser.APPROVE_OPTION) {
                            mCurFile = chooser.getSelectedFile();
                        }
                    }

                    try {
                        StockPersist persist = new StockPersist(mCurFile);
                        Enumeration enum = mEditor.getMarket();

                        while (enum.hasMoreElements()) {
                            persist.writeStock((Stock) enum.nextElement());
                        }

                        persist.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    break;

                case JOptionPane.NO_OPTION:
                    break;

                case JOptionPane.CANCEL_OPTION:
                    proceed = false;
                    break;

                default:
                    throw new RuntimeException("Invalid option selected.");
            }
        }

        return proceed;
    }

    /**
     * Creates a new set of stock records - an empty file.
     */
    private void openNew() {
        Vector stocks = new Vector(DEFAULT_VECTOR_SIZE,
                                   DEFAULT_VECTOR_INCREMENT);
        mEditor.setMarket(stocks);
        mEditor.setChanged(false);
    }

    /**
     * Opens an stock record file.
     *
     * @param f the file to open
     */
    private void open(final File f) {
        try {
            StockPersist persist = new StockPersist(f);
            Stock stock;
            Vector stocks = new Vector(DEFAULT_VECTOR_SIZE,
                                       DEFAULT_VECTOR_INCREMENT);

            while ((stock = persist.readStock()) != null) {
                stocks.addElement(stock);
            }

            persist.close();
            mEditor.setMarket(stocks);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Saves the stock record currently being processed to file.
     *
     * @param f the file to save the records to
     */
    private void save(final File f) {
        try {
            StockPersist persist = new StockPersist(f);
            Enumeration enum = mEditor.getMarket();

            while (enum.hasMoreElements()) {
                persist.writeStock((Stock) enum.nextElement());
            }

            persist.close();
            mEditor.setChanged(false);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Program entry point.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        MarketEditor win = new MarketEditor();
    }
}
