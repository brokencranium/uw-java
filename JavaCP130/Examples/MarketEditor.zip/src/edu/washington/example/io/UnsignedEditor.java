package edu.washington.example.io;

import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.Component;
import java.awt.Toolkit;
import java.text.NumberFormat;
import java.text.ParseException;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

/**
 * A cell editor for unsigned integer values.
 *
 * @author Russ Moul
 */
public final class UnsignedEditor extends DefaultCellEditor {

    /** Integer format used for validation. */
    private NumberFormat mUnsignedIntFormat;

    /**
     * Constructor.
     */
    public UnsignedEditor() {
        super(new JFormattedTextField());
        Integer zero = new Integer(0);

        //Set up the editor for the integer cells.
        mUnsignedIntFormat = NumberFormat.getIntegerInstance();
        mUnsignedIntFormat.setGroupingUsed(false);
        NumberFormatter intFormatter = new NumberFormatter(mUnsignedIntFormat);
        intFormatter.setMinimum(zero);

        final JFormattedTextField formattedFld;
        formattedFld = (JFormattedTextField)getComponent();
        formattedFld.setFormatterFactory(
                new DefaultFormatterFactory(intFormatter));
        formattedFld.setValue(zero);
        formattedFld.setHorizontalAlignment(JTextField.TRAILING);
        formattedFld.setFocusLostBehavior(JFormattedTextField.COMMIT);

        //React when the user presses Enter while the editor is active
        formattedFld.getInputMap().put(KeyStroke.getKeyStroke(
                                        KeyEvent.VK_ENTER, 0),
                                        "validate");
        formattedFld.getActionMap().put("validate", new AbstractAction() {
            public void actionPerformed(final ActionEvent e) {
                if (!formattedFld.isEditValid()) {
                    if (userSaysRevert()) {
                        formattedFld.postActionEvent();
                    }
                } else {
                    try {
                        formattedFld.commitEdit();
                        formattedFld.postActionEvent();
                    } catch (java.text.ParseException exc) {
                        exc.printStackTrace();
                    }
                }
            }
        });
    }

    /**
     * Sets an initial value for the editor. This will cause the editor to
     * stopEditing and lose any partially edited value if the editor is editing
     * when this method is called.
     *
     * @param table the JTable that is asking the editor to edit; can be null
     * @param value the value of the cell to be edited
     * @param isSelected true if the cell is to be rendered with highlighting
     * @param row the row of the cell being edited
     * @param column the column of the cell being edited
     *
     * @return the component for editing
     */
    public Component getTableCellEditorComponent(final JTable table,
            final Object value, final boolean isSelected,
            final int row, final int column) {
        JFormattedTextField ftf =
            (JFormattedTextField)super.getTableCellEditorComponent(
                table, value, isSelected, row, column);
        ftf.setValue(value);
        return ftf;
    }

    /**
     * Gets the value contained in the editor.
     *
     * @return the value contained in the editor
     */
    public Object getCellEditorValue() {
        JFormattedTextField ftf = (JFormattedTextField)getComponent();
        Object o = ftf.getValue();
        if (o instanceof Integer) {
            return o;
        } else if (o instanceof Number) {
            return new Integer(((Number)o).intValue());
        } else {
            try {
                return mUnsignedIntFormat.parseObject(o.toString());
            } catch (ParseException exc) {
                System.err.println(
                        "UnsignedEditor.getCellEditorValue: can't parse: " + o);
                return null;
            }
        }
    }

    /**
     * Check whether the edit is valid, setting the value if it is, otherwise
     * prompt the user to revert or continue editing.  If the valus is valid or
     * the user elects to revert invokes the superclass' method to clean things
     * up.
     *
     * @return true the value is valid, or reverted to the previous value
     *         otherwise false (the user elects to continue editing)
     */
    public boolean stopCellEditing() {
        JFormattedTextField ftf = (JFormattedTextField)getComponent();
        if (ftf.isEditValid()) {
            try {
                ftf.commitEdit();
            } catch (java.text.ParseException exc) {
                exc.printStackTrace();
            }
        } else { //text is invalid
            if (!userSaysRevert()) { //user wants to edit
                return false; //don't let the editor go away
            }
        }
        return super.stopCellEditing();
    }

    /**
     * Asks the user if they would like to revert to the previous valid value or
     * continue editing.
     *
     * @return true if the user wants to revert to the old value otherwise false
     */
    private boolean userSaysRevert() {
        Toolkit.getDefaultToolkit().beep();
        JFormattedTextField formattedFld = (JFormattedTextField)getComponent();
        formattedFld.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(formattedFld),
            "The value must be a non-negative integer.\n"
            + "You can either continue editing "
            + "or revert to the last valid value.",
            "Invalid Value Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);

        if (answer == 1) { //Revert!
            formattedFld.setValue(formattedFld.getValue());
            return true;
        }
        return false;
    }
}
