package edu.washington.example.sockets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * A simple UDP Echo client.  Prompts for a string, sends it to the server,
 * awaits the reply and prints it.
 *
 * @author Russ Moul
 */
public final class UdpEchoClient {
    /** Buffer size. */
    private static final int BUF_SIZE = 1024;

    /** The ip address. */
    private String ipAddress;

    /** The port. */
    private int port;

    /**
     * Constructor.
     *
     * @param ipAddress the hostname or IP address to connect to
     * @param port the port to connect to
     */
    public UdpEchoClient(final String ipAddress, final int port) {
        this.ipAddress = ipAddress;
        this.port = port;
    }

    /**
     * Repeatedly prompts for a string, sends it to the server, awaits the
     * reply, and prints it.  An input string of "q" end the loop.
     */
    public void start() {
        DatagramSocket sock = null;

        try {
            sock = new DatagramSocket();

            BufferedReader br = new BufferedReader(new InputStreamReader(
                        System.in));
            byte[] buf = new byte[BUF_SIZE];
            DatagramPacket packet = new DatagramPacket(buf, buf.length,
                    InetAddress.getByName(ipAddress), port);

            while (true) {
                System.out.print("Enter string to be echoed ('q' to quit): ");

                String line = br.readLine();

                if ("q".equals(line)) {
                    break;
                }

                byte[] bytes = line.getBytes();
                packet.setData(bytes);
                packet.setLength(bytes.length);
                sock.send(packet);
                System.out.print("Waiting for echo...");

                // we know it will be the same size, otherwise we might need
                // to use a larger buffer
                sock.receive(packet);
                System.out.println();
                System.out.println(
                             "Echo: <" + (new String(packet.getData(), 0, packet.getLength())) + ">");
                System.out.println();
            }
        } catch (IOException ex) {
            System.out.println("Server error: " + ex);
        } finally {
            if (sock != null) {
                sock.close();
            }
        }
    }
}
