package edu.washington.rgm.account;

import java.util.logging.Level;
import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.account.Account;
import edu.washington.ext.cp130.framework.account.AccountException;
import edu.washington.ext.cp130.framework.account.AccountFactory;

/**
 * An implementation of AccountFactory that creates SimpleAccount instances.
 *
 * @author Russ Moul
 */
public final class SimpleAccountFactory implements AccountFactory {
    /** Logger to be used by this class */
    private static final Logger logger =
                         Logger.getLogger(SimpleAccountFactory.class.getName());

    /**
     * Instantiations a an instance of SimpleAccount.
     *
     * @param accountName the account name
     * @param hashedPassword the password hash
     * @param initialBalance the balance
     *
     * @return the newly instantiated account, or null if unable
     *         to instantiate the account
     *
     * @see edu.washington.ext.cp130.framework.account.AccountFactory#newAccount(java.lang.String, byte[], int)
    */
    public Account newAccount(final String accountName,
                              final byte[] hashedPassword,
                              final int initialBalance) {
        Account acct = null;

        try {
            acct = new SimpleAccount(accountName, hashedPassword,
                                     initialBalance);
            if (logger.isLoggable(Level.INFO)) {
                logger.info("Created account: '" + accountName
                          + "', balance = " + initialBalance);
            }
        } catch (final AccountException ex) {
            final String msg = "Account creation failed for , account '"
                             + accountName + "', balance = " + initialBalance;
            logger.log(Level.WARNING, msg, ex);
        }

        return acct;
    }
}
