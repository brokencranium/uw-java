package edu.washington.rgm.account;

import edu.washington.ext.cp130.framework.account.AccountManager;
import edu.washington.ext.cp130.framework.account.AccountManagerFactory;
import edu.washington.ext.cp130.framework.dao.AccountDao;


/**
 * A simple implementation of the AccountManagerFactory that instantiates the
 * SimpleAccountManager.
 *
 * @author Russ Moul
 */
public final class SimpleAccountManagerFactory implements AccountManagerFactory
{
    /**
     * Instantiates a new SimpleAccountManager instance.
     *
     * @param dao the data access object to be used by the account manager
     *
     * @return a newly instantiated SimpleAccountManager
     */
    public AccountManager newAccountManager(final AccountDao dao) {
        return new SimpleAccountManager(dao);
    }
}

