package edu.washington.rgm.broker;

import java.util.logging.Logger;

import edu.washington.ext.cp130.framework.broker.OrderDispatchFilter;
import edu.washington.ext.cp130.framework.order.StopSellOrder;

/**
 * Dispatch filter that dispatches any orders having a price above the current
 * market price (threshold).
 *
 * @author Russ Moul
 */
public final class StopSellOrderDispatchFilter
             extends OrderDispatchFilter<Integer, StopSellOrder> {

     /** This class' logger. */
    private static final Logger log =
                         Logger.getLogger(OrderDispatchFilter.class.getName());

    /**
     * Constructor.
     *
     * @param initPrice the initial price
     */
    public StopSellOrderDispatchFilter(final int initPrice) {
        setThreshold(initPrice);
    }

    /**
     * Test the provided order against the threshold.
     *
     * @param order the order to be tested for dispatch
     *
     * @return true if the order price is above or equal the thresold
     */
    public boolean check(final StopSellOrder order) {
        final int threshold = getThreshold();
        final int price = order.getPrice();
        final boolean dispatch = price >= threshold;

        log.fine("StopSellDispatchFilter: desiredPrice = " + price
                                           + " curr price = " + threshold
                                           + " dispatch = " + dispatch);
        return dispatch;
    }
}

