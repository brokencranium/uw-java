package edu.washington.rgm.broker;

import java.util.Comparator;

import edu.washington.ext.cp130.framework.order.StopBuyOrder;

/**
 * Comparator which places the orders in ascending order - the highest priced
 * order is the last item in the list.
 *
 * @author Russ Moul
 */
public final class StopBuyOrderComparator implements Comparator<StopBuyOrder> {

    /**
     * Performs the comparison.
     *
     * @param order1 first of two orders to be compared
     * @param order2 first of two orders to be compared
     *
     * @return a negative integer, zero, or a positive integer as the first
     *         argument is less than, equal to, or greater than the second.
     *         Where the lesser order has the the lowest price, if prices are
     *         equal the lesser order will have the highest order quantity,
     *         finally if price and quantity are equal the lesser order will
     *         have the lower order id.

     */
    public int compare(final StopBuyOrder order1, final StopBuyOrder order2) {
        final int price1 = order1.getPrice();
        final int price2 = order2.getPrice();
        
        int diff = (price1 < price2) ? -1
                 : (price1 > price2) ? 1 : 0;

        if (diff == 0) {
            diff = order1.compareTo(order2);
        }

        return diff;
    }
}

