package test;


import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import edu.washington.ext.cp130.framework.broker.OrderDispatchFilter;
import edu.washington.ext.cp130.framework.broker.OrderQueue;
import edu.washington.ext.cp130.framework.order.MarketBuyOrder;
import edu.washington.ext.cp130.framework.order.MarketSellOrder;
import edu.washington.ext.cp130.framework.order.Order;
import edu.washington.ext.cp130.framework.order.StopBuyOrder;
import edu.washington.ext.cp130.framework.order.StopSellOrder;

// These need to be replaced with your classes
import edu.washington.rgm.broker.StopBuyOrderComparator;
import edu.washington.rgm.broker.StopSellOrderComparator;
import edu.washington.rgm.broker.SimpleOrderQueue;


/**
 * Test to verify the queue properly orders the orders.
 *
 * @author Russ Moul
 */
public class QueueTest {
    /** Properly ordered priced sell orders */
    private StopSellOrder[] stopSellOrders;

    /** Properly ordered priced buy orders */
    private StopBuyOrder[] stopBuyOrders;

    /** Properly ordered market orders */
    private Order[] marketOrders;

    /**
     * Initialize OrderManager to be exercised.
     */
    @Before
    public final void setUp() {
        final String acctName = "russ";
        final StopBuyOrder[] tmpBuy = {
                new StopBuyOrder(acctName, 10, "BA", 1010),
                new StopBuyOrder(acctName, 30, "BA", 2990),
                new StopBuyOrder(acctName, 30, "BA", 3005),
                new StopBuyOrder(acctName, 30, "BA", 3005),
                new StopBuyOrder(acctName, 10, "BA", 3005),
                new StopBuyOrder(acctName, 10, "F",  3995),
                new StopBuyOrder(acctName, 30, "BA", 4990),
        };
        stopBuyOrders = tmpBuy;

        final StopSellOrder[] tmpSell = {
                new StopSellOrder(acctName, 30, "BA", 4990),
                new StopSellOrder(acctName, 10, "F",  3995),
                new StopSellOrder(acctName, 30, "BA", 3005),
                new StopSellOrder(acctName, 30, "BA", 3005),
                new StopSellOrder(acctName, 10, "BA", 3005),
                new StopSellOrder(acctName, 30, "BA", 2990),
                new StopSellOrder(acctName, 10, "BA", 1010),
        };
        stopSellOrders = tmpSell;

        final Order[] tmpQty = {
            new MarketBuyOrder(acctName, 400, "BA"),
            new MarketSellOrder(acctName, 300, "BA"),
            new MarketSellOrder(acctName, 300, "BA"),
            new MarketSellOrder(acctName, 30, "BA"),
            new MarketBuyOrder(acctName, 20, "BA"),
            new MarketBuyOrder(acctName, 10, "F"),
            new MarketSellOrder(acctName, 5, "BA")
        };
        marketOrders = tmpQty;
    }

    /**
     * Tests the AscendingPriceComparator.
     *
     * @throws Exception if the ordering is incorrect
     */
    @Test
    public final void testAscendingQueue() throws Exception {
        /**
         * Dispatch filter for test purposes.
         */
        class TestBuyFilter extends OrderDispatchFilter<Object, StopBuyOrder> {
            private boolean dispatchState;
            /**
             * Dispatch filter returning the current dispatch state.
             * @param order not used
             * @return the dispatch state
              */
            @Override
            public boolean check(final StopBuyOrder order) {
                return dispatchState;
            }
        }

        final TestBuyFilter filter = new TestBuyFilter();
        OrderQueue<StopBuyOrder> q;
        q = new SimpleOrderQueue<StopBuyOrder>(new StopBuyOrderComparator(), filter);
        addOrders(q, stopBuyOrders);
        filter.dispatchState = true;

        Order order = null;
        for (int i = 0; (order = q.dequeue()) != null; i++) {
            assertTrue("\nNatural ordering queue out of order!\n"
                     + "MyOrder: " + order + "\nAscending List: " + stopBuyOrders[i] + "\n",
                       order.getOrderId() == stopBuyOrders[i].getOrderId());
        }
    }

    /**
     * Tests the DecendingPriceComparator.
     *
     * @throws Exception if the ordering is incorrect
     */
    @Test
    public final void testDescendingQueue() throws Exception {
        /**
         * Dispatch filter for test purposes.
         */
        class TestSellFilter extends OrderDispatchFilter<Object, StopSellOrder> {
            private boolean dispatchState;
            /**
             * Dispatch filter returning the current dispatch state.
             * @param order not used
             * @return the dispatch state
             */
            @Override
            public boolean check(final StopSellOrder order) {
                return dispatchState;
            }
        }

        final TestSellFilter filter = new TestSellFilter();
        OrderQueue<StopSellOrder> q;
        q = new SimpleOrderQueue<StopSellOrder>(new StopSellOrderComparator(), filter);
        addOrders(q, stopSellOrders);
        filter.dispatchState = true;

        Order order = null;
        for (int i = 0; (order = q.dequeue()) != null; i++) {
            assertTrue("\nNatural ordering queue out of order!\n"
                     + "MyOrder: " + order + "\nDescending List: " + stopSellOrders[i] + "\n",
                    order.getOrderId() == stopSellOrders[i].getOrderId());
        }
    }

    /**
     * Tests the order classes natural ordering (Comparable).
     *
     * @throws Exception if the ordering is incorrect
     */
    @Test
    public final void testNaturalOrderQueue() throws Exception {
        /**
         * Dispatch filter for test purposes.
         */
        class TestQtyFilter extends OrderDispatchFilter<Object, Order> {
            private boolean dispatchState;
            /**
             * Dispatch filter returning the current dispatch state.
             * @param order not used
             * @return the dispatch state
             */
            @Override
            public boolean check(final Order order) {
                return dispatchState;
            }
        }

        final TestQtyFilter filter = new TestQtyFilter();
        OrderQueue<Order> q;
        q = new SimpleOrderQueue<Order>(filter);
        addOrders(q, marketOrders);
        filter.dispatchState = true;

        Order order = null;
        for (int i = 0; (order = q.dequeue()) != null; i++) {
            assertTrue("\nNatural ordering queue out of order!\n"
                     + "MyOrder: " + order + "\nNatural Order List: " + marketOrders[i] + "\n",
                       order.getOrderId() == marketOrders[i].getOrderId());
        }
    }

    /**
     * Utility method to place some orders.
     *
     * @param q the queue to be populated
     * @param orders the array to populate the queue from
     * @param <T> the order type parameter
     */
    private <T extends Order> void addOrders(final OrderQueue <T> q,
                                             final T[] orders) {
        q.enqueue(orders[2]);
        q.enqueue(orders[4]);
        q.enqueue(orders[5]);
        q.enqueue(orders[0]);
        q.enqueue(orders[3]);
        q.enqueue(orders[1]);
        q.enqueue(orders[6]);
    }
}

