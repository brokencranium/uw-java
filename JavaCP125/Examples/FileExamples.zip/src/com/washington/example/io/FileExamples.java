package edu.washington.example.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

/**
 * Contains example code for:<br>
 *
 * Reading text from standard input<br>
 * Writing text to a file<br>
 * Appending to a file<br>
 * Reading text from a file<br>
 * Serializing an object<br>
 * Deserializing an object<br>
 */
public final class FileExamples {
   /**
    * Prevent instantiation.
    */
   private FileExamples() {
   }

   /**
    * Executes the example code.
    *
    * @param args (not used)
    */
   public static void main(final String[] args) {
      // Reading text from standard input
      try {
         BufferedReader in =
            new BufferedReader(new InputStreamReader(System.in));
         String str = "";
         System.out.print("Input some text> ");
         str = in.readLine();
         System.out.println("Read: '" + str + "'");
         System.out.println();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

      // Writing text to a file
      System.out.println("Writing: 'aString'");
      try {
         BufferedWriter out =
            new BufferedWriter(new FileWriter("Test.txt"));
         out.write("aString");
         out.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

      // Appending to a file
      System.out.println("Appending: 'aString'");
      try {
         BufferedWriter out =
            new BufferedWriter(new FileWriter("Test.txt", true));
         out.write("anotherString");
         out.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

      // Reading text from a file
      try {
         BufferedReader in =
            new BufferedReader(new FileReader("Test.txt"));
         String str;
         while ((str = in.readLine()) != null) {
            System.out.println("Read: '" + str + "'");
         }
         in.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

      //Serializing an object (which must implement Serializable)
      try {
         SerializableObject outExample = new SerializableObject();

         ObjectOutputStream out =
           new ObjectOutputStream(new FileOutputStream("./exampleObjects.ser"));
         out.writeObject(outExample);
         out.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

      //Deserializing an object
      try {
         ObjectInputStream in =
            new ObjectInputStream(new FileInputStream("./exampleObjects.ser"));
         SerializableObject inExample = (SerializableObject) in.readObject();
         in.close();
      } catch (ClassNotFoundException ex) {
         ex.printStackTrace();
      } catch (IOException ex) {
         ex.printStackTrace();
      }
   }
}

