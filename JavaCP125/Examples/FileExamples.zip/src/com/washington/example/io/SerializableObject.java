package edu.washington.example.io;

import java.io.Serializable;

/**
 * A simple serializable object.
 *
 * @author Bob Stallcop
 * @version $Revision$
 * Date: Apr 5, 2003
 * Time: 12:10:50 PM
 */
public final class SerializableObject implements Serializable {
    /** Default value. */
    private static final int DEFAULT_NUMBER_VALUE = 10;

    /** The lone member variable. */
    private int mNumber;

    /**
     * Constructor, set number to the default value.
     */
    public SerializableObject() {
        this(DEFAULT_NUMBER_VALUE);
    }

    /**
     * Constructor.
     *
     * @param number value for the number member
     */
    public SerializableObject(final int number) {
        mNumber = number;
    }


    /**
     * Gets number.
     *
     * @return value of the number member
     */
    public int getNumber() {
        return mNumber;
    }

    /**
     * Sets number.
     *
     * @param number value for the number member
     */
    public void setNumber(final int number) {
        mNumber = number;
    }
}
