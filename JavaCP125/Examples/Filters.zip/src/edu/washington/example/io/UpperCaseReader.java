package edu.washington.example.io;

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FilterReader;
import java.io.Reader;
import java.io.Writer;

/**
 * Converts characters to uppercase as they are read.
 * Demonstrates the use of the FilterReader class.
 *
 * @author Russ Moul
 */
public class UpperCaseReader extends FilterReader
{
   /**
    * Create a new UpperCaseReader.
    * @param r Reader to layer this UpperCaseReader upon.
    */
   public UpperCaseReader( Reader r )
   {
      super( r );
   }
   
   /**
    * Read a single character, converting it to uppercase.
    * @return    The character read, as an integer or -1 if end of stream has
    *            been reached
    * @exception IOException If an I/O error occurs
    */
   public int read()
   throws IOException
   {
      int c = super.read();
      if( c != -1 )
         c = Character.toUpperCase( (char)c );
      return c;
   }

   /**
    * Read characters into a prortion of an array, converting them to uppercase.
    * @return    The number of characters read or -1 if end of stream has
    *            been reached
    * @exception IOException If an I/O error occurs
    */
   public int read( char[] cbuf, int off, int len )
   throws IOException
   {
      int cnt = super.read( cbuf, off, len );
      if( cnt != -1 )
      {
         for( int i = off; i < off+len; i++ )
         {
            cbuf[i] = Character.toUpperCase( cbuf[i] );
         }
      }
      return cnt;
   }

   /**
    * Tests the UpperCaseReader methods.
    *
    * @param args      the String array containing command line arguments,
    *                  not used.
    */
   public static void main( String args[] )
   {
      char ch[] = new char[64];
      int  x;

      try
      {
         // create the UpperCaseReader object on a file
         Reader r = new FileReader( "preamble.txt" );
         UpperCaseReader fr = new UpperCaseReader( r );
         
         // read characters and print them
         while( (x = fr.read()) != -1 )
         {
            System.out.print( (char)x );
         }
         System.out.println();
         System.out.println();

         // Recreate the UpperCaseReader object
         r = new FileReader( "preamble.txt" );
         fr = new UpperCaseReader( r );

         // read characters and print them
         // note: read( char[] cbuf ) --> read( char[] cbuf, int off, int len )
         while( (x = fr.read( ch )) != -1 ) 
         {
            System.out.print( new String( ch, 0, x ) );
         }

         // Recreate the UpperCaseReader object
         r = new FileReader( "preamble.txt" );
         fr = new UpperCaseReader( r );
         // For kicks show we can add another layer/filter
         BufferedReader br = new BufferedReader(  fr );

         // read lines and print them
         String s;
         while( (s = br.readLine()) != null ) 
         {
            System.out.println( s );
         }

      }
      catch( IOException ex )
      {
         ex.printStackTrace();
      }
   }
}
