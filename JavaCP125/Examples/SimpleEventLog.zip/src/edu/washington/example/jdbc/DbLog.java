package edu.washington.example.jdbc;

import java.sql.*;
import java.util.Date;

public class DbLog
{
   private String mDbUrl;
   private String mDriverClassName;
   private String mUsername = "sa";
   private String mPassword = "";

   /**
    * Constructor.  Initializes variables required to make DB connection and
    * initializes the database.  If the EventLog table does not exist create it.
    *
    * @throws SQLException if any database operations fail
    * @throws ClassNotFoundException if the database drive class can't be loaded
    */
   public DbLog( String dbName, String driverClassName, String username,
                 String password )
   throws SQLException, ClassNotFoundException
   {
      mDbUrl = dbName;
      mDriverClassName = driverClassName;
      mUsername = username;
      mPassword = password;
      Class.forName( driverClassName );
      
      /**
      Connection conn = null;
      Statement stmnt;
      try
      {
         Class.forName( driverClassName );
         conn = DriverManager.getConnection( mDbUrl, mUsername, mPassword );
         stmnt = conn.createStatement();
         // throws SQLException is table doesn't exist
         ResultSet rs = stmnt.executeQuery( "SELECT COUNT(*) FROM EventLog" );
         conn.close();
      }
      catch( SQLException ex )
      {
         System.out.println( "Creating log table..." );
         stmnt = conn.createStatement();
         stmnt.executeUpdate( "CREATE TABLE EventLog"
                         + "( id INTEGER IDENTITY, message VARCHAR(255) )" );
      }
      */
   }

   /**
    * Adds a message to the event log table.
    * 
    * @param msg the message
    *
    * @return true if logged successfully
    */
   public boolean logMessage( String msg )
   {
      Connection conn = null;
      try
      {
         conn = DriverManager.getConnection( mDbUrl, mUsername, mPassword );
         Statement stmnt = conn.createStatement();
         stmnt.executeUpdate( "INSERT INTO EventLog (message)"
                            + " VALUES ('" + msg + "')" );
         return true;
      }
      catch( SQLException ex )
      {
         ex.printStackTrace();
      }
      return false;
   }

   /**
    * Prints the contents of teh event log table.
    */
   public void dump()
   {
      Connection conn = null;
      try
      {
         conn = DriverManager.getConnection( mDbUrl, mUsername, mPassword );
         Statement stmnt = conn.createStatement();
         ResultSet rs = stmnt.executeQuery( "SELECT id, message"
                                          + "  FROM EventLog" );
         while( rs.next() )
         {
            System.out.print( rs.getInt("id") + "   " );
            System.out.println( rs.getString("message") );
         }
         System.out.println();
      }
      catch( SQLException ex )
      {
         ex.printStackTrace();
      }
   }

   /**
    * Test the class.
    *
    * @param args[0] the message to be loged in place of the defalut message
    */
   public static void main( String[] args )
   throws SQLException, ClassNotFoundException
   {
      DbLog log = new DbLog( "jdbc:hsqldb:EventLogDB", "org.hsqldb.jdbcDriver",
                             "sa", "" );
      Date dt = new Date();
      String msg;
      if( args.length > 0 )
         msg = args[0] + " (posted " + dt + ")";
      else
         msg = "Simple test message (posted " + dt + ")";
      System.out.println( "Message: " + msg );
      log.logMessage( msg );
      log.dump();
      System.exit(0);
   }
}
