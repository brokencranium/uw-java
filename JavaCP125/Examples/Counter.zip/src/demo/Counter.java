package demo;

/**
 * A simple counter, that illustrates a simple use of independent threads.
 *
 * @author Russ Moul
 */
public final class Counter extends Thread {
    /** One second - in milliseconds */
    private static final int INTERVAL_ONE_SECOND = 1000;

    /** Two seconds - in milliseconds */
    private static final int INTERVAL_TWO_SECOND = 2000;

    /** Counter 1's increment limit */
    private static final int COUNTER_1_LIMIT = 10;

    /** Counter 2's increment limit */
    private static final int COUNTER_2_LIMIT =  5;

    /** Counter 3's increment limit */
    private static final int COUNTER_3_LIMIT = 40;

    /** Counter 4's increment limit */
    private static final int COUNTER_4_LIMIT = 20;

    /** The counters name. */
    private String mName;

    /** The counters limit. */
    private int mLimit;

    /** The counters increment interval. */
    private int mInterval;

    /** Should the counter terminate. */
    private boolean mTerminate;

    /**
     * Constructor.
     *
     * @param name the counters name
     * @param limit the counter will count upto this value (exclusive) from zero
     * @param interval the interval between counter increments
     */
    public Counter(final String name, final int limit, final int interval) {
        super(name);
        mName = name;
        mLimit = limit;
        mInterval = interval;
    }

    /**
     * Performs teh counting, printing its current value each time it is
     * incremented.
     */
    public void run() {
        int cnt = 0;

        while (!mTerminate && (cnt < mLimit)) {
            System.out.println("Counter " + mName + ": " + cnt++);

            try {
                sleep(mInterval);
            } catch (InterruptedException ex) {
                System.err.println("Ignoring interruption, Counter " + mName);
            }
        }
    }

    /**
     * Instruct the counter to terminate.
     */
    public void terminate() {
        mTerminate = true;
    }

    /**
     * Creates a number of Counters and lets them run.  The use of join is
     * illustrated as is thread termination.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        Counter c1 = new Counter("counter_1",
                                 COUNTER_1_LIMIT, INTERVAL_ONE_SECOND);
        Counter c2 = new Counter("counter_2",
                                 COUNTER_2_LIMIT, INTERVAL_TWO_SECOND);
        Counter c3 = new Counter("counter_3",
                                 COUNTER_3_LIMIT, INTERVAL_ONE_SECOND);
        Counter c4 = new Counter("counter_4",
                                 COUNTER_4_LIMIT, INTERVAL_ONE_SECOND);

        c1.start();
        c2.start();
        c3.start();
        c4.start();

        try {
            c1.join();
            c2.join();
        } catch (InterruptedException ex) {
            System.err.println("Join interrupted.");
            ex.printStackTrace();
        }

        System.out.println();
        System.out.println("Counters counter_1 & counter_2 have completed");

        System.out.println("Terminating counter_3");
        c3.terminate();

        System.out.println();
        System.out.println("Main is terminating!");
        System.out.println();
    }
}
