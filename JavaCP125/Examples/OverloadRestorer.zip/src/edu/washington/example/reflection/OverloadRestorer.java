package edu.washington.example.reflection;

import java.lang.reflect.Method;

// Define super class and three subclasses
abstract class SuperClass {}
class SubClass1 extends SuperClass {}
class SubClass2 extends SuperClass {}
class SubClass3 extends SuperClass {}

/**
 * Illustrates how reflection may be used to re-establish the ability to take
 * advantage of method overloading after an object reference has been
 * generalized to a less specific class.
 *
 * @author Russ Moul
 */
public class OverloadRestorer
{
   /**
    * The general method, identifies the correct method to invoke based on the
    * read type of the argument.
    *
    * @param o the object to be tested
    */
   public void test( SuperClass o )
   {
      System.out.println( "Method: test( SuperClass )" );
      Class[] argType = { o.getClass() };
      Object[] arg = { o };
      try
      {
         System.out.println( "Restoring overloading..." );
         Method method = getClass().getDeclaredMethod( "test", argType );
         method.invoke( this, arg );
      }
      catch( NoSuchMethodException ex )
      {
         System.out.println( "Need to add method: test( " + o.getClass().getName() + " )" );
      }
      catch( Exception iex )
      {
         System.out.println( "Need to fix method: test( " + o.getClass().getName() + " )" );
      }
   }

   /**
    * Test method for the SubClass1 class.  Simply prints its method signature
    * and the real type of the argument passed.
    *
    * @param o the object to be tested
    */
   private void test( SubClass1 o )
   {
      System.out.println( "Method: test( SubClass1 )" );
      System.out.println( "   Arguments actual type: "
                          + o.getClass().getName() );
   }

   /**
    * Test method for the SubClass2 class.  Simply prints its method signature
    * and the real type of the argument passed.
    *
    * @param o the object to be tested
    */
   private void test( SubClass2 o )
   {
      System.out.println( "Method: test( SubClass2 )" );
      System.out.println( "   Arguments actual type: "
                          + o.getClass().getName() );
   }

   /**
    * Generalizes the argument to the super class and calls test.
    *
    * @param o the object to be tested
    */
   public void generalize( SuperClass o )
   {
      test( o );
   }

   /**
    * Excersize the class.
    */
   public static void main (String argv [])
   {
      OverloadRestorer restorer = new OverloadRestorer();
      SubClass1 sub1 = new SubClass1();
      SubClass2 sub2 = new SubClass2();
      SubClass3 sub3 = new SubClass3();

      // invoke using specific references
      System.out.println( "Invoke test method using specific types..." );
      restorer.test( sub1 );
      restorer.test( sub2 );
      System.out.println();

      // invoke using more general reference
      System.out.println(
       "Invoke generalize method, which calls test with the general type..." );
      restorer.generalize( sub1 );
      System.out.println();

      // no method provided for SubClass3
      System.out.println( "Invoke generalize method, with unsupported class..." );
      restorer.generalize( sub3 );
   }

}


