import java.net.*;
import java.io.*;

/**
 * A simple UDP Echo client.  Prompts for a string, sends it to the server,
 * awaits the reply and prints it.
 */
public class UdpEchoClient  
{
   private String mIpAddress;
   private int mPort;

   /**
    * Constructor.  
    *
    * @param ipAddress the hostname or IP address to connect to
    * @param port the port to connect to
    */
   public UdpEchoClient( String ipAddress, int port )
   {
      mIpAddress = ipAddress;
      mPort = port;
   }

   /**
    * Repeatedly prompts for a string, sends it to the server, awaits the reply,
    * and prints it.  An input string of "q" end the loop.
    */
   public void start()
   {
      DatagramSocket sock = null;
      try
      {
         sock = new DatagramSocket();
         BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
         byte[] buf = new byte[256];
         DatagramPacket packet = new DatagramPacket( buf, buf.length,
                InetAddress.getByName(mIpAddress), mPort );
         while( true )
         {
            System.out.print( "Enter string to be echoed ('q' to quit): " );
            String line = br.readLine();
            if( "q".equals(line) ) break;
            byte[] bytes = line.getBytes();
            packet.setData( bytes );
            packet.setLength( bytes.length );
            sock.send( packet );
            System.out.print( "Waiting for echo..." );

            // we know it will be the same size, otherwise we would need to use
            // a bigger buffer
            sock.receive( packet );
            System.out.println();
            System.out.println( "Echo: <" + (new String(packet.getData())) + ">" );
            System.out.println();
         }
      }
      catch( IOException ex )
      {
         System.out.println( "Server error: " + ex );
      }
      finally
      {
         if( sock != null )
         {
            sock.close();
         }
      }
   }

   /**
    * Create the client and start it.
    *
    * @param args command line arguments, default host is localhost(128.0.0.1)
    *                  args[0] = port number
    *                        - or -
    *                  args[0] = ipaddress
    *                  args[1] = port number
    */
    public static void main( String[] args )
   {
      String host = "128.0.0.1";
      int port = 0;

      if( args.length == 1 )
      {
         port = Integer.parseInt( args[0] );
      }
      else if( args.length == 2 )
      {
         host = args[0];
         port = Integer.parseInt( args[1] );
      }
      else
      {
         System.out.println( "usage: java UdpEchoClient [host] port" );
         System.exit(0);
      }

      UdpEchoClient server = new UdpEchoClient( host, port );
      server.start();
   }
}

