import java.net.*;
import java.io.*;

/**
 * A simple Echo server, using UDP.  Replies to the client by echoing the
 * string sent to it.
 */
public class UdpEchoServer  
{
   private int mPort;

   /**
    * Constructor.  
    *
    * @param port the port to connect to
    */
   public UdpEchoServer( int port )
   {
      mPort = port;
   }

   /**
    * Continually, attemps to read a message and echo it back to the sended.
    */
   public void start()
   {
      DatagramSocket udpSock = null;
      try
      {
         udpSock = new DatagramSocket( mPort );
         System.out.println( "Server ready..." );
         byte[] buf = new byte[1024];
         DatagramPacket packet = new DatagramPacket( buf, buf.length );
         while( true )
         {
            udpSock.receive( packet );
            String msg = new String( packet.getData(), 0, packet.getLength() );
            msg = msg.toUpperCase();
            packet.setData( msg.getBytes() );
            packet.setLength( msg.length() );
            udpSock.send( packet );

            // prepare to receive - buffer must be big enough
            packet.setData( buf );
            packet.setLength( buf.length );
         }
      }
      catch( IOException ex )
      {
         System.out.println( "Server error: " + ex );
      }
      finally
      {
         if( udpSock != null )
         {
            udpSock.close();
         }
      }
   }

   /**
    * Create the server and start it.
    *
    * @param args command line arguments:
    *                  args[0] = port number
    */
   public static void main( String[] args )
   {
      int port = 0;
      if( args.length == 1 )
         port = Integer.parseInt( args[0] );
      else
      {
        System.out.println( "usage: java UdpEchoServer port" );
        System.exit(0);
      }

      UdpEchoServer server = new UdpEchoServer( port );
      server.start();
   }
}

