package edu.washington.example;

import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;

/**
 * A simple program to illustrate very basic use of the Formatter class.
 */
public class FormattedPrinting {

	/**
	 * Uses the Formatter to format strings, integers and dates.
	 *
	 * @param args unused
	 */
	public static void main(final String[] args) {
		Date today = Calendar.getInstance().getTime();
		int value = 450;
		String name = "Acme Industries";
		Formatter fmtr = new Formatter();
		
		// Prints the name, left aligned and padded to 20 characters, a separator (|),
		// the integer value right aligned padded to 6 characters, a separator (|),
		// the date in the mm/dd/yy format note that all the of the date conversions
		// draw their value from the third parameter the '3$' causes this, and lastly
		// a line termination sequence.
		// "Acme Industries     |   450|20/04/20"
		fmtr.format("%-20s|%6d|%3$tm/%3$td/%3$tC%n", name, value, today);
		System.out.print(fmtr.toString());
		
		// This does the same thing, only in pieces.  Here you can see the sepaarate
		// conversion character usages.
		fmtr = new Formatter();
		fmtr.format("%-20s|", name)
		    .format("%6d|", value)
		    .format("%1$tm/%1$td/%1$tC", today)  // note the parameter index is now 1
		    .format("%n");
		System.out.print(fmtr.toString());

		// This does the same thing, but uses the String.format method.
		String s = String.format("%-20s|%6d|%3$tm/%3$td/%3$tC%n", name, value, today);
		System.out.print(s);

		// Prints the name, right aligned and padded to 20 characters, a separator (|),
		// the integer value left aligned padded to 6 characters and always having its
		// sign, a separator (|), the date in the mm/dd/yy format note that all the of
		// the date conversions draw their value from the third parameter the '3$'
		// causes this, and lastly a line termination sequence.
	    // "Acme Industries|+450  |04/20/20"
		fmtr = new Formatter();
		fmtr.format("%20s|%-+6d|%3$tm/%3$td/%3$tC%n", name, value, today);
		System.out.print(fmtr.toString());
	}
}
