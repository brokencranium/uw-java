package edu.washington.example.serialization;

import java.io.*;

public class Cube implements java.io.Serializable
{
  private transient double surfaceArea;
  private transient double volume;
  private double    height;
  private double    width;
  private double    depth;

  public Cube( double height, double width, double depth )
  {
    this.height = height;
    this.width = width;
    this.depth = depth;
    surfaceArea = (width * height + width * depth + height * depth) * 2;
    volume = width * height * depth;
  }

  public String toString()
  {
    return (  "Height: " + height +
            "\nWidth:  " + width  +
            "\nDepth:  " + depth  +
            "\nArea:   " + surfaceArea +
            "\nVolume: " + volume );
  }

  public static void main( String args[] )
  {
    // create a Cube object
    Cube kube = new Cube( 2.0, 1.0, 3.0 );
    System.out.println( kube );
    try
    {
      // open the output file and layer an ObjectOutputStream on it
      FileOutputStream f = new FileOutputStream( "cube.dat" );
      ObjectOutputStream fout = new ObjectOutputStream( f );
      // write the Cube object to file
      fout.writeObject( kube );
      fout.close();

      // open the input file and layer an ObjectInputStream on it
      FileInputStream fis = new FileInputStream( "cube.dat" );
      ObjectInputStream fin = new ObjectInputStream( fis );

      System.out.println();
      // read all the objects from the file
      while( true )
      {
        Cube c = (Cube)fin.readObject();
        System.out.println( c );
      }
    }
    catch( EOFException ex )
    {
      System.out.println( "Done!" );
    }
    catch( IOException ex )
    {
      System.out.println( ex );
    }
    catch( ClassNotFoundException ex )
    {
      System.out.println( ex );
    }
  }
}
