/*
 * Day.java
 * Created on February 8, 2003, 5:59 PM
 */
package edu.washington.example.assertion;


/** Day encapsulates a simple date. Note that this class
 * is NOT Y2K compliant and does NOT handle leap years.
 * @author Bob Stallcop
 * @version $Revision: 1.7 $
 * @see java.util.Calendar
 */
public final class Day {
    /** The maximum number of months. */
    private static final int MAX_MONTHS = 12;

    /** The minimum number of months; 1-based. */
    private static final int MIN_MONTHS = 1;

    /** The number of days in each month;
     * does not handle leap years.
     */
    private static final int[] DAYS_IN_MONTH = {
        0, 31, 28, 31, 30, 31, 30, 31, 30, 30, 31, 30, 31
    };

    /** Holds the value of property month. */
    private int mMonth;

    /** Holds the value of property day. */
    private int mDay;

    /** Holds value of property year. */
    private int mYear;

    /** Construct a Day object with a month day and year.
     * @param month The month.
     * @param day The day.
     * @param year The year.
     */
    public Day(final int month, final int day, final int year) {
        if ((month <= 0) || (month > MAX_MONTHS)) {
            throw new IllegalArgumentException("month out of range");
        } else if ((day <= 0) || (day > DAYS_IN_MONTH[month])) {
            throw new IllegalArgumentException("day out of range");
        } else if (year <= 0) {
            throw new IllegalArgumentException("year out of range");
        }

        mMonth = month;
        mDay = day;
        mYear = year;
        assert invariant() : "assertion failed in Day()";

        //        assert mMonth >=1 && mMonth <=MAX_MONTHS;
        //        assert mDay >=1 && mDay <= DAYS_IN_MONTH[mMonth];
        //        assert mYear >= 0;
    }

    /** Getter for property month.
     * @return Value of property month.
     *
     */
    public int getMonth() {
        return mMonth;
    }

    /** Getter for property day.
     * @return Value of property day.
     *
     */
    public int getDay() {
        return mDay;
    }

    /** Getter for property year.
     * @return Value of property year.
     *
     */
    public int getYear() {
        return mYear;
    }

    /** Print the date of this Day in mm/dd/yyyy format.
     * @return String the formated date.
     */
    public String print() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(mMonth);
        buffer.append("/");
        buffer.append(mDay);
        buffer.append("/");
        buffer.append(mYear);

        return buffer.toString();
    }

    /**
     * Get a new Day with the next calendar date.
     * @return Day representing the next day.
     */
    public Day getNextDay() {
        Day newDay = new Day(mMonth, mDay, mYear);
        newDay.addDays(1);

        return newDay;
    }

    /** Add days to the current date of this day.
     * Correctly handles end-of-month and end-of-year
     * situations. Does not properly handle negative values
     * for daysToAdd.
     * @param daysToAdd the number of days to add.
     * This parameter must be positive and > 0.
     */
    public void addDays(final int daysToAdd) {
        int resultDay = mDay + daysToAdd;

        while (resultDay > DAYS_IN_MONTH[mMonth]) {
            resultDay -= DAYS_IN_MONTH[mMonth];
            addMonths(1);
        }

        mDay = resultDay;

        if (mDay > DAYS_IN_MONTH[mMonth]) {
            mDay -= DAYS_IN_MONTH[mMonth];
            addMonths(1);
        }

        assert invariant() : "assert failed in addDays()";

        return;
    }

    /** Add months to the current date.
     * Properly handles end-of-year situations. This method should only be
     * called interally.
     * @param monthsToAdd the months to add. Must be positive and &gt; 0.
     */
    private void addMonths(final int monthsToAdd) {
        int resultMonth = mMonth + monthsToAdd;

        while (resultMonth > MAX_MONTHS) {
            resultMonth -= MAX_MONTHS;
            mYear++;
        }

        mMonth = resultMonth;

        // Cannot assert invariant here, because this method can leave the
        // invariant untrue.
        // assert invariant();
        return;
    }

    /**
     * Returns true if the following class invariants are true:
     * month <= 0 or >= MAX_MONTHS,
     * day <=0 or > the number of days in the month,
     * year <=0.
     *
     * @return true if the class invariants are true.
     */
    private boolean invariant() {
        return ((mMonth >= 1)
             && (mMonth <= MAX_MONTHS)
             && (mDay >= 1)
             && (mDay <= DAYS_IN_MONTH[mMonth])
             && (mYear >= 0));
    }
}
