package edu.washington.example.io;

import java.io.FilterInputStream;
import java.io.InputStream;
import java.io.IOException;

/**
 * A reverse reader, reads byte pairs, reverses their orded and creates a
 * unicode character.
 */
public final class RevReader extends FilterInputStream {
    /** Size of one byte. */
    private static final int ONE_BYTE = 8;

    /** EOF value. */
    private static final char CHAR_EOF = 0xFFFF;

    /**
     * Constructor.
     *
     * @param in the underlying input stream
     */
    public RevReader(final InputStream in)    {
        super(in);
    }

    /**
     * Reads two bytes, reverses their order and creates a unicode character.
     *
     * @return the unicode character read, or -1 to indicate EOF
     *
     * @throws IOException if a read error occurs
     */
    public int read() throws IOException {
        byte[] buf = {0,0};
        int r = super.read(buf);
        if (r == -1) { // EOF
            return -1;
        }

        char charIn = (char)0;

        charIn |= buf[0];
        charIn |= buf[1] << ONE_BYTE;
        return charIn;
    }
}

