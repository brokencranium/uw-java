package edu.washington.example.io;

import java.io.FilterOutputStream;
import java.io.OutputStream;
import java.io.IOException;

/**
 * A reverse writer, writes the unicode bytes in reverse order.
 */
public final class RevWriter extends FilterOutputStream {
    /** Mask for the high byte */
    private static final char CHAR_HIGH_BYTE_MASK = 0xFF00;

    /** Mask for the low byte */
    private static final char CHAR_LOW_BYTE_MASK = 0x00FF;

    /**
     * Constructor.
     *
     * @param out the underlying stream
     */
    public RevWriter(final OutputStream out) {
        super(out);
    }

    /**
     * Writes the bytes of a unicode character in reverse order.
     *
     * @param c the character to write
     *
     * @throws IOException if a write error occurs
     */
    public void write(final char c) throws IOException {
        byte byteHigh = (byte)(c & CHAR_HIGH_BYTE_MASK);
        byte byteLow  = (byte)(c & CHAR_LOW_BYTE_MASK);

        super.write(byteLow);  // Write low then high
        super.write(byteHigh);
    }
}
