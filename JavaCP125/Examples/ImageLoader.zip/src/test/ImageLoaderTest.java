package test;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import edu.washington.example.loader.ImageLoader;

/**
 * Demonstrates the use the ImageLoader class.
 *
 * @author Russ Moul
 */
public class ImageLoaderTest
{
   /**
    * Creates a window and displays images laoded using the ImageLoader class.
    *
    * @param args not used
    */
   public static void main( String[] args )
   {
      JFrame frame = new JFrame( "Image Loader Test" );
      frame.addWindowListener( new WindowAdapter()
      {
         public void windowClosing( WindowEvent e )
         {
            System.exit( 0 );
         }
      } );
      frame.getContentPane().setLayout( new java.awt.FlowLayout() );

      Image img;
      ImageIcon icon;

      img = ImageLoader.loadImage( "curve.gif" );
      icon = new ImageIcon( img );
      frame.getContentPane().add( new JLabel( icon ) );

      img = ImageLoader.loadImage(
            "edu/washington/example/loader/reverse_curve.gif" );
      icon = new ImageIcon( img );
      frame.getContentPane().add( new JLabel( icon ) );

      img = ImageLoader.loadImage( "images/winding_road.gif" );
      icon = new ImageIcon( img );
      frame.getContentPane().add( new JLabel( icon ) );

      frame.pack();
      frame.setVisible( true );
   }
}
