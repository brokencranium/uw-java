package edu.washington.example.io;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.StringTokenizer;

import java.io.*;

/**
 * Enables simple console input.  Methods are provided to read values for the 
 * primative types from the console.  Each method returns a default value in the
 * event any exceptions occur.
 *
 * @author Russ Moul
 */
public final class ConsoleIn
{
   private static DataInputReader dir = new DataInputReader(System.in);

   /**
    * Reads a boolean value from the console.  The case insensitive string
    * "true" is interpreted as true all other values are false.
    *
    * @return the boolean value represented by the input string, false is
    *         returned in the event of an exception.
    */
   static boolean readBoolean()
   {
      boolean value = false;
      try
      {
         value = dir.readBoolean();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a byte value from the console.
    *
    * @return the byte value represented by the input string, 0 is
    *         returned in the event of an exception.
    */
   static byte readByte()
   {
      byte value = 0;
      try
      {
         value = dir.readByte();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a short value from the console.
    *
    * @return the short value represented by the input string, 0 is
    *         returned in the event of an exception.
    */
   static short readShort()
   {
      short value = 0;
      try
      {
         value = dir.readShort();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads an int value from the console.
    *
    * @return the int value represented by the input string, 0 is
    *         returned in the event of an exception.
    */
   static int readInt()
   {
      int value = 0;
      try
      {
         value = dir.readInt();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a long value from the console.
    *
    * @return the long value represented by the input string, 0L is
    *         returned in the event of an exception.
    */
   static long readLong()
   {
      long value = 0;
      try
      {
         value = dir.readLong();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a float value from the console.
    *
    * @return the float value represented by the input string, 0.0F is
    *         returned in the event of an exception.
    */
   static float readFloat()
   {
      float value = 0.0F;
      try
      {
         value = dir.readFloat();
      }
      catch( Exception ex )
      {}
      return value;
    }

   /**
    * Reads a double value from the console.
    *
    * @return the double value represented by the input string, 0.0 is
    *         returned in the event of an exception.
    */
   static double readDouble()
   {
      double value = 0.0;
      try
      {
         value = dir.readDouble();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a char value from the console.
    *
    * @return the first char of the input string, 0 is
    *         returned in the event of an exception.
    */
   static char readChar()
   {
      char value = 0;
      try
      {
         value = dir.readChar();
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Reads a String from the console.
    *
    * @return the the input string, an empty string is
    *         returned in the event of an exception.
    */
   static String readString()
   {
      String value = "";
      try
      {
         value = dir.readLine(); 
      }
      catch( Exception ex )
      {}
      return value;
   }

   /**
    * Tests each of the read methods.
    *
    * @param args      the String array containing command line arguments,
    *                  not used.
    */
   public static void main (String args[]){
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      PrintWriter w = new PrintWriter( baos, true );
      
      w.println( "A" );
      w.println( "Hello" );
      w.println( "true" );
      w.println( "16" );
      w.println( "1024" );
      w.println( "102400" );
      w.println( "1024000" );
      w.println( "3.14" );
      w.println( "3.14" );
      w.flush();

      byte[] buf = baos.toByteArray();
      //dir = (InputStream)new ByteArrayInputStream( buf );

      System.out.print("enter char: "); System.out.flush();
      System.out.println("You entered: '" + ConsoleIn.readChar() + "'" );

      System.out.print("enter String: "); System.out.flush();
      System.out.println("You entered: \"" + ConsoleIn.readString() + "\"" );

      System.out.print("enter boolean: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readBoolean() );

      System.out.print("enter byte: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readByte() );

      System.out.print("enter short: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readShort() );

      System.out.print("enter int: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readInt() );

      System.out.print("enter long: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readLong() );

      System.out.print("enter float: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readFloat() );

      System.out.print("enter double: "); System.out.flush();
      System.out.println("You entered: " + ConsoleIn.readDouble() );
   }

}
