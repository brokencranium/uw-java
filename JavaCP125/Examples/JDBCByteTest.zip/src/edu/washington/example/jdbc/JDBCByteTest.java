package edu.washington.example.jdbc;

import java.sql.*;
import java.io.*;

/**
 * Demonstrates the use of an SQL VARBINARY field for holding a byte array.
 */
public class JDBCByteTest 
{
   public static void main( String[] args )
   {
      
      Connection conn = null;
      String dbUrl = "jdbc:hsqldb:ByteTestDB";
      String driverClassName = "org.hsqldb.jdbcDriver";
      String username = "sa";
      String password = "";
      try
      {
         Class.forName( driverClassName );
         conn = DriverManager.getConnection( dbUrl, username, password );
         Statement stmnt = conn.createStatement();
         ResultSet rs;

         // CREATE TABLE
         System.out.println( "Creating table..." );
         stmnt.executeUpdate( "CREATE TABLE test_tab"
                      + "( name VARCHAR PRIMARY KEY,"
                      + "  data VARBINARY )" );

         // INSERT
         System.out.println( "Inserting ..." );
         PreparedStatement ps = conn.prepareStatement(
                              "INSERT INTO test_tab (name, data) "
                            + "VALUES ( ?, ? )" );
         ps.setString( 1, "record 1" );
         byte[] data = { 0,   1,  2,  3,  4,  5,  6,  7,  8, 9,
                         10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
         ps.setBytes( 2, data );
         int cnt = ps.executeUpdate();
         System.out.println( "" + cnt + " rows inserted" );

         // SELECT
         System.out.println( "Select ..." );
         rs = stmnt.executeQuery( "SELECT name, data"
                                + "  FROM test_tab" );
         while( rs.next() )
         {
            System.out.println( rs.getString("name") );
            byte[] dat = rs.getBytes("data");
            for( int i = 0; i < dat.length; i++ )
            {
               System.out.print( "" + dat[i] + " " );
            }
         }
         System.out.println();
         conn.close();

      }
      catch( Exception ex )
      {
         ex.printStackTrace();
         System.out.println( ex );
      }
      System.exit(0);
   }
}
