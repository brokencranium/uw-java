package edu.washington.example.reflection;


public class PriceChangeTest
{
   public static void main( String[] args )
   throws InterruptedException
   {
      FakeMarket market = new FakeMarket();

      PriceChangeListener listener1, listener2;
      listener1 = new SimplePriceChangeListener( "Listener 1" );
      listener2 = new SimplePriceChangeListener( "Listener 2" );
      
      market.addPriceChangeListener( listener1 );
      market.addPriceChangeListener( listener2 );

      Thread.currentThread().sleep( 5000 );

      System.out.println();
      System.out.println( "Removing second listener!" );
      System.out.println();
      market.removePriceChangeListener( listener2 );

      Thread.currentThread().sleep( 5000 );

      System.out.println();
      System.out.println( "Closing market." );
      market.close();
   }
}

class SimplePriceChangeListener implements PriceChangeListener
{
   private String mName;

   public SimplePriceChangeListener( String listenerName )
   {
      mName = listenerName;
   }

   public void priceChanged( PriceChangeEvent event )
   {
      System.out.println( mName + ": " + event.getTicker() + " "
                                       + event.getPrice() );
   }
}
