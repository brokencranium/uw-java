package edu.washington.example.reflection;

import java.util.EventListener;
/**
 *  
 */
public interface PriceChangeListener extends EventListener
{
   public void priceChanged( PriceChangeEvent event );
}
