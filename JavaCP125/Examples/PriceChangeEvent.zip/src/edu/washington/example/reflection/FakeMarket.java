package edu.washington.example.reflection;

import java.util.HashMap;
import java.util.Random;
import javax.swing.event.EventListenerList;

/**
 * A simulated market.
 *
 * @author Russ Moul
 */
public class FakeMarket extends Thread
{
   private boolean mAdjusting = true;
   private Stock[] mStocks = { new Stock( "IBM", 10000 ),
                              new Stock( "BA",   4000 ),
                              new Stock( "MSFT", 6000 ),
                            };

   private EventListenerList mListenerList = new EventListenerList();

   public FakeMarket()
   {
      start();
   }

   public void run()
   {
      Random rand = new Random();
      while(mAdjusting)
      {
         try
         {
            // get random delay, within range
            int interval = 100 + (int)(rand.nextDouble() * 500);
            // get random ticker
            int ndx = rand.nextInt( mStocks.length );
            // get random adjustment <= 1%
            int price = mStocks[ndx].getPrice();
            int adjustment = rand.nextInt() % (price/100);
            price += adjustment;
            mStocks[ndx].setPrice( price );
            firePriceChangeEvent( new PriceChangeEvent(this, mStocks[ndx].getTicker(), price) );
            sleep( interval );
         }
         catch( InterruptedException iex )
         {}
      }
   }

   /**
    * Stop the price adjustment.
    */
   public void close() {
       mAdjusting = false;
   }

   /**
    * Adds a price change listener.
    *
    * @param l the listener to add
    */
   public synchronized void addPriceChangeListener( PriceChangeListener l )
   {
      mListenerList.add(PriceChangeListener.class, l);
   }
   
   /**
    * Removes a price change listener.
    *
    * @param l the listener to remove
    */
   public synchronized void removePriceChangeListener( PriceChangeListener l )
   {
      mListenerList.remove(PriceChangeListener.class, l);
   }

   /**
    * Fires a price changed event.
    *
    * @param evnt the event to be fired
    */
   protected void firePriceChangeEvent( PriceChangeEvent evnt )
   {
     Object[] listeners = mListenerList.getListenerList();
     for (int i = listeners.length-2; i>=0; i-=2) {
         if (listeners[i]==PriceChangeListener.class) {
             ((PriceChangeListener)listeners[i+1]).priceChanged(evnt);
         }
     }
   }

}
