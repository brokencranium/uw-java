package edu.washington.example.reflection;

import java.util.EventObject;

/**
 * Event object encapsulating a stock price change event.
 */
public class PriceChangeEvent extends java.util.EventObject
{
   protected String mTicker;
   protected int mPrice;

   /**
    * Constructor.
    *
    * @param source event source
    * @param ticker stock ticker symbol
    * @param price the new price
    */
   PriceChangeEvent(Object source, String ticker, int price)
   {
      super( source );
      mTicker = ticker;
      mPrice = price;
   }
      
   /**
    * Gets the stock ticker symbol for the stock experienceing the price change.
    *
    * @return the stock ticker symbol
    */
   public String getTicker()
   {
      return mTicker;
   }
      
   /**
    * Gets the new price of the stoc experienceing the price change.
    *
    * @return the new stock price
    */
   public int getPrice()
   {
      return mPrice;
   }
}
