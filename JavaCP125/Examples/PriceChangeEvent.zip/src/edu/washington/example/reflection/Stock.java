package edu.washington.example.reflection;

public class Stock
{
   private String mTicker = " ";
   private int mPrice = 0;

   public Stock()
   {}

   public Stock( String ticker, int price )
   {
      setTicker( ticker );
      setPrice( price );
   }

   private void setTicker( String ticker )
   {
      ticker = ticker.trim();
      if( ticker == null 
       || ticker.length() == 0
       || ticker.length() > 4 )
       throw new IllegalArgumentException( "Ticker must be 1 to 4 chararacters." );

      mTicker = ticker;
   }

   public String getTicker()
   {
      return mTicker;
   }

   public void setPrice( int price )
   {
      if( price < 0 )
       throw new IllegalArgumentException( "Price must be a positive value." );

      mPrice = price;
   }

   public int getPrice()
   {
      return mPrice;
   }

   public String toString()
   {
      return mTicker + ":" + mPrice;
   }

}


