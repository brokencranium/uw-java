package edu.washington.example.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

/**
 * Copies a file.
 */
public final class FileCopier {
    /** Working buffer sive. */
    private static final int BUF_SIZE = 128;

    /**
     * Prevent instantiation.
     */
    private FileCopier() {
    }

    /**
     * Copies a file.
     *
     * @param args args[0] the source file name
     *             args[1] the destination file name
     */
    public static void main (final String[] args) {
        if (args.length != 2) {
            System.out.println("usage: FileCopier src dst");
            System.exit(1);
        }

        String sourcePath = args[0];
        String destPath = args[1];
        File srcFile = new File(sourcePath);
        if (srcFile.exists()) {
            if (srcFile.isDirectory()) {
                System.out.println("Source file is a directory.");
            } else {
                try {
                    System.out.println("Copying " + sourcePath
                                     + " to " + destPath);
                    InputStream is = new FileInputStream (srcFile);
                    OutputStream os = new FileOutputStream (destPath);
                    int count = 0;
                    byte[] bytes = new byte[BUF_SIZE];
                    while ((count = is.read(bytes)) != -1) {
                        os.write(bytes, 0, count);
                    }
                    is.close();
                    os.close();
                } catch (IOException e) {
                    System.out.println("IO Exception on copy");
                    System.out.println(e.getMessage());
                }
            }
        } else {
            System.out.println("Source file does not exist.");
        }
    }
}


