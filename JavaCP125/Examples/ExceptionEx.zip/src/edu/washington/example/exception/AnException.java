package edu.washington.example.exception;

/**
 * A trivial "custom" exception.
 */
public final class AnException extends Exception {
    /**
     * Default (no argument) constructor.
     */
    public AnException() {
        super("AnException");
    }

    /**
     * Constructor, allows chaining.
     *
     * @param cause the Throwable that caused this exception to be created
     */
    public AnException(final Throwable cause) {
        super("AnException", cause);
    }

    /**
     * Constructor.
     *
     * @param message a message indicating the cause of the exception
     */
    public AnException(final String message) {
        super(message);
    }
    /**
     * Constructor.
     *
     * @param message a message indicating the cause of the exception
     * @param cause the Throwable that caused this exception to be created
     */
    public AnException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
