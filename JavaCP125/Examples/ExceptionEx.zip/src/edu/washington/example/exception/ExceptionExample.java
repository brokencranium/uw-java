package edu.washington.example.exception;

/**
 * Ilustrates the use of exception chaining.
 */
public final class ExceptionExample {
    /**
     * Method that thows an AnException exception.
     *
     * @throws AnException - always throws this exception
     */
    public void aMethod() throws AnException {
        System.out.println("Entered aMethod()");
        throw new AnException("AnException thrown from aMethod()");

        //System.out.println("Leaving aMethod()");
    }

    /**
     * Calls aMethod and cains its exception.
     *
     * @throws Exception - always throws this exception
     */
    public void myMethod() throws Exception {
        try {
            aMethod();
            System.out.println("After aMethod() call");
        } catch (AnException anEx) {
            System.out.println("AnException caught");

            // Chain the caught exception
            // Exception ex = new Exception("Chaining AnException", anEx);
            // not all Exception subclasses support the above, but this will
            // also work
            Exception ex = new Exception("Chaining AnException");
            ex.initCause(anEx);
            throw ex;
        } finally {
            System.out.println("finally in myMethod() done");
        }
    }

    /**
     * Program entry point.
     *
     * @param args (not used)
     */
    public static void main(final String[] args) {
        ExceptionExample example = new ExceptionExample();

        try {
            example.myMethod();
        } catch (Exception e) {
            System.out.println("Caught Exception with cause "
                             + e.getCause().getMessage());
        } finally {
            System.out.println("finally in main() done");
        }
    }
}
